package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.Shop
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning

@Composable
fun AdminMetricCard(
  title: String,
  value: String,
  subtitle: String,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, OutlineSubtle),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Text(text = title, style = MaterialTheme.typography.labelMedium, color = KgsForest)
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = KgsEmerald,
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminOrderVerificationCard(
  order: Order,
  language: AppLanguage,
  deliveryPartners: List<UserProfile>,
  isAdmin: Boolean,
  onVerifyUpi: (String, Boolean) -> Unit,
  onMarkCodCollected: (String) -> Unit,
  onUpdateRefund: (String, String) -> Unit,
  onAssignPartner: (String, String) -> Unit,
  onUpdateStatus: (String, OrderStatus) -> Unit,
) {
  var showAssignDialog by rememberSaveable { mutableStateOf(false) }

  if (showAssignDialog) {
    AlertDialog(
      onDismissRequest = { showAssignDialog = false },
      title = { Text("Assign Delivery Partner") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          if (deliveryPartners.isEmpty()) {
            Text(
              text = "No users currently have the Delivery Partner role. Promote a user in the Delivery tab first.",
              style = MaterialTheme.typography.bodySmall,
            )
          } else {
            deliveryPartners.forEach { partner ->
              OutlinedButton(
                onClick = {
                  onAssignPartner(order.id, partner.id)
                  showAssignDialog = false
                },
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
              ) {
                Text("${partner.fullName.ifBlank { partner.phone }} (${partner.phone})")
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showAssignDialog = false }) { Text("Close") }
      },
    )
  }

  val pStatus = order.parsedPaymentStatus
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, OutlineSubtle),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "${order.orderNumber} • ${order.customerName}",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = formatInr(order.totalAmount),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = KgsForest,
        )
      }
      Text(
        text = "${order.status.labelEn} • ${order.paymentMethod.labelEn} • ${order.deliveryAddress}",
        style = MaterialTheme.typography.bodySmall,
      )

      if (order.status == OrderStatus.CANCELLED && !order.cancellationReason.isNullOrBlank()) {
        Text(
          text = "Cancellation reason: ${order.cancellationReason}",
          style = MaterialTheme.typography.bodySmall,
          color = StatusError,
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PaymentStatusBadge(paymentStatus = pStatus, language = language)
        if (order.refundStatus != "none") {
          Surface(shape = RoundedCornerShape(8.dp), color = StatusWarning.copy(alpha = 0.14f)) {
            Text(
              text = "Refund: ${order.refundStatus}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = StatusWarning,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
          }
        }
      }

      if (order.paymentMethod == PaymentMethod.UPI) {
        Surface(shape = RoundedCornerShape(8.dp), color = KgsMintContainer) {
          Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            Text(
              text =
                "Customer Paid Claim: ${if (order.customerMarkedPaid) "Yes" else "Not marked"} • UTR: ${order.upiReference ?: "Not provided"}",
              style = MaterialTheme.typography.bodySmall,
              color = KgsForest,
            )
          }
        }
        if (pStatus == PaymentStatus.PENDING_VERIFICATION || pStatus == PaymentStatus.UPI_REJECTED) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = { onVerifyUpi(order.id, true) },
              enabled = isAdmin,
              colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
            ) {
              Text("Verify Kotak UPI", maxLines = 1)
            }
            OutlinedButton(
              onClick = { onVerifyUpi(order.id, false) },
              enabled = isAdmin,
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
            ) {
              Text("Reject UPI", maxLines = 1, color = StatusError)
            }
          }
        }
      } else if (pStatus == PaymentStatus.COD_PENDING) {
        OutlinedButton(
          onClick = { onMarkCodCollected(order.id) },
          enabled = isAdmin,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Text("Mark COD Cash Collected")
        }
      }

      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        OutlinedButton(
          onClick = { showAssignDialog = true },
          enabled = isAdmin,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Text(
            if (order.deliveryPartnerId == null) "Assign Partner"
            else "Partner: ${order.deliveryPartnerName ?: "Assigned"}"
          )
        }
        if (order.status != OrderStatus.CANCELLED && order.status != OrderStatus.DELIVERED) {
          OutlinedButton(onClick = { onUpdateStatus(order.id, OrderStatus.CONFIRMED) }, enabled = isAdmin) {
            Text("Accept")
          }
          OutlinedButton(onClick = { onUpdateStatus(order.id, OrderStatus.PACKED) }, enabled = isAdmin) {
            Text("Preparing")
          }
          OutlinedButton(onClick = { onUpdateStatus(order.id, OrderStatus.OUT_FOR_DELIVERY) }, enabled = isAdmin) {
            Text("Dispatch")
          }
          OutlinedButton(onClick = { onUpdateStatus(order.id, OrderStatus.DELIVERED) }, enabled = isAdmin) {
            Text("Deliver")
          }
          OutlinedButton(onClick = { onUpdateStatus(order.id, OrderStatus.CANCELLED) }, enabled = isAdmin) {
            Text("Cancel", color = StatusError)
          }
        }
        if (order.status == OrderStatus.CANCELLED &&
          (pStatus == PaymentStatus.UPI_VERIFIED || order.refundStatus != "none")
        ) {
          OutlinedButton(onClick = { onUpdateRefund(order.id, "initiated") }, enabled = isAdmin) {
            Text("Initiate Refund")
          }
          OutlinedButton(onClick = { onUpdateRefund(order.id, "refunded") }, enabled = isAdmin) {
            Text("Mark Refunded")
          }
          OutlinedButton(onClick = { onUpdateRefund(order.id, "rejected") }, enabled = isAdmin) {
            Text("Reject Refund", color = StatusError)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminProfileCard(
  profile: UserProfile,
  isAdmin: Boolean,
  onUpdateRole: (String, UserRole) -> Unit,
  onToggleActive: (String, Boolean) -> Unit,
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, OutlineSubtle),
  ) {
    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "${profile.fullName.ifBlank { profile.email.ifBlank { profile.phone } }} (${profile.role.labelEn})",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.weight(1f),
        )
        TextButton(onClick = { onToggleActive(profile.id, !profile.isActive) }, enabled = isAdmin) {
          Text(
            text = if (profile.isActive) "Active" else "Disabled",
            color = if (profile.isActive) KgsEmerald else StatusError,
          )
        }
      }
      Text(
        text = "${profile.phone} • ${profile.email}",
        style = MaterialTheme.typography.bodySmall,
      )
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        UserRole.entries.forEach { role ->
          OutlinedButton(
            onClick = { onUpdateRole(profile.id, role) },
            enabled = isAdmin && profile.role != role,
          ) {
            Text(role.labelEn, style = MaterialTheme.typography.labelSmall)
          }
        }
      }
    }
  }
}

@Composable
fun AdminProductDialog(
  existing: Product?,
  shops: List<Shop>,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (Product, String, String) -> Unit,
) {
  var name by rememberSaveable { mutableStateOf(existing?.name.orEmpty()) }
  var nameHi by rememberSaveable { mutableStateOf(existing?.nameHi.orEmpty()) }
  var category by rememberSaveable { mutableStateOf(existing?.category ?: "Grains & Atta") }
  var unit by rememberSaveable { mutableStateOf(existing?.baseUnit ?: "1kg") }
  var price by rememberSaveable { mutableStateOf(existing?.basePrice?.toString().orEmpty()) }
  var stock by rememberSaveable { mutableStateOf(existing?.stockQty?.toString() ?: "50") }
  var imageUrl by rememberSaveable { mutableStateOf(existing?.imageUrl.orEmpty()) }
  var selectedShopId by rememberSaveable {
    mutableStateOf(existing?.shopId ?: shops.firstOrNull()?.id.orEmpty())
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) "Add Catalog Product" else "Edit ${existing.name}") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Product Name (English)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = nameHi,
          onValueChange = { nameHi = it },
          label = { Text("Product Name (Hindi - Optional)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category") },
          singleLine = true,
        )
        OutlinedTextField(
          value = unit,
          onValueChange = { unit = it },
          label = { Text("Base Unit (e.g. 1kg, 500g, 1 pc)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = price,
          onValueChange = { price = it },
          label = { Text("Price (₹)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
        )
        OutlinedTextField(
          value = stock,
          onValueChange = { stock = it.filter { c -> c.isDigit() } },
          label = { Text("Stock Qty") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
        )
        OutlinedTextField(
          value = imageUrl,
          onValueChange = { imageUrl = it },
          label = { Text("Image URL (Optional)") },
          singleLine = true,
        )
        if (shops.isNotEmpty()) {
          Text("Shop / Distributor", style = MaterialTheme.typography.labelMedium)
          shops.take(6).forEach { shop ->
            FilterChip(
              selected = selectedShopId == shop.id,
              onClick = { selectedShopId = shop.id },
              label = { Text(shop.shopName) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            (existing ?: Product(id = "", name = name, category = category, basePrice = 0.0))
              .copy(
                name = name.trim(),
                nameHi = nameHi.trim().takeIf { it.isNotBlank() },
                category = category.trim(),
                baseUnit = unit.trim(),
                imageUrl = imageUrl.trim().takeIf { it.isNotBlank() },
                shopId = selectedShopId.takeIf { it.isNotBlank() } ?: existing?.shopId,
              ),
            price,
            stock,
          )
        },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}
