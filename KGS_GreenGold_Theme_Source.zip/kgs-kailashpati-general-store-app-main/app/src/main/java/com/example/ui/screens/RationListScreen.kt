package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.QuantityVariant
import com.example.model.RationItem
import com.example.ui.components.QuantityVariantSelector
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.viewmodel.KgsUiState

@Composable
fun RationListScreen(
  state: KgsUiState,
  strings: AppStrings,
  onAddCustomRation: (String, QuantityVariant, Int) -> Unit,
  onEditRationItem: (String, String, QuantityVariant, Int) -> Unit,
  onUpdateRationQty: (String, Int) -> Unit,
  onAddAllToCart: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showAddDialog by rememberSaveable { mutableStateOf(false) }
  var editingItemId by rememberSaveable { mutableStateOf<String?>(null) }

  if (showAddDialog) {
    AddOrEditRationItemDialog(
      existing = null,
      strings = strings,
      onDismiss = { showAddDialog = false },
      onConfirm = { name, variant, qty ->
        onAddCustomRation(name, variant, qty)
        showAddDialog = false
      },
    )
  }

  editingItemId?.let { id ->
    state.rationItems.firstOrNull { it.id == id }?.let { target ->
      AddOrEditRationItemDialog(
        existing = target,
        strings = strings,
        onDismiss = { editingItemId = null },
        onConfirm = { name, variant, qty ->
          onEditRationItem(target.id, name, variant, qty)
          editingItemId = null
        },
      )
    }
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = strings.rationTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = strings.rationSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = { showAddDialog = true },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("add_custom_ration_button"),
            ) {
              Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null)
              Spacer(modifier = Modifier.width(6.dp))
              Text(strings.addCustomRationItem, maxLines = 1)
            }
            if (state.rationItems.isNotEmpty()) {
              Button(
                onClick = onAddAllToCart,
                colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("ration_add_all_cart_button"),
              ) {
                Icon(Icons.Filled.AddShoppingCart, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.addAllToCart, maxLines = 1)
              }
            }
          }
        }
      }

      if (state.rationItems.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Outlined.ReceiptLong,
                contentDescription = null,
                tint = KgsEmerald,
                modifier = Modifier.size(56.dp),
              )
              Text(
                text = strings.emptyRationBody,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      } else {
        items(state.rationItems, key = { it.id }) { item ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                  text =
                    if (state.language == AppLanguage.HINDI && !item.productNameHi.isNullOrBlank()) {
                      item.productNameHi
                    } else {
                      item.productName
                    },
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.SemiBold,
                )
                Text(
                  text =
                    buildString {
                      append(item.variant.label)
                      if (item.estimatedUnitPrice > 0.0) {
                        append(" • ${formatInr(item.estimatedUnitPrice * item.quantity)}")
                      }
                    },
                  style = MaterialTheme.typography.bodySmall,
                  color = KgsForest,
                )
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = { editingItemId = item.id },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("edit_ration_${item.id}"),
                ) {
                  Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = strings.editRationItem,
                    tint = KgsEmerald,
                  )
                }
                IconButton(
                  onClick = { onUpdateRationQty(item.id, item.quantity - 1) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector =
                      if (item.quantity == 1) Icons.Filled.DeleteOutline else Icons.Filled.Remove,
                    contentDescription = "Decrease ration quantity",
                  )
                }
                Text(
                  text = item.quantity.toString(),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                IconButton(
                  onClick = { onUpdateRationQty(item.id, item.quantity + 1) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Filled.Add, contentDescription = "Increase ration quantity")
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AddOrEditRationItemDialog(
  existing: RationItem?,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onConfirm: (String, QuantityVariant, Int) -> Unit,
) {
  var name by rememberSaveable(existing?.id) { mutableStateOf(existing?.productName.orEmpty()) }
  var selectedVariant by rememberSaveable(existing?.id) {
    mutableStateOf(existing?.variant ?: QuantityVariant.KG5)
  }
  var qtyText by rememberSaveable(existing?.id) {
    mutableStateOf((existing?.quantity ?: 1).toString())
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(if (existing == null) strings.addCustomRationItem else strings.editRationItem)
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Grocery Item (e.g. Chakki Atta)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("ration_item_name_input"),
        )
        Text(text = strings.selectVariant, style = MaterialTheme.typography.labelLarge)
        QuantityVariantSelector(
          selectedVariant = selectedVariant,
          priceProvider = null,
          variants = QuantityVariant.standardGroceryOptions,
          onSelect = { selectedVariant = it },
        )
        OutlinedTextField(
          value = qtyText,
          onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
          label = { Text("Monthly Packs Count") },
          singleLine = true,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(name, selectedVariant, qtyText.toIntOrNull() ?: 1) },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
        modifier = Modifier.testTag("ration_save_item_button"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}
