package com.example.ui.viewmodel

import com.example.config.SupabaseConfig
import com.example.model.AppLanguage
import com.example.model.AuthSession
import com.example.model.CartItem
import com.example.model.Category
import com.example.model.CustomerAddress
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.RationItem
import com.example.model.SchemaInspectionResult
import com.example.model.Shop
import com.example.model.UserProfile
import com.example.model.UserRole

data class KgsUiState(
  val language: AppLanguage = AppLanguage.ENGLISH,
  val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured,
  val isUpiConfigured: Boolean = true,
  val merchantUpiVpa: String = SupabaseConfig.effectiveUpiVpa,
  val merchantPayeeName: String = SupabaseConfig.effectivePayeeName,
  val authSession: AuthSession? = null,
  val isAuthLoading: Boolean = false,
  val otpSentToPhone: String? = null,
  val authFeedback: String? = null,
  val isInspectingSchema: Boolean = false,
  val schemaInspection: SchemaInspectionResult? = null,
  val isLoadingCatalog: Boolean = false,
  val catalogError: String? = null,
  val products: List<Product> = emptyList(),
  val totalCatalogCount: Int = 0,
  val resolvedProductsTable: String = "products",
  val categories: List<Category> = emptyList(),
  val publicShops: List<Shop> = emptyList(),
  val searchQuery: String = "",
  val selectedCategory: String = ALL_CATEGORY_KEY,
  val selectedShopId: String = ALL_SHOP_KEY,
  val inStockOnly: Boolean = false,
  val cartItems: List<CartItem> = emptyList(),
  val addresses: List<CustomerAddress> = emptyList(),
  val selectedAddressId: String? = null,
  val rationItems: List<RationItem> = emptyList(),
  val orders: List<Order> = emptyList(),
  val isLoadingOrders: Boolean = false,
  val isPlacingOrder: Boolean = false,
  val shops: List<Shop> = emptyList(),
  val profiles: List<UserProfile> = emptyList(),
  val isLoadingPanelData: Boolean = false,
  val snackbarMessage: String? = null,
) {
  val filteredProducts: List<Product>
    get() =
      products.filter { product ->
        val matchesCategory =
          selectedCategory == ALL_CATEGORY_KEY ||
            product.category.equals(selectedCategory, ignoreCase = true)
        val matchesShop =
          selectedShopId == ALL_SHOP_KEY || product.shopId == selectedShopId
        val matchesStock = !inStockOnly || (product.isAvailable && product.stockQty > 0)
        val q = searchQuery.trim()
        val matchesSearch =
          q.isEmpty() ||
            product.name.contains(q, ignoreCase = true) ||
            (product.nameHi?.contains(q, ignoreCase = true) == true) ||
            product.category.contains(q, ignoreCase = true) ||
            product.description.contains(q, ignoreCase = true)
        matchesCategory && matchesShop && matchesStock && matchesSearch
      }

  val cartCount: Int
    get() = cartItems.sumOf { it.quantity }

  val cartSubtotal: Double
    get() = cartItems.sumOf { it.lineTotal }

  val deliveryFee: Double
    get() = if (cartItems.isEmpty() || cartSubtotal >= 499.0) 0.0 else 25.0

  val totalPayable: Double
    get() = cartSubtotal + deliveryFee

  val selectedAddress: CustomerAddress?
    get() =
      addresses.firstOrNull { it.id == selectedAddressId }
        ?: addresses.firstOrNull { it.isDefault }
        ?: addresses.firstOrNull()

  // Strict shop isolation helpers for Distributor Portal
  val distributorOwnedShopIds: Set<String>
    get() {
      val uid = authSession?.userId ?: return emptySet()
      return shops.filter { it.ownerId == uid }.map { it.id }.filter { it.isNotBlank() }.toSet()
    }

  val distributorScopedProducts: List<Product>
    get() {
      val session = authSession ?: return emptyList()
      if (session.role == UserRole.ADMIN) return products
      if (session.role != UserRole.DISTRIBUTOR) return emptyList()
      val ownShopIds = distributorOwnedShopIds
      return products.filter {
        (it.shopId != null && it.shopId in ownShopIds) || it.distributorId == session.userId
      }
    }

  val distributorScopedOrders: List<Order>
    get() {
      val session = authSession ?: return emptyList()
      if (session.role == UserRole.ADMIN) return orders
      if (session.role != UserRole.DISTRIBUTOR) return emptyList()
      val ownShopIds = distributorOwnedShopIds
      return orders.filter {
        (it.shopId != null && it.shopId in ownShopIds) || it.distributorId == session.userId
      }
    }

  val deliveryScopedOrders: List<Order>
    get() {
      val session = authSession ?: return emptyList()
      if (session.role == UserRole.ADMIN) return orders
      if (session.role != UserRole.DELIVERY_PARTNER) return emptyList()
      return orders.filter { it.deliveryPartnerId == session.userId }
    }

  fun canEditProduct(product: Product): Boolean {
    val session = authSession ?: return false
    if (session.role == UserRole.ADMIN) return true
    if (session.role != UserRole.DISTRIBUTOR) return false
    return (product.shopId != null && product.shopId in distributorOwnedShopIds) ||
      product.distributorId == session.userId
  }

  // Admin analytics metrics
  val totalOrderVolume: Double
    get() = orders.filter { it.status != OrderStatus.CANCELLED }.sumOf { it.totalAmount }

  val verifiedAndCollectedRevenue: Double
    get() =
      orders
        .filter {
          it.status != OrderStatus.CANCELLED &&
            (it.parsedPaymentStatus == PaymentStatus.UPI_VERIFIED ||
              it.parsedPaymentStatus == PaymentStatus.COD_COLLECTED)
        }
        .sumOf { it.totalAmount }

  val pendingUpiVerificationOrdersCount: Int
    get() =
      orders.count {
        it.paymentMethod == com.example.model.PaymentMethod.UPI &&
          it.parsedPaymentStatus == PaymentStatus.PENDING_VERIFICATION
      }

  val outOfStockProductsCount: Int
    get() = products.count { !it.isAvailable || it.stockQty <= 0 }

  companion object {
    const val ALL_CATEGORY_KEY = "__ALL__"
    const val ALL_SHOP_KEY = "__ALL_SHOPS__"
  }
}
