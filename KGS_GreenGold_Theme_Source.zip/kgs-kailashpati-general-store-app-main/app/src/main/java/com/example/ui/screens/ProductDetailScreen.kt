package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.ui.components.QuantityVariantSelector
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintBg
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
  product: Product,
  language: AppLanguage,
  strings: AppStrings,
  canEditPrice: Boolean,
  onBack: () -> Unit,
  onAddToCart: (Product, QuantityVariant) -> Unit,
  onAddToRation: (Product, QuantityVariant) -> Unit,
  onSavePriceAndStock: (Product, String, String) -> Unit,
) {
  BackHandler(onBack = onBack)

  var selectedVariant by rememberSaveable { mutableStateOf(QuantityVariant.KG1) }
  var priceInput by rememberSaveable(product.id) { mutableStateOf(product.basePrice.toString()) }
  var stockInput by rememberSaveable(product.id) { mutableStateOf(product.stockQty.toString()) }

  val packPrice = product.priceFor(selectedVariant)
  val unitLabel = if (product.isWeightBased) selectedVariant.label else product.baseUnit

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(product.displayName(language), maxLines = 1) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("product_detail_back")) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(id = R.string.cd_navigate_back),
            )
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = KgsForest,
            titleContentColor = PureWhite,
            navigationIconContentColor = PureWhite,
          ),
      )
    }
  ) { innerPadding ->
    Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.TopCenter) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 680.dp)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .height(220.dp)
              .clip(RoundedCornerShape(20.dp))
              .background(KgsMintBg),
          contentAlignment = Alignment.Center,
        ) {
          if (!product.imageUrl.isNullOrBlank()) {
            AsyncImage(
              model = product.imageUrl,
              contentDescription = product.displayName(language),
              contentScale = ContentScale.Crop,
              modifier = Modifier.matchParentSize(),
            )
          } else {
            Icon(
              imageVector = Icons.Outlined.Inventory2,
              contentDescription = product.displayName(language),
              tint = KgsEmerald,
              modifier = Modifier.size(64.dp),
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = KgsMintContainer,
          ) {
            Text(
              text = product.displayCategory(language),
              style = MaterialTheme.typography.labelMedium,
              color = KgsForest,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            )
          }
          Text(
            text =
              if (product.isAvailable && product.stockQty > 0) "${strings.inStock} (${product.stockQty})"
              else strings.outOfStock,
            style = MaterialTheme.typography.labelLarge,
            color = if (product.isAvailable && product.stockQty > 0) KgsEmerald else StatusError,
          )
        }

        Text(
          text = product.displayName(language),
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Bold,
        )

        if (product.description.isNotBlank()) {
          Text(
            text = product.description,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        if (!product.shopName.isNullOrBlank()) {
          Text(
            text = "${strings.soldBy}: ${product.shopName}",
            style = MaterialTheme.typography.bodyMedium,
            color = KgsForest,
          )
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          border = BorderStroke(1.dp, OutlineSubtle),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            if (product.isWeightBased) {
              Text(
                text = strings.selectVariant,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )
              QuantityVariantSelector(
                selectedVariant = selectedVariant,
                priceProvider = { product.priceFor(it) },
                variants = product.applicableVariants(),
                onSelect = { selectedVariant = it },
              )
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "${strings.pricePerPack} ($unitLabel)",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = formatInr(packPrice),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = KgsForest,
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedButton(
            onClick = { onAddToRation(product, selectedVariant) },
            shape = RoundedCornerShape(14.dp),
            modifier =
              Modifier.weight(1f)
                .height(52.dp)
                .minimumInteractiveComponentSize()
                .testTag("detail_add_ration_button"),
          ) {
            Icon(Icons.Filled.BookmarkAdd, contentDescription = strings.addToRation)
            Spacer(modifier = Modifier.padding(4.dp))
            Text(strings.addToRation, maxLines = 1)
          }

          Button(
            onClick = { onAddToCart(product, selectedVariant) },
            enabled = product.isAvailable && product.stockQty > 0,
            colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
            shape = RoundedCornerShape(14.dp),
            modifier =
              Modifier.weight(1f)
                .height(52.dp)
                .minimumInteractiveComponentSize()
                .testTag("detail_add_cart_button"),
          ) {
            Icon(Icons.Filled.ShoppingBag, contentDescription = strings.addToCart)
            Spacer(modifier = Modifier.padding(4.dp))
            Text(strings.addToCart, maxLines = 1)
          }
        }

        if (canEditPrice) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, KgsEmerald.copy(alpha = 0.4f)),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(Icons.Filled.Edit, contentDescription = strings.editPrice, tint = KgsEmerald)
                Text(
                  text = "${strings.editPrice} (${product.baseUnit})",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
              }
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                  value = priceInput,
                  onValueChange = { priceInput = it },
                  label = { Text(strings.editPrice) },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                  singleLine = true,
                  modifier = Modifier.weight(1f).testTag("detail_edit_price_input"),
                )
                OutlinedTextField(
                  value = stockInput,
                  onValueChange = { stockInput = it },
                  label = { Text("Stock") },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  singleLine = true,
                  modifier = Modifier.weight(1f).testTag("detail_edit_stock_input"),
                )
              }
              Button(
                onClick = { onSavePriceAndStock(product, priceInput, stockInput) },
                colors = ButtonDefaults.buttonColors(containerColor = KgsForest),
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("detail_save_price_button"),
              ) {
                Text(strings.savePrice)
              }
            }
          }
        }
      }
    }
  }
}
