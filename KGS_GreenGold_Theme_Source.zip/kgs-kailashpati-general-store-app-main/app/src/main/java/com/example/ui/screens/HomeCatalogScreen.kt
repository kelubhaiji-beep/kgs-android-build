package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.ui.components.GroceryProductCard
import com.example.ui.components.SupabaseStatusCard
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.viewmodel.KgsUiState

@Composable
fun HomeCatalogScreen(
  state: KgsUiState,
  strings: AppStrings,
  onSearchChange: (String) -> Unit,
  onCategorySelect: (String) -> Unit,
  onShopSelect: (String) -> Unit,
  onToggleInStock: () -> Unit,
  onRefreshCatalog: () -> Unit,
  onProductClick: (Product) -> Unit,
  onAddToCart: (Product, QuantityVariant) -> Unit,
  onUpdateCartQty: (Product, QuantityVariant, Int) -> Unit,
  onOpenSchemaInspector: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var quickVariant by rememberSaveable { mutableStateOf(QuantityVariant.KG1) }
  val filtered = state.filteredProducts

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val columns =
      when {
        maxWidth >= 900.dp -> 4
        maxWidth >= 600.dp -> 3
        else -> 2
      }

    LazyVerticalGrid(
      columns = GridCells.Fixed(columns),
      contentPadding = PaddingValues(16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxSize().testTag("catalog_product_grid"),
    ) {
      item(span = { GridItemSpan(columns) }) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text(strings.searchHint) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = strings.searchHint,
                tint = KgsEmerald,
              )
            },
            trailingIcon = {
              if (state.searchQuery.isNotEmpty()) {
                IconButton(
                  onClick = { onSearchChange("") },
                  modifier = Modifier.testTag("clear_search_button"),
                ) {
                  Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = stringResource(id = R.string.cd_clear_search),
                  )
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedContainerColor = PureWhite,
                unfocusedContainerColor = PureWhite,
                focusedBorderColor = KgsEmerald,
                unfocusedBorderColor = OutlineSubtle,
              ),
            modifier = Modifier.fillMaxWidth().testTag("catalog_search_input"),
          )

          if (!state.isSupabaseConfigured || state.catalogError != null) {
            SupabaseStatusCard(
              title =
                if (!state.isSupabaseConfigured) strings.supabaseNotConfiguredTitle
                else "Supabase Connection Error",
              body =
                if (!state.isSupabaseConfigured) {
                  state.catalogError ?: strings.supabaseNotConfiguredBody
                } else {
                  "${state.catalogError}\n${com.example.config.SupabaseConfig.runtimeDiagnosticSummary}"
                },
              buttonLabel =
                if (state.isSupabaseConfigured) strings.retryConnection else strings.inspectSchema,
              isConnected = false,
              onAction =
                if (state.isSupabaseConfigured) onRefreshCatalog else onOpenSchemaInspector,
            )
          } else if (!state.isLoadingCatalog && state.products.isEmpty()) {
            SupabaseStatusCard(
              title = "Connected to Supabase (${state.resolvedProductsTable})",
              body =
                "Connected, but 0 products were returned. Verify that public.${state.resolvedProductsTable} has rows and an RLS SELECT policy for anon/authenticated.",
              buttonLabel = strings.inspectSchema,
              isConnected = false,
              onAction = onOpenSchemaInspector,
            )
          }

          // Quick pack weight selector (100g, 200g, 250g, 500g, 1kg, 2kg, 5kg)
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            items(QuantityVariant.standardGroceryOptions) { variant ->
              FilterChip(
                selected = quickVariant == variant,
                onClick = { quickVariant = variant },
                label = { Text(variant.label) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = KgsEmerald,
                    selectedLabelColor = PureWhite,
                  ),
                modifier = Modifier.minimumInteractiveComponentSize(),
              )
            }
          }

          // Multi-shop filter chips when multiple local shops exist
          if (state.publicShops.size > 1) {
            LazyRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              item {
                FilterChip(
                  selected = state.selectedShopId == KgsUiState.ALL_SHOP_KEY,
                  onClick = { onShopSelect(KgsUiState.ALL_SHOP_KEY) },
                  label = { Text(strings.allShops) },
                  colors =
                    FilterChipDefaults.filterChipColors(
                      selectedContainerColor = KgsEmerald,
                      selectedLabelColor = PureWhite,
                    ),
                  modifier = Modifier.minimumInteractiveComponentSize(),
                )
              }
              items(state.publicShops, key = { it.id.ifBlank { it.shopName } }) { shop ->
                FilterChip(
                  selected = state.selectedShopId == shop.id,
                  onClick = { onShopSelect(shop.id) },
                  label = { Text(shop.shopName) },
                  colors =
                    FilterChipDefaults.filterChipColors(
                      selectedContainerColor = KgsEmerald,
                      selectedLabelColor = PureWhite,
                    ),
                  modifier = Modifier.minimumInteractiveComponentSize(),
                )
              }
            }
          }

          // Category chips (Hindi + English)
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            item {
              FilterChip(
                selected = state.selectedCategory == KgsUiState.ALL_CATEGORY_KEY,
                onClick = { onCategorySelect(KgsUiState.ALL_CATEGORY_KEY) },
                label = { Text(strings.allCategories) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = KgsForest,
                    selectedLabelColor = PureWhite,
                  ),
                modifier = Modifier.minimumInteractiveComponentSize().testTag("category_chip_all"),
              )
            }
            items(state.categories, key = { it.id }) { cat ->
              FilterChip(
                selected = state.selectedCategory.equals(cat.name, ignoreCase = true),
                onClick = { onCategorySelect(cat.name) },
                label = {
                  val countSuffix = if (cat.productCount > 0) " (${cat.productCount})" else ""
                  Text("${cat.displayName(state.language)}$countSuffix")
                },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = KgsForest,
                    selectedLabelColor = PureWhite,
                  ),
                modifier = Modifier.minimumInteractiveComponentSize().testTag("category_chip_${cat.id}"),
              )
            }
          }

          // Count, In-Stock filter, and Refresh row
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = strings.showingProductsCount(filtered.size, state.totalCatalogCount),
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.weight(1f),
            )
            FilterChip(
              selected = state.inStockOnly,
              onClick = onToggleInStock,
              label = { Text(strings.inStock) },
              modifier = Modifier.testTag("in_stock_filter_chip"),
            )
            IconButton(
              onClick = onRefreshCatalog,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("refresh_catalog_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = strings.retryConnection,
                tint = KgsEmerald,
              )
            }
          }
        }
      }

      if (!state.isSupabaseConfigured || state.catalogError != null) {
        // Status card already shown above search filters
      } else if (state.isLoadingCatalog) {
        item(span = { GridItemSpan(columns) }) {
          Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp),
            contentAlignment = Alignment.Center,
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              CircularProgressIndicator(color = KgsEmerald)
              Text(
                text = strings.loadingProducts,
                style = MaterialTheme.typography.bodyMedium,
              )
            }
          }
        }
      } else if (filtered.isEmpty()) {
        item(span = { GridItemSpan(columns) }) {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = PureWhite,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.Storefront,
                contentDescription = null,
                tint = KgsEmerald,
                modifier = Modifier.height(44.dp),
              )
              Text(
                text = "No matching products found",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )
              TextButton(onClick = {
                onSearchChange("")
                onCategorySelect(KgsUiState.ALL_CATEGORY_KEY)
              }) {
                Text("Reset filters")
              }
            }
          }
        }
      } else {
        items(filtered, key = { it.id }) { product ->
          val cartQty =
            state.cartItems
              .firstOrNull { it.product.id == product.id && it.variant == quickVariant }
              ?.quantity ?: 0
          GroceryProductCard(
            product = product,
            language = state.language,
            strings = strings,
            selectedVariant = quickVariant,
            cartQty = cartQty,
            onCardClick = { onProductClick(product) },
            onAddToCart = { onAddToCart(product, quickVariant) },
            onUpdateQty = { qty -> onUpdateCartQty(product, quickVariant, qty) },
          )
        }
      }

      item(span = { GridItemSpan(columns) }) { Spacer(modifier = Modifier.height(16.dp)) }
    }
  }
}
