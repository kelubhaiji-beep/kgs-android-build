package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.UserRole
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.KgsUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
  state: KgsUiState,
  strings: AppStrings,
  onBack: () -> Unit,
  onInspectSchema: () -> Unit,
  onRefreshAdminData: () -> Unit,
  onApproveShop: (String, Boolean) -> Unit,
  onUpdateUserRole: (String, UserRole) -> Unit,
  onToggleUserActive: (String, Boolean) -> Unit,
  onUpdateOrderStatus: (String, OrderStatus) -> Unit,
  onVerifyUpiPayment: (String, Boolean) -> Unit,
  onMarkCodCollected: (String) -> Unit,
  onUpdateRefund: (String, String) -> Unit,
  onAssignDeliveryPartner: (String, String) -> Unit,
  onSaveProduct: (Product, String, String) -> Unit,
  onDeleteProduct: (String) -> Unit,
) {
  BackHandler(onBack = onBack)

  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  var orderFilter by rememberSaveable { mutableStateOf("all") }
  var userRoleFilter by rememberSaveable { mutableStateOf("all") }
  var productSearch by rememberSaveable { mutableStateOf("") }
  var editingProductId by rememberSaveable { mutableStateOf<String?>(null) }
  var showAddProductDialog by rememberSaveable { mutableStateOf(false) }

  val isAdmin = state.authSession?.role == UserRole.ADMIN
  val deliveryPartners = state.profiles.filter { it.role == UserRole.DELIVERY_PARTNER && it.isActive }

  val tabs =
    listOf(
      strings.schemaInspectorTab,
      strings.dashboardTab,
      strings.ordersTab,
      strings.productsTab,
      strings.shopsTab,
      strings.categoriesTab,
      strings.customersTab,
      strings.deliveryPartnersTab,
    )

  if (showAddProductDialog) {
    AdminProductDialog(
      existing = null,
      shops = state.shops,
      strings = strings,
      onDismiss = { showAddProductDialog = false },
      onSave = { prod, price, stock ->
        onSaveProduct(prod, price, stock)
        showAddProductDialog = false
      },
    )
  }

  editingProductId?.let { pid ->
    state.products.firstOrNull { it.id == pid }?.let { target ->
      AdminProductDialog(
        existing = target,
        shops = state.shops,
        strings = strings,
        onDismiss = { editingProductId = null },
        onSave = { prod, price, stock ->
          onSaveProduct(prod, price, stock)
          editingProductId = null
        },
      )
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.adminPanel) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(id = R.string.cd_navigate_back),
            )
          }
        },
        actions = {
          IconButton(onClick = onRefreshAdminData) {
            Icon(Icons.Filled.Refresh, contentDescription = strings.retryConnection)
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = KgsForest,
            titleContentColor = PureWhite,
            navigationIconContentColor = PureWhite,
            actionIconContentColor = PureWhite,
          ),
      )
    }
  ) { innerPadding ->
    Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
        tabs.forEachIndexed { idx, label ->
          Tab(
            selected = selectedTab == idx,
            onClick = { selectedTab = idx },
            text = { Text(label) },
          )
        }
      }

      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
          modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          if (!isAdmin) {
            item {
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = StatusWarning.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth().testTag("admin_role_notice"),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(Icons.Filled.Lock, contentDescription = null, tint = StatusWarning)
                  Text(
                    text =
                      "Admin sign-in is required for sensitive operations (Kotak UPI bank verification, refunds, user roles, shop approval). Enforced by Supabase RLS.",
                    style = MaterialTheme.typography.bodySmall,
                  )
                }
              }
            }
          }

          when (selectedTab) {
            0 -> {
              item {
                Surface(shape = RoundedCornerShape(12.dp), color = KgsMintContainer) {
                  Column(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                  ) {
                    Text(
                      text =
                        if (state.isSupabaseConfigured) "Runtime Secrets Loaded"
                        else "Secrets Not Configured",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = KgsForest,
                    )
                    Text(
                      text = com.example.config.SupabaseConfig.runtimeDiagnosticSummary,
                      style = MaterialTheme.typography.bodySmall,
                      color = KgsForest,
                    )
                  }
                }
              }
              item {
                Button(
                  onClick = onInspectSchema,
                  enabled = !state.isInspectingSchema,
                  colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                  modifier =
                    Modifier.fillMaxWidth()
                      .minimumInteractiveComponentSize()
                      .testTag("admin_inspect_schema_button"),
                ) {
                  if (state.isInspectingSchema) {
                    CircularProgressIndicator(color = PureWhite)
                  } else {
                    Text("Inspect Tables Safely (Client RLS Check)")
                  }
                }
              }
              val inspection = state.schemaInspection
              if (inspection == null) {
                item {
                  Text(
                    text =
                      "Configure SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets, then tap Inspect to verify tables, columns, and RLS protection.",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              } else if (!inspection.isConnected) {
                item {
                  Surface(shape = RoundedCornerShape(12.dp), color = StatusError.copy(alpha = 0.1f)) {
                    Text(
                      text = inspection.errorMessage ?: "Not connected",
                      color = StatusError,
                      style = MaterialTheme.typography.bodyMedium,
                      modifier = Modifier.padding(14.dp),
                    )
                  }
                }
              } else {
                item {
                  Surface(shape = RoundedCornerShape(12.dp), color = KgsMintContainer) {
                    Column(
                      modifier = Modifier.fillMaxWidth().padding(12.dp),
                      verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Text(
                        text =
                          "Connected at ${inspection.inspectedAt} • ${inspection.tables.size} tables detected",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = KgsForest,
                      )
                      Text(
                        text = inspection.inspectionMethod,
                        style = MaterialTheme.typography.bodySmall,
                        color = KgsForest,
                      )
                      inspection.detectedMappings.forEach { (logical, physical) ->
                        Text(
                          text = "Mapped $logical -> $physical",
                          style = MaterialTheme.typography.bodySmall,
                        )
                      }
                    }
                  }
                }
                items(inspection.tables, key = { it.tableName }) { table ->
                  Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, OutlineSubtle),
                  ) {
                    Column(
                      modifier = Modifier.padding(12.dp),
                      verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                      ) {
                        Text(
                          text = table.tableName,
                          style = MaterialTheme.typography.titleSmall,
                          fontWeight = FontWeight.Bold,
                          color = KgsForest,
                        )
                        Text(
                          text = table.accessStatus,
                          style = MaterialTheme.typography.labelSmall,
                          color = KgsEmerald,
                        )
                      }
                      Text(
                        text =
                          if (table.columns.isNotEmpty()) {
                            table.columns.joinToString(", ") { "${it.name}: ${it.type}" }
                          } else {
                            "Columns hidden until rows are readable under your RLS policy."
                          },
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                  }
                }
              }
            }

            1 -> {
              item {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  AdminMetricCard(
                    title = "Total Order Sales",
                    value = formatInr(state.totalOrderVolume),
                    subtitle = "${state.orders.size} total orders",
                    modifier = Modifier.weight(1f),
                  )
                  AdminMetricCard(
                    title = "Verified Revenue",
                    value = formatInr(state.verifiedAndCollectedRevenue),
                    subtitle = "UPI verified + COD collected",
                    modifier = Modifier.weight(1f),
                  )
                }
              }
              item {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  AdminMetricCard(
                    title = "Pending Kotak UPI",
                    value = state.pendingUpiVerificationOrdersCount.toString(),
                    subtitle = "Needs bank check",
                    modifier = Modifier.weight(1f),
                  )
                  AdminMetricCard(
                    title = "Catalog Health",
                    value = "${state.products.size}",
                    subtitle = "${state.outOfStockProductsCount} out of stock",
                    modifier = Modifier.weight(1f),
                  )
                }
              }
              item {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  AdminMetricCard(
                    title = "Registered Shops",
                    value = state.shops.size.toString(),
                    subtitle = "${state.shops.count { it.isApproved }} approved",
                    modifier = Modifier.weight(1f),
                  )
                  AdminMetricCard(
                    title = "Users & Staff",
                    value = state.profiles.size.toString(),
                    subtitle = "${deliveryPartners.size} active delivery partners",
                    modifier = Modifier.weight(1f),
                  )
                }
              }
            }

            2 -> {
              item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  val filters =
                    listOf(
                      "all" to "All (${state.orders.size})",
                      "pending_upi" to "Pending UPI (${state.pendingUpiVerificationOrdersCount})",
                      "cod_pending" to "COD Pending",
                      "cancelled" to "Cancelled / Refunds",
                    )
                  items(filters) { (key, label) ->
                    FilterChip(
                      selected = orderFilter == key,
                      onClick = { orderFilter = key },
                      label = { Text(label) },
                    )
                  }
                }
              }
              val filteredOrders =
                when (orderFilter) {
                  "pending_upi" ->
                    state.orders.filter {
                      it.paymentMethod == PaymentMethod.UPI &&
                        it.parsedPaymentStatus == PaymentStatus.PENDING_VERIFICATION
                    }
                  "cod_pending" ->
                    state.orders.filter {
                      it.paymentMethod == PaymentMethod.COD &&
                        it.parsedPaymentStatus == PaymentStatus.COD_PENDING
                    }
                  "cancelled" ->
                    state.orders.filter {
                      it.status == OrderStatus.CANCELLED || it.refundStatus != "none"
                    }
                  else -> state.orders
                }
              if (filteredOrders.isEmpty()) {
                item { Text("No orders match this filter.", style = MaterialTheme.typography.bodyMedium) }
              } else {
                items(filteredOrders, key = { it.id.ifBlank { it.orderNumber } }) { order ->
                  AdminOrderVerificationCard(
                    order = order,
                    language = state.language,
                    deliveryPartners = deliveryPartners,
                    isAdmin = isAdmin,
                    onVerifyUpi = onVerifyUpiPayment,
                    onMarkCodCollected = onMarkCodCollected,
                    onUpdateRefund = onUpdateRefund,
                    onAssignPartner = onAssignDeliveryPartner,
                    onUpdateStatus = onUpdateOrderStatus,
                  )
                }
              }
            }

            3 -> {
              item {
                Button(
                  onClick = { showAddProductDialog = true },
                  enabled = isAdmin,
                  colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                  modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Filled.Add, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Add Product to Supabase")
                }
              }
              item {
                OutlinedTextField(
                  value = productSearch,
                  onValueChange = { productSearch = it },
                  leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                  label = { Text("Filter products by name or category") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                )
              }
              val matchingProducts =
                state.products.filter {
                  productSearch.isBlank() ||
                    it.name.contains(productSearch, ignoreCase = true) ||
                    it.category.contains(productSearch, ignoreCase = true)
                }
              item {
                Text(
                  text = "Showing ${matchingProducts.take(200).size} of ${state.products.size} products",
                  style = MaterialTheme.typography.labelLarge,
                  color = KgsForest,
                )
              }
              items(matchingProducts.take(200), key = { it.id }) { prod ->
                Card(
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(containerColor = PureWhite),
                  border = BorderStroke(1.dp, OutlineSubtle),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(prod.name, fontWeight = FontWeight.SemiBold)
                      Text(
                        "${prod.category} • ${formatInr(prod.basePrice)}/${prod.baseUnit} • Stock: ${prod.stockQty}",
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                    Row {
                      IconButton(onClick = { editingProductId = prod.id }, enabled = isAdmin) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit product", tint = KgsForest)
                      }
                      IconButton(onClick = { onDeleteProduct(prod.id) }, enabled = isAdmin) {
                        Icon(
                          Icons.Filled.DeleteOutline,
                          contentDescription = "Delete product",
                          tint = StatusError,
                        )
                      }
                    }
                  }
                }
              }
            }

            4 -> {
              items(state.shops, key = { it.id.ifBlank { it.shopName } }) { shop ->
                Card(
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(containerColor = PureWhite),
                  border = BorderStroke(1.dp, OutlineSubtle),
                ) {
                  Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                  ) {
                    Text(
                      text = "${shop.shopName} • Owner: ${shop.ownerName}",
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                    )
                    Text(
                      text = "${shop.phone} • ${shop.address}, ${shop.city} - ${shop.pincode}",
                      style = MaterialTheme.typography.bodySmall,
                    )
                    Button(
                      onClick = { onApproveShop(shop.id, !shop.isApproved) },
                      enabled = isAdmin,
                      colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Text(if (shop.isApproved) "Suspend Shop" else "Approve Shop")
                    }
                  }
                }
              }
            }

            5 -> {
              items(state.categories, key = { it.id }) { cat ->
                Card(
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(containerColor = PureWhite),
                  border = BorderStroke(1.dp, OutlineSubtle),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Column {
                      Text(cat.displayName(state.language), fontWeight = FontWeight.SemiBold)
                      if (!cat.nameHi.isNullOrBlank()) {
                        Text(cat.nameHi, style = MaterialTheme.typography.bodySmall, color = KgsEmerald)
                      }
                    }
                    Text("${cat.productCount} items", color = KgsForest)
                  }
                }
              }
            }

            6 -> {
              item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  val roleFilters =
                    listOf(
                      "all" to "All Users",
                      "customer" to "Customers",
                      "distributor" to "Distributors",
                      "admin" to "Admins",
                    )
                  items(roleFilters) { (key, label) ->
                    FilterChip(
                      selected = userRoleFilter == key,
                      onClick = { userRoleFilter = key },
                      label = { Text(label) },
                    )
                  }
                }
              }
              val nonDeliveryUsers = state.profiles.filter { it.role != UserRole.DELIVERY_PARTNER }
              val filteredUsers =
                when (userRoleFilter) {
                  "customer" -> nonDeliveryUsers.filter { it.role == UserRole.CUSTOMER }
                  "distributor" -> nonDeliveryUsers.filter { it.role == UserRole.DISTRIBUTOR }
                  "admin" -> nonDeliveryUsers.filter { it.role == UserRole.ADMIN }
                  else -> nonDeliveryUsers
                }
              if (filteredUsers.isEmpty()) {
                item { Text("No user profiles found for this filter.", style = MaterialTheme.typography.bodyMedium) }
              } else {
                items(filteredUsers, key = { it.id }) { profile ->
                  AdminProfileCard(
                    profile = profile,
                    isAdmin = isAdmin,
                    onUpdateRole = onUpdateUserRole,
                    onToggleActive = onToggleUserActive,
                  )
                }
              }
            }

            7 -> {
              val partners = state.profiles.filter { it.role == UserRole.DELIVERY_PARTNER }
              if (partners.isEmpty()) {
                item {
                  Text(
                    text = "No delivery partners yet. Promote a user in the Customers tab to Delivery Partner.",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              } else {
                items(partners, key = { it.id }) { partner ->
                  AdminProfileCard(
                    profile = partner,
                    isAdmin = isAdmin,
                    onUpdateRole = onUpdateUserRole,
                    onToggleActive = onToggleUserActive,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
