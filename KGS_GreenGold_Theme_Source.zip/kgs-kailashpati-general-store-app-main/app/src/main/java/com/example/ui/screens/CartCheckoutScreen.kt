package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.CustomerAddress
import com.example.model.Order
import com.example.model.PaymentMethod
import com.example.model.QuantityVariant
import com.example.ui.components.KotakUpiQrCard
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.KgsUiState
import com.example.util.ValidationUtils

@Composable
fun CartCheckoutScreen(
  state: KgsUiState,
  strings: AppStrings,
  onBrowseProducts: () -> Unit,
  onUpdateQty: (String, QuantityVariant, Int) -> Unit,
  onSelectAddress: (String) -> Unit,
  onSaveAddress: (CustomerAddress) -> Unit,
  onShowMessage: (String) -> Unit,
  onPlaceOrder: (PaymentMethod, String, Boolean, (Order) -> Unit) -> Unit,
  onOrderSuccessNavigate: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val clipboard = LocalClipboardManager.current
  var selectedPayment by rememberSaveable { mutableStateOf(PaymentMethod.COD) }
  var upiReferenceInput by rememberSaveable { mutableStateOf("") }
  var customerMarkedPaid by rememberSaveable { mutableStateOf(false) }
  var showAddAddressDialog by rememberSaveable { mutableStateOf(false) }
  val draftOrderRef = remember(state.cartCount, state.totalPayable) {
    "KGS${System.currentTimeMillis().toString().takeLast(6)}"
  }

  if (showAddAddressDialog) {
    AddAddressDialog(
      strings = strings,
      onDismiss = { showAddAddressDialog = false },
      onSave = {
        onSaveAddress(it)
        showAddAddressDialog = false
      },
    )
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    if (state.cartItems.isEmpty()) {
      Column(
        modifier = Modifier.fillMaxSize().widthIn(max = 520.dp).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Icon(
          imageVector = Icons.Outlined.ShoppingCart,
          contentDescription = strings.emptyCartTitle,
          tint = KgsEmerald,
          modifier = Modifier.size(72.dp),
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = strings.emptyCartTitle,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = strings.emptyCartBody,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
          onClick = onBrowseProducts,
          colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("empty_cart_browse_button"),
        ) {
          Text(strings.browseProducts)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        item {
          Text(
            text = strings.cartTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
          )
        }

        items(state.cartItems, key = { "${it.product.id}_${it.variant.label}" }) { item ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = item.product.displayName(state.language),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.SemiBold,
                )
                Text(
                  text = "${item.variantDisplayLabel()} • ${formatInr(item.unitPrice)} each",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                  text = formatInr(item.lineTotal),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = KgsForest,
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = {
                    onUpdateQty(item.product.id, item.variant, item.quantity - 1)
                  },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector =
                      if (item.quantity == 1) Icons.Filled.DeleteOutline else Icons.Filled.Remove,
                    contentDescription = "Decrease quantity",
                  )
                }
                Text(
                  text = item.quantity.toString(),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                IconButton(
                  onClick = {
                    onUpdateQty(item.product.id, item.variant, item.quantity + 1)
                  },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(imageVector = Icons.Filled.Add, contentDescription = "Increase quantity")
                }
              }
            }
          }
        }

        // Delivery Address section
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Icon(Icons.Filled.LocationOn, contentDescription = null, tint = KgsEmerald)
                  Text(
                    text = strings.deliveryAddress,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                  )
                }
                TextButton(
                  onClick = { showAddAddressDialog = true },
                  modifier = Modifier.testTag("checkout_add_address_button"),
                ) {
                  Text(strings.addNewAddress)
                }
              }

              if (state.addresses.isEmpty()) {
                OutlinedButton(
                  onClick = { showAddAddressDialog = true },
                  modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
                ) {
                  Text(strings.selectOrAddAddress)
                }
              } else {
                state.addresses.forEach { addr ->
                  val isSelected = state.selectedAddress?.id == addr.id
                  Surface(
                    onClick = { onSelectAddress(addr.id) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) KgsMintContainer else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Row(
                      modifier = Modifier.padding(10.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      RadioButton(selected = isSelected, onClick = { onSelectAddress(addr.id) })
                      Column(modifier = Modifier.weight(1f)) {
                        Text(
                          text = "${addr.label} • ${addr.fullName} (${addr.phone})",
                          style = MaterialTheme.typography.labelLarge,
                        )
                        Text(
                          text = addr.formatted(),
                          style = MaterialTheme.typography.bodySmall,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // Payment Method: ONLY Cash on Delivery (COD) and Kotak UPI
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Text(
                text = strings.paymentMethod,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )

              PaymentMethod.entries.forEach { method ->
                val selected = selectedPayment == method
                Surface(
                  onClick = { selectedPayment = method },
                  shape = RoundedCornerShape(12.dp),
                  color = if (selected) KgsMintContainer else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.fillMaxWidth().testTag("payment_${method.dbValue}"),
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                  ) {
                    RadioButton(selected = selected, onClick = { selectedPayment = method })
                    Icon(
                      imageVector =
                        if (method == PaymentMethod.COD) Icons.Filled.Payments
                        else Icons.Filled.QrCode2,
                      contentDescription = null,
                      tint = KgsEmerald,
                    )
                    Text(
                      text =
                        if (state.language == AppLanguage.HINDI) method.labelHi else method.labelEn,
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.SemiBold,
                    )
                  }
                }
              }

              if (selectedPayment == PaymentMethod.COD) {
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = KgsMintContainer.copy(alpha = 0.7f),
                ) {
                  Text(
                    text = strings.codNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = KgsForest,
                    modifier = Modifier.padding(10.dp),
                  )
                }
              } else {
                KotakUpiQrCard(
                  upiVpa = state.merchantUpiVpa,
                  payeeName = state.merchantPayeeName,
                  amount = state.totalPayable,
                  orderRef = draftOrderRef,
                  strings = strings,
                  onCopyUpiId = {
                    clipboard.setText(AnnotatedString(state.merchantUpiVpa))
                    onShowMessage(strings.upiIdCopied)
                  },
                  onOpenUpiApp = {
                    val uri =
                      ValidationUtils.buildUpiPaymentUri(
                        merchantVpa = state.merchantUpiVpa,
                        merchantName = state.merchantPayeeName,
                        orderRef = draftOrderRef,
                        amount = state.totalPayable,
                      )
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    runCatching { context.startActivity(intent) }.onFailure {
                      onShowMessage("No UPI app found. Scan the QR code or copy ${state.merchantUpiVpa}.")
                    }
                  },
                )

                Surface(
                  onClick = { customerMarkedPaid = !customerMarkedPaid },
                  shape = RoundedCornerShape(10.dp),
                  color = KgsMintContainer.copy(alpha = 0.55f),
                  modifier = Modifier.fillMaxWidth().testTag("upi_i_have_paid_toggle"),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Checkbox(
                      checked = customerMarkedPaid,
                      onCheckedChange = { customerMarkedPaid = it },
                    )
                    Text(
                      text = strings.iHavePaidLabel,
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.SemiBold,
                    )
                  }
                }

                OutlinedTextField(
                  value = upiReferenceInput,
                  onValueChange = { upiReferenceInput = it },
                  label = { Text(strings.upiRefLabel) },
                  placeholder = { Text(strings.upiRefHint) },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth().testTag("upi_reference_input"),
                )

                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = StatusWarning.copy(alpha = 0.14f),
                ) {
                  Text(
                    text = strings.upiPendingVerificationNotice,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(10.dp),
                  )
                }
              }
            }
          }
        }

        // Totals & Place Order
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              SummaryRow(strings.subtotal, formatInr(state.cartSubtotal))
              SummaryRow(
                strings.deliveryFee,
                if (state.deliveryFee == 0.0) "FREE" else formatInr(state.deliveryFee),
              )
              HorizontalDivider()
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = strings.totalPayable,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text = formatInr(state.totalPayable),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = KgsForest,
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Button(
                onClick = {
                  onPlaceOrder(selectedPayment, upiReferenceInput, customerMarkedPaid) {
                    onOrderSuccessNavigate()
                  }
                },
                enabled = !state.isPlacingOrder,
                colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                shape = RoundedCornerShape(14.dp),
                modifier =
                  Modifier.fillMaxWidth()
                    .height(52.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("place_order_button"),
              ) {
                if (state.isPlacingOrder) {
                  CircularProgressIndicator(color = PureWhite, modifier = Modifier.size(22.dp))
                } else {
                  Text(strings.placeOrder, style = MaterialTheme.typography.titleMedium)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SummaryRow(label: String, value: String) {
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium)
    Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
fun AddAddressDialog(
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (CustomerAddress) -> Unit,
) {
  var label by rememberSaveable { mutableStateOf("Home") }
  var fullName by rememberSaveable { mutableStateOf("") }
  var phone by rememberSaveable { mutableStateOf("") }
  var street by rememberSaveable { mutableStateOf("") }
  var landmark by rememberSaveable { mutableStateOf("") }
  var city by rememberSaveable { mutableStateOf("") }
  var pincode by rememberSaveable { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.addNewAddress) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = label,
          onValueChange = { label = it },
          label = { Text("Label (Home / Shop / Office)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it },
          label = { Text(strings.fullName) },
          singleLine = true,
          modifier = Modifier.testTag("address_name_input"),
        )
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text(strings.mobileNumber) },
          singleLine = true,
          modifier = Modifier.testTag("address_phone_input"),
        )
        OutlinedTextField(
          value = street,
          onValueChange = { street = it },
          label = { Text(strings.streetAddress) },
          singleLine = true,
          modifier = Modifier.testTag("address_street_input"),
        )
        OutlinedTextField(
          value = landmark,
          onValueChange = { landmark = it },
          label = { Text(strings.landmark) },
          singleLine = true,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = city,
            onValueChange = { city = it },
            label = { Text(strings.city) },
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("address_city_input"),
          )
          OutlinedTextField(
            value = pincode,
            onValueChange = { pincode = it },
            label = { Text(strings.pincode) },
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("address_pincode_input"),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            CustomerAddress(
              id = "",
              label = label.ifBlank { "Home" },
              fullName = fullName,
              phone = phone,
              streetAddress = street,
              landmark = landmark,
              city = city,
              pincode = pincode,
            )
          )
        },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
        modifier = Modifier.testTag("save_address_confirm_button"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}
