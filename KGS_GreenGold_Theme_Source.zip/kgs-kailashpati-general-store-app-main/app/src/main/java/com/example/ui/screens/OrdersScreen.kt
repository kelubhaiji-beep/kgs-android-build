package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.ui.components.OrderTimelineStepper
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.viewmodel.KgsUiState
import kotlinx.coroutines.delay

@Composable
fun OrdersScreen(
  state: KgsUiState,
  strings: AppStrings,
  onRefreshOrders: () -> Unit,
  onSubmitUpiRef: (String, String, Boolean) -> Unit,
  onCancelOrder: (String, String) -> Unit,
  onReorder: (Order) -> Unit,
  modifier: Modifier = Modifier,
) {
  var upiDialogOrderId by rememberSaveable { mutableStateOf<String?>(null) }
  var cancelDialogOrderId by rememberSaveable { mutableStateOf<String?>(null) }

  // Live order tracking refresh while customer views Orders screen
  LaunchedEffect(state.authSession?.userId) {
    if (state.authSession != null) {
      while (true) {
        delay(20_000L)
        onRefreshOrders()
      }
    }
  }

  upiDialogOrderId?.let { oid ->
    val targetOrder = state.orders.firstOrNull { it.id == oid }
    if (targetOrder != null) {
      SubmitUpiRefDialog(
        order = targetOrder,
        strings = strings,
        onDismiss = { upiDialogOrderId = null },
        onSave = { ref, markedPaid ->
          onSubmitUpiRef(targetOrder.id, ref, markedPaid)
          upiDialogOrderId = null
        },
      )
    }
  }

  cancelDialogOrderId?.let { oid ->
    val targetOrder = state.orders.firstOrNull { it.id == oid }
    if (targetOrder != null) {
      ConfirmCancelOrderDialog(
        orderNumber = targetOrder.orderNumber,
        strings = strings,
        onDismiss = { cancelDialogOrderId = null },
        onConfirm = { reason ->
          onCancelOrder(targetOrder.id, reason)
          cancelDialogOrderId = null
        },
      )
    }
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = strings.ordersTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
          )
          IconButton(
            onClick = onRefreshOrders,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("refresh_orders_button"),
          ) {
            Icon(Icons.Filled.Refresh, contentDescription = strings.retryConnection, tint = KgsEmerald)
          }
        }
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = KgsMintContainer,
          modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Filled.LocalShipping, contentDescription = null, tint = KgsForest)
            Text(
              text = strings.trackingNotice,
              style = MaterialTheme.typography.bodySmall,
              color = KgsForest,
            )
          }
        }
      }

      if (state.isLoadingOrders) {
        item {
          Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = KgsEmerald)
          }
        }
      } else if (state.orders.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, OutlineSubtle),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.Receipt,
                contentDescription = null,
                tint = KgsEmerald,
                modifier = Modifier.size(56.dp),
              )
              Text(
                text = strings.emptyOrdersBody,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      } else {
        items(state.orders, key = { it.id.ifBlank { it.orderNumber } }) { order ->
          OrderTrackingCard(
            order = order,
            language = state.language,
            strings = strings,
            onOpenUpiUpdate = { upiDialogOrderId = order.id },
            onCancelOrder = { cancelDialogOrderId = order.id },
            onReorder = { onReorder(order) },
          )
        }
      }
    }
  }
}

@Composable
fun OrderTrackingCard(
  order: Order,
  language: AppLanguage,
  strings: AppStrings,
  onOpenUpiUpdate: () -> Unit,
  onCancelOrder: () -> Unit,
  onReorder: () -> Unit,
) {
  val canCancel = order.status == OrderStatus.PLACED || order.status == OrderStatus.CONFIRMED
  val showUpiUpdate =
    order.paymentMethod == PaymentMethod.UPI &&
      order.parsedPaymentStatus == PaymentStatus.PENDING_VERIFICATION &&
      order.status != OrderStatus.CANCELLED

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, OutlineSubtle),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = order.orderNumber,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = if (order.paymentMethod == PaymentMethod.UPI) "Kotak UPI" else "COD",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
            )
            PaymentStatusBadge(
              paymentStatus = order.parsedPaymentStatus,
              language = language,
            )
          }
          if (!order.upiReference.isNullOrBlank()) {
            Text(
              text = "UTR: ${order.upiReference}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        Surface(
          shape = RoundedCornerShape(8.dp),
          color =
            if (order.status == OrderStatus.CANCELLED) StatusError.copy(alpha = 0.14f)
            else KgsMintContainer,
        ) {
          Text(
            text = if (language == AppLanguage.HINDI) order.status.labelHi else order.status.labelEn,
            style = MaterialTheme.typography.labelMedium,
            color = if (order.status == OrderStatus.CANCELLED) StatusError else KgsForest,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
          )
        }
      }

      OrderTimelineStepper(status = order.status, language = language)

      if (order.status == OrderStatus.CANCELLED && order.refundStatus != "none") {
        Text(
          text = "Refund Status: ${order.refundStatus.uppercase()}",
          style = MaterialTheme.typography.labelMedium,
          color = StatusError,
        )
      }

      HorizontalDivider()

      order.items.take(6).forEach { item ->
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(
            text = "${item.productName} (${item.variant.label}) x${item.quantity}",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f),
          )
          Text(
            text = formatInr(item.unitPrice * item.quantity),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = order.deliveryAddress,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )
        Text(
          text = formatInr(order.totalAmount),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = KgsForest,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (order.items.isNotEmpty()) {
          OutlinedButton(
            onClick = onReorder,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Filled.Replay, contentDescription = strings.reorderItems, modifier = Modifier.size(16.dp))
            Text(" ${strings.reorderItems}")
          }
        }
        if (showUpiUpdate) {
          OutlinedButton(
            onClick = onOpenUpiUpdate,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Text(
              when {
                !order.customerMarkedPaid && order.upiReference.isNullOrBlank() -> strings.markPaidOrUtr
                order.upiReference.isNullOrBlank() -> "Add UTR"
                else -> "Update UTR"
              }
            )
          }
        }
        if (canCancel) {
          TextButton(
            onClick = onCancelOrder,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Text(strings.cancelOrder, color = StatusError)
          }
        }
      }
    }
  }
}

@Composable
private fun SubmitUpiRefDialog(
  order: Order,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (String, Boolean) -> Unit,
) {
  var ref by rememberSaveable(order.id) { mutableStateOf(order.upiReference.orEmpty()) }
  var markedPaid by rememberSaveable(order.id) { mutableStateOf(true) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Kotak UPI Reference (${order.orderNumber})") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = strings.upiPendingVerificationNotice,
          style = MaterialTheme.typography.bodySmall,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          Checkbox(checked = markedPaid, onCheckedChange = { markedPaid = it })
          Text(strings.iHavePaidLabel, style = MaterialTheme.typography.bodyMedium)
        }
        OutlinedTextField(
          value = ref,
          onValueChange = { ref = it },
          label = { Text(strings.upiRefLabel) },
          placeholder = { Text(strings.upiRefHint) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(ref, markedPaid) },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
private fun ConfirmCancelOrderDialog(
  orderNumber: String,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit,
) {
  var reason by rememberSaveable(orderNumber) { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("${strings.confirmCancelTitle} ($orderNumber)") },
    text = {
      OutlinedTextField(
        value = reason,
        onValueChange = { reason = it },
        label = { Text(strings.cancelReasonHint) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(reason.ifBlank { "Cancelled by customer" }) },
        colors = ButtonDefaults.buttonColors(containerColor = StatusError),
      ) {
        Text(strings.cancelOrder)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}
