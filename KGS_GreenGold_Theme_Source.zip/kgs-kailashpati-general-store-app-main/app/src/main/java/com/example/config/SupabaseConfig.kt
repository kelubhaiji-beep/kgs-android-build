package com.example.config

import com.example.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

object SupabaseConfig {
  val url: String
    get() = normalizeUrl(BuildConfig.SUPABASE_URL)

  val anonKey: String
    get() = normalizeSecretValue(BuildConfig.SUPABASE_ANON_KEY)

  val merchantUpiVpa: String
    get() = normalizeSecretValue(BuildConfig.MERCHANT_UPI_VPA)

  val host: String
    get() = url.toHttpUrlOrNull()?.host ?: url.removePrefix("https://").removePrefix("http://").ifBlank { "UNSET" }

  val restBaseUrl: String
    get() = "$url/rest/v1"

  val authBaseUrl: String
    get() = "$url/auth/v1"

  val isSecretKeyDetected: Boolean
    get() = isSecretOrServiceRoleKey(anonKey)

  val isConfigured: Boolean
    get() = isValidConfig(url, anonKey)

  fun normalizeSecretValue(raw: String): String {
    var clean = raw.trim()
    if ((clean.startsWith("\"") && clean.endsWith("\"")) ||
      (clean.startsWith("'") && clean.endsWith("'"))
    ) {
      clean = clean.substring(1, clean.length - 1).trim()
    }
    return clean
  }

  fun normalizeUrl(raw: String): String {
    var clean = normalizeSecretValue(raw).trimEnd('/')
    for (suffix in listOf("/rest/v1", "/auth/v1", "/storage/v1")) {
      if (clean.endsWith(suffix, ignoreCase = true)) {
        clean = clean.substring(0, clean.length - suffix.length).trimEnd('/')
      }
    }
    return clean
  }

  fun isValidConfig(candidateUrl: String, candidateAnonKey: String): Boolean {
    val cleanUrl = normalizeUrl(candidateUrl)
    val cleanKey = normalizeSecretValue(candidateAnonKey)
    val parsed = cleanUrl.toHttpUrlOrNull()
    return parsed != null &&
      parsed.isHttps &&
      parsed.host.contains('.') &&
      !cleanUrl.contains("YOUR_SUPABASE", ignoreCase = true) &&
      cleanKey.isNotBlank() &&
      !cleanKey.contains("YOUR_SUPABASE", ignoreCase = true) &&
      !isSecretOrServiceRoleKey(cleanKey)
  }

  val configurationError: String?
    get() =
      when {
        isSecretKeyDetected ->
          "Security violation blocked: A Supabase secret/service_role key was placed in SUPABASE_ANON_KEY. Use only your publishable (sb_publishable_...) or anon key in the Android app."
        url.isBlank() || url.contains("YOUR_SUPABASE", ignoreCase = true) || url.toHttpUrlOrNull()?.isHttps != true ->
          "Invalid or missing SUPABASE_URL in AI Studio Secrets. Expected https://<project-ref>.supabase.co."
        anonKey.isBlank() || anonKey.contains("YOUR_SUPABASE", ignoreCase = true) ->
          "Add your Supabase publishable/anon key to SUPABASE_ANON_KEY in AI Studio Secrets."
        else -> null
      }

  val runtimeDiagnosticSummary: String
    get() {
      val keyHint =
        when {
          anonKey.isBlank() || anonKey.contains("YOUR_SUPABASE", ignoreCase = true) -> "UNSET"
          anonKey.length > 16 -> "${anonKey.take(15)}… (${anonKey.length} chars)"
          else -> "SET (${anonKey.length} chars)"
        }
      return "Project: $host • Key: $keyHint"
    }

  const val DEFAULT_KOTAK_UPI_VPA = "kailashyadav0@kotakbank"
  const val DEFAULT_KOTAK_PAYEE_NAME = "KAILASH YADAV"

  val isUpiConfigured: Boolean
    get() = isValidUpiVpa(merchantUpiVpa)

  fun isValidUpiVpa(vpa: String): Boolean {
    val clean = vpa.trim()
    return clean.contains("@") &&
      clean.length >= 5 &&
      !clean.equals("UNCONFIGURED", ignoreCase = true)
  }

  val effectiveUpiVpa: String
    get() = if (isUpiConfigured) merchantUpiVpa else DEFAULT_KOTAK_UPI_VPA

  val effectivePayeeName: String
    get() = DEFAULT_KOTAK_PAYEE_NAME

  fun isSecretOrServiceRoleKey(key: String): Boolean {
    val trimmed = key.trim()
    if (trimmed.isBlank()) return false
    if (trimmed.startsWith("sb_secret_", ignoreCase = true)) return true

    val parts = trimmed.split('.')
    if (parts.size == 3 && trimmed.startsWith("eyJ")) {
      val payloadJson = decodeBase64UrlToUtf8(parts[1])
      if (payloadJson != null &&
        (payloadJson.contains("\"role\":\"service_role\"", ignoreCase = true) ||
          payloadJson.contains("\"role\": \"service_role\"", ignoreCase = true))
      ) {
        return true
      }
    }
    return false
  }

  private fun decodeBase64UrlToUtf8(input: String): String? =
    runCatching {
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        val clean = input.trimEnd('=')
        val out = ArrayList<Byte>((clean.length * 3) / 4)
        var buffer = 0
        var bitsLeft = 0
        for (ch in clean) {
          val val6 = alphabet.indexOf(ch)
          if (val6 < 0) return null
          buffer = (buffer shl 6) or val6
          bitsLeft += 6
          if (bitsLeft >= 8) {
            bitsLeft -= 8
            out.add(((buffer shr bitsLeft) and 0xFF).toByte())
          }
        }
        String(out.toByteArray(), Charsets.UTF_8)
      }
      .getOrNull()
}
