package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException
import okhttp3.Dns

object PreferIpv4Dns : Dns {
  override fun lookup(hostname: String): List<InetAddress> {
    val addresses = Dns.SYSTEM.lookup(hostname)
    return addresses.sortedBy { if (it is Inet4Address) 0 else 1 }
  }
}

object NetworkUtils {
  fun isNetworkAvailable(context: Context): Boolean {
    return runCatching {
        val cm =
          context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
      }
      .getOrDefault(true)
  }

  fun formatConnectionError(error: Throwable, host: String): String {
    val detail = error.message?.trim().orEmpty()
    return when (error) {
      is UnknownHostException ->
        "DNS lookup failed for $host. Check emulator/device internet connectivity and DNS settings."
      is SocketTimeoutException ->
        "Connection to $host timed out. Check network speed or firewall and tap Retry."
      is SSLException ->
        "Secure TLS/SSL connection to $host failed (${detail.ifBlank { "certificate or handshake error" }})."
      is ConnectException ->
        "Unable to connect to $host (${detail.ifBlank { "connection refused" }})."
      else -> detail.ifBlank { "Failed to connect to Supabase ($host)" }
    }
  }
}
