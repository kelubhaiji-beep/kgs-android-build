package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.CustomerAddress
import com.example.model.UserRole
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsGold
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.viewmodel.KgsUiState

@Composable
fun AccountAndAuthScreen(
  state: KgsUiState,
  strings: AppStrings,
  onToggleLanguage: () -> Unit,
  onRequestOtp: (String) -> Unit,
  onVerifyOtp: (String, String) -> Unit,
  onSignInEmail: (String, String) -> Unit,
  onSignUpEmail: (String, String, String, String) -> Unit,
  onUpdateProfile: (String, String) -> Unit,
  onSignOut: () -> Unit,
  onSaveAddress: (CustomerAddress) -> Unit,
  onSetDefaultAddress: (String) -> Unit,
  onDeleteAddress: (String) -> Unit,
  onOpenDistributorPanel: () -> Unit,
  onOpenDeliveryPanel: () -> Unit,
  onOpenAdminPanel: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var authTab by rememberSaveable { mutableIntStateOf(0) }
  var phoneInput by rememberSaveable { mutableStateOf("") }
  var otpInput by rememberSaveable { mutableStateOf("") }
  var emailInput by rememberSaveable { mutableStateOf("") }
  var passwordInput by rememberSaveable { mutableStateOf("") }
  var fullNameInput by rememberSaveable { mutableStateOf("") }
  var isSignUpMode by rememberSaveable { mutableStateOf(false) }
  var showAddressDialog by rememberSaveable { mutableStateOf(false) }
  var showEditProfileDialog by rememberSaveable { mutableStateOf(false) }

  if (showAddressDialog) {
    AddAddressDialog(
      strings = strings,
      onDismiss = { showAddressDialog = false },
      onSave = {
        onSaveAddress(it)
        showAddressDialog = false
      },
    )
  }

  val session = state.authSession
  if (showEditProfileDialog && session != null) {
    EditProfileDialog(
      currentName = session.fullName,
      currentPhone = session.phone,
      strings = strings,
      onDismiss = { showEditProfileDialog = false },
      onSave = { name, phone ->
        onUpdateProfile(name, phone)
        showEditProfileDialog = false
      },
    )
  }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp).testTag("account_lazy_column"),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        Text(
          text = strings.accountTitle,
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Bold,
        )
      }

      // Auth & Profile Section
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          border = BorderStroke(1.dp, OutlineSubtle),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            if (session != null) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = KgsEmerald)
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = session.fullName.ifBlank { session.email.ifBlank { session.phone } },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                  )
                  if (session.phone.isNotBlank()) {
                    Text(
                      text = session.phone,
                      style = MaterialTheme.typography.bodySmall,
                    )
                  }
                  if (session.email.isNotBlank()) {
                    Text(
                      text = session.email,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Text(
                    text =
                      "Role: ${if (state.language == AppLanguage.HINDI) session.role.labelHi else session.role.labelEn}",
                    style = MaterialTheme.typography.labelMedium,
                    color = KgsForest,
                  )
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = { showEditProfileDialog = true },
                  modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("edit_profile_button"),
                ) {
                  Icon(Icons.Filled.Edit, contentDescription = strings.editProfile)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(strings.editProfile)
                }
                OutlinedButton(
                  onClick = onSignOut,
                  modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("sign_out_button"),
                ) {
                  Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = strings.signOut)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(strings.signOut)
                }
              }
            } else {
              Surface(
                shape = RoundedCornerShape(18.dp),
                color = KgsForest,
                contentColor = PureWhite,
              ) {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                  verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                  Text(
                    text = "KGS  •  KAILASHPATI GENERAL STORE",
                    style = MaterialTheme.typography.labelLarge,
                    color = KgsGold,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    text = strings.loginTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    text = "Fresh groceries, trusted local shopping",
                    style = MaterialTheme.typography.bodySmall,
                    color = PureWhite,
                  )
                }
              }
              TabRow(
                selectedTabIndex = authTab,
                containerColor = PureWhite,
                contentColor = KgsEmerald,
              ) {
                Tab(
                  selected = authTab == 0,
                  onClick = { authTab = 0 },
                  text = { Text("Mobile SMS OTP") },
                )
                Tab(
                  selected = authTab == 1,
                  onClick = { authTab = 1 },
                  text = { Text("Email / Password") },
                )
              }

              if (authTab == 0) {
                OutlinedTextField(
                  value = phoneInput,
                  onValueChange = { phoneInput = it },
                  label = { Text(strings.mobileNumber) },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth().testTag("login_phone_input"),
                )
                Button(
                  onClick = { onRequestOtp(phoneInput) },
                  enabled = !state.isAuthLoading,
                  colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                  modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("send_otp_button"),
                ) {
                  Text(if (state.otpSentToPhone != null) strings.resendOtp else strings.sendOtp)
                }
                if (state.otpSentToPhone != null) {
                  OutlinedTextField(
                    value = otpInput,
                    onValueChange = { otpInput = it },
                    label = { Text(strings.enterOtp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("verify_otp_input"),
                  )
                  Button(
                    onClick = { onVerifyOtp(phoneInput, otpInput) },
                    enabled = !state.isAuthLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = KgsForest),
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("verify_otp_button"),
                  ) {
                    Text(strings.verifyOtp)
                  }
                }
              } else {
                if (isSignUpMode) {
                  OutlinedTextField(
                    value = fullNameInput,
                    onValueChange = { fullNameInput = it },
                    label = { Text(strings.fullName) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                  )
                  OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text(strings.mobileNumber) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                  )
                }
                OutlinedTextField(
                  value = emailInput,
                  onValueChange = { emailInput = it },
                  label = { Text(strings.emailAddress) },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth().testTag("login_email_input"),
                )
                OutlinedTextField(
                  value = passwordInput,
                  onValueChange = { passwordInput = it },
                  label = { Text(strings.password) },
                  visualTransformation = PasswordVisualTransformation(),
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth().testTag("login_password_input"),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Button(
                    onClick = {
                      if (isSignUpMode) {
                        onSignUpEmail(emailInput, passwordInput, fullNameInput, phoneInput)
                      } else {
                        onSignInEmail(emailInput, passwordInput)
                      }
                    },
                    enabled = !state.isAuthLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("email_auth_submit"),
                  ) {
                    Text(if (isSignUpMode) strings.signUpEmail else strings.signInEmail)
                  }
                  OutlinedButton(
                    onClick = { isSignUpMode = !isSignUpMode },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) {
                    Text(if (isSignUpMode) strings.signInEmail else strings.signUpEmail)
                  }
                }
              }

              if (state.isAuthLoading) {
                CircularProgressIndicator(color = KgsEmerald)
              }
              if (!state.authFeedback.isNullOrBlank()) {
                Surface(shape = RoundedCornerShape(10.dp), color = KgsMintContainer) {
                  Text(
                    text = state.authFeedback,
                    style = MaterialTheme.typography.bodySmall,
                    color = KgsForest,
                    modifier = Modifier.padding(10.dp),
                  )
                }
              }
            }
          }
        }
      }

      // Saved Addresses & Language
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          border = BorderStroke(1.dp, OutlineSubtle),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = strings.savedAddresses,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )
              OutlinedButton(
                onClick = { showAddressDialog = true },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Text(strings.addNewAddress)
              }
            }
            if (state.addresses.isEmpty()) {
              Text(
                text = strings.selectOrAddAddress,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            } else {
              state.addresses.forEach { addr ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color =
                    if (addr.isDefault) KgsMintContainer.copy(alpha = 0.7f)
                    else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = "${addr.label}${if (addr.isDefault) " (Default)" else ""} • ${addr.fullName}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                      )
                      Text(
                        text = "${addr.phone} • ${addr.formatted()}",
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      if (!addr.isDefault) {
                        TextButton(onClick = { onSetDefaultAddress(addr.id) }) {
                          Text(strings.setDefault)
                        }
                      }
                      IconButton(
                        onClick = { onDeleteAddress(addr.id) },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Icon(
                          imageVector = Icons.Filled.DeleteOutline,
                          contentDescription = strings.deleteLabel,
                          tint = StatusError,
                        )
                      }
                    }
                  }
                }
              }
            }

            OutlinedButton(
              onClick = onToggleLanguage,
              modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
            ) {
              Text(
                "${strings.languageLabel}: ${if (state.language == AppLanguage.ENGLISH) "English -> हिन्दी" else "हिन्दी -> English"}"
              )
            }
          }
        }
      }

      // Role-Based Panels (Distributor, Delivery Partner, Admin)
      item {
        Text(
          text = strings.rolePortalsTitle,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(top = 4.dp),
        )
        Text(
          text = strings.roleAccessNote,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      item {
        val role = state.authSession?.role
        PortalActionButton(
          title = strings.distributorPanel,
          subtitle =
            if (role == UserRole.DISTRIBUTOR || role == UserRole.ADMIN) "Authorized"
            else "Requires Distributor or Admin sign-in for live writes",
          icon = Icons.Filled.Store,
          isAuthorized = role == UserRole.DISTRIBUTOR || role == UserRole.ADMIN,
          onClick = onOpenDistributorPanel,
          testTag = "open_distributor_panel",
        )
      }

      item {
        val role = state.authSession?.role
        PortalActionButton(
          title = strings.deliveryPanel,
          subtitle =
            if (role == UserRole.DELIVERY_PARTNER || role == UserRole.ADMIN) "Authorized"
            else "Requires Delivery Partner or Admin sign-in for live writes",
          icon = Icons.Filled.DeliveryDining,
          isAuthorized = role == UserRole.DELIVERY_PARTNER || role == UserRole.ADMIN,
          onClick = onOpenDeliveryPanel,
          testTag = "open_delivery_panel",
        )
      }

      item {
        val role = state.authSession?.role
        PortalActionButton(
          title = strings.adminPanel,
          subtitle =
            if (role == UserRole.ADMIN) "Authorized (Full Dashboard & Schema Inspector)"
            else "Schema Inspector available; Admin mutations require Admin role",
          icon = Icons.Filled.AdminPanelSettings,
          isAuthorized = role == UserRole.ADMIN,
          onClick = onOpenAdminPanel,
          testTag = "open_admin_panel",
        )
      }
    }
  }
}

@Composable
private fun EditProfileDialog(
  currentName: String,
  currentPhone: String,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (String, String) -> Unit,
) {
  var name by rememberSaveable { mutableStateOf(currentName) }
  var phone by rememberSaveable { mutableStateOf(currentPhone) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.editProfile) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text(strings.fullName) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text(strings.mobileNumber) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(name, phone) },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
private fun PortalActionButton(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isAuthorized: Boolean,
  onClick: () -> Unit,
  testTag: String,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(12.dp),
    color = if (isAuthorized) KgsMintContainer else MaterialTheme.colorScheme.surfaceVariant,
    border = BorderStroke(1.dp, OutlineSubtle),
    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Icon(imageVector = icon, contentDescription = title, tint = KgsForest)
      Column(modifier = Modifier.weight(1f)) {
        Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      if (!isAuthorized) {
        Icon(
          imageVector = Icons.Filled.Lock,
          contentDescription = "Role gated",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
