package com.example.data.remote

import com.example.config.SupabaseConfig
import com.example.model.AuthSession
import com.example.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class SupabaseAuthService(private val client: OkHttpClient) {
  private val jsonMedia = "application/json; charset=utf-8".toMediaType()

  suspend fun requestPhoneOtp(phoneE164: String): Result<String> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(
            SupabaseConfig.configurationError
              ?: "Supabase is not configured yet. Add SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets."
          )
        )
      }
      runCatching {
        val body = JSONObject().put("phone", phoneE164).toString().toRequestBody(jsonMedia)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/otp")
            .post(body)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) {
            val msg = parseSupabaseError(respBody)
            error(
              if (
                msg.contains("sms", ignoreCase = true) ||
                  msg.contains("provider", ignoreCase = true) ||
                  msg.contains("phone", ignoreCase = true) ||
                  msg.contains("unsupported", ignoreCase = true)
              ) {
                "SMS OTP provider is not configured in Supabase Auth ($msg). Enable Phone Auth + Twilio/MSG91 in Supabase Dashboard -> Authentication -> Providers."
              } else {
                msg
              }
            )
          }
          "Real SMS OTP sent to $phoneE164"
        }
      }
    }

  suspend fun verifyPhoneOtp(phoneE164: String, otpToken: String): Result<AuthSession> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(
            SupabaseConfig.configurationError ?: "Supabase is not configured yet."
          )
        )
      }
      runCatching {
        val payload =
          JSONObject()
            .put("phone", phoneE164)
            .put("token", otpToken.trim())
            .put("type", "sms")
            .toString()
            .toRequestBody(jsonMedia)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/verify")
            .post(payload)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseSupabaseError(respBody))
          parseSessionAndLoadRole(JSONObject(respBody))
        }
      }
    }

  suspend fun signInWithEmail(email: String, password: String): Result<AuthSession> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(
            SupabaseConfig.configurationError
              ?: "Supabase is not configured yet. Add SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets."
          )
        )
      }
      runCatching {
        val payload =
          JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .toString()
            .toRequestBody(jsonMedia)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/token?grant_type=password")
            .post(payload)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseSupabaseError(respBody))
          parseSessionAndLoadRole(JSONObject(respBody))
        }
      }
    }

  suspend fun signUpWithEmail(
    email: String,
    password: String,
    fullName: String,
    phone: String,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(
            SupabaseConfig.configurationError
              ?: "Supabase is not configured yet. Add SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets."
          )
        )
      }
      runCatching {
        val metadata =
          JSONObject()
            .put("full_name", fullName.trim())
            .put("phone", phone.trim())
            .put("role", UserRole.CUSTOMER.dbValue)
        val payload =
          JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .put("data", metadata)
            .toString()
            .toRequestBody(jsonMedia)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/signup")
            .post(payload)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseSupabaseError(respBody))
          "Account created. If email confirmation is enabled in Supabase, please verify your inbox before signing in."
        }
      }
    }

  suspend fun refreshSession(refreshToken: String): Result<AuthSession> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured || refreshToken.isBlank()) {
        return@withContext Result.failure(IllegalStateException("Missing refresh token"))
      }
      runCatching {
        val payload =
          JSONObject().put("refresh_token", refreshToken).toString().toRequestBody(jsonMedia)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/token?grant_type=refresh_token")
            .post(payload)
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) {
            error("AUTH_REFRESH_${resp.code}: ${parseSupabaseError(respBody)}")
          }
          parseSessionAndLoadRole(JSONObject(respBody))
        }
      }
    }

  suspend fun signOut(accessToken: String) =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured || accessToken.isBlank()) return@withContext
      runCatching {
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/auth/v1/logout")
            .post("".toRequestBody(jsonMedia))
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()
        client.newCall(req).execute().close()
      }
    }

  private fun parseSessionAndLoadRole(obj: JSONObject): AuthSession {
    val accessToken = obj.optString("access_token")
    val refreshToken = obj.optString("refresh_token")
    val user = obj.optJSONObject("user") ?: JSONObject()
    val userId = user.optString("id")
    val email = user.optString("email")
    val phone = user.optString("phone")
    val userMeta = user.optJSONObject("user_metadata") ?: JSONObject()
    val appMeta = user.optJSONObject("app_metadata") ?: JSONObject()

    var fullName = userMeta.optString("full_name").ifBlank { userMeta.optString("name") }
    var role =
      UserRole.fromDb(
        appMeta.optString("role").ifBlank { userMeta.optString("role") }
      )

    // Inspect user's authoritative role from profiles / users table (protected by RLS)
    if (accessToken.isNotBlank() && userId.isNotBlank()) {
      for (table in listOf("profiles", "users")) {
        val profileReq =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$userId&select=*&limit=1")
            .get()
            .addHeader("apikey", SupabaseConfig.anonKey)
            .addHeader("Authorization", "Bearer $accessToken")
            .build()
        runCatching {
          client.newCall(profileReq).execute().use { resp ->
            if (resp.isSuccessful) {
              val arr = JSONArray(resp.body?.string().orEmpty())
              if (arr.length() > 0) {
                val p = arr.getJSONObject(0)
                val dbRole = p.optString("role")
                if (dbRole.isNotBlank()) role = UserRole.fromDb(dbRole)
                val dbName = p.optString("full_name").ifBlank { p.optString("name") }
                if (dbName.isNotBlank()) fullName = dbName
                return@runCatching
              }
            }
          }
        }
      }
    }

    return AuthSession(
      accessToken = accessToken,
      refreshToken = refreshToken,
      userId = userId,
      email = email,
      phone = phone,
      fullName = fullName,
      role = role,
    )
  }

  private fun parseSupabaseError(raw: String): String {
    if (raw.isBlank()) return "Authentication request failed"
    return runCatching {
        val obj = JSONObject(raw)
        obj.optString("msg")
          .ifBlank { obj.optString("error_description") }
          .ifBlank { obj.optString("message") }
          .ifBlank { obj.optString("error") }
          .ifBlank { raw }
      }
      .getOrDefault(raw)
  }
}
