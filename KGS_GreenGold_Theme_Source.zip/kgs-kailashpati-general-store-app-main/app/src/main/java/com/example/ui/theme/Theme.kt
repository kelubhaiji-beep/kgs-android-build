package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val KgsLightColorScheme =
  lightColorScheme(
    primary = KgsEmerald,
    onPrimary = PureWhite,
    primaryContainer = KgsMintContainer,
    onPrimaryContainer = KgsOnMintContainer,
    secondary = KgsLeaf,
    onSecondary = PureWhite,
    secondaryContainer = KgsMintBg,
    onSecondaryContainer = KgsForest,
    tertiary = KgsGold,
    onTertiary = KgsOnSaffronContainer,
    tertiaryContainer = KgsSaffronContainer,
    onTertiaryContainer = KgsOnSaffronContainer,
    background = KgsMintBg,
    onBackground = TextPrimary,
    surface = PureWhite,
    onSurface = TextPrimary,
    surfaceVariant = SoftWhite,
    onSurfaceVariant = TextSecondary,
    outline = OutlineSubtle,
    surfaceTint = KgsEmerald,
    error = StatusError,
    onError = PureWhite,
    errorContainer = StatusErrorContainer,
  )

private val KgsDarkColorScheme =
  darkColorScheme(
    primary = KgsEmeraldDark,
    onPrimary = KgsOnEmeraldDark,
    primaryContainer = KgsContainerDark,
    onPrimaryContainer = KgsMintContainer,
    secondary = KgsLeaf,
    onSecondary = PureWhite,
    secondaryContainer = KgsSurfaceContainerDark,
    onSecondaryContainer = KgsTextDark,
    tertiary = KgsGold,
    onTertiary = KgsOnSaffronContainer,
    background = KgsSurfaceDark,
    onBackground = KgsTextDark,
    surface = KgsSurfaceContainerDark,
    onSurface = KgsTextDark,
    surfaceVariant = KgsSurfaceContainerDark,
    onSurfaceVariant = KgsTextSecondaryDark,
    outline = KgsTextSecondaryDark,
    surfaceTint = KgsEmeraldDark,
    error = StatusError,
    onError = PureWhite,
  )

val KgsShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun KgsTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  // Always preserve KGS green-and-white branding rather than overriding with wallpaper dynamic color
  val colorScheme = if (darkTheme) KgsDarkColorScheme else KgsLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = KgsTypography,
    shapes = KgsShapes,
    content = content,
  )
}
