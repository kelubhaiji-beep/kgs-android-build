package com.example.ui.viewmodel

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.config.SupabaseConfig
import com.example.data.local.SessionStore
import com.example.data.remote.SupabaseAuthService
import com.example.data.remote.SupabaseRestRepository
import com.example.model.AppLanguage
import com.example.model.CartItem
import com.example.model.Category
import com.example.model.CategoryHindiDictionary
import com.example.model.CustomerAddress
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.model.RationItem
import com.example.model.Shop
import com.example.model.UserRole
import com.example.util.NetworkUtils
import com.example.util.PreferIpv4Dns
import com.example.util.ValidationResult
import com.example.util.ValidationUtils
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

class KgsViewModel(application: Application) : AndroidViewModel(application) {
  private val sessionStore = SessionStore(application.applicationContext)

  private val httpClient: OkHttpClient =
    OkHttpClient.Builder()
      .dns(PreferIpv4Dns)
      .retryOnConnectionFailure(true)
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(30, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .callTimeout(45, TimeUnit.SECONDS)
      .apply {
        if (BuildConfig.DEBUG) {
          addInterceptor(
            HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
          )
        }
      }
      .build()

  private val authService = SupabaseAuthService(httpClient)
  private val repository = SupabaseRestRepository(httpClient)

  private val _uiState = MutableStateFlow(KgsUiState())
  val uiState: StateFlow<KgsUiState> = _uiState.asStateFlow()

  private var lastAttemptedRefreshToken: String? = null

  init {
    observeLocalStore()
    if (SupabaseConfig.isConfigured) {
      refreshCatalogAndSchema()
    } else {
      _uiState.update {
        it.copy(
          isSupabaseConfigured = false,
          catalogError = SupabaseConfig.configurationError,
        )
      }
    }
  }

  private fun observeLocalStore() {
    viewModelScope.launch {
      sessionStore.languageFlow.collect { lang -> _uiState.update { it.copy(language = lang) } }
    }
    viewModelScope.launch {
      sessionStore.authSessionFlow.collect { session ->
        _uiState.update { it.copy(authSession = session) }
        if (session != null && SupabaseConfig.isConfigured) {
          var activeSession: com.example.model.AuthSession = session
          if (
            session.refreshToken.isNotBlank() &&
              lastAttemptedRefreshToken != session.refreshToken
          ) {
            lastAttemptedRefreshToken = session.refreshToken
            authService
              .refreshSession(session.refreshToken)
              .onSuccess { refreshed ->
                activeSession = refreshed
                lastAttemptedRefreshToken = refreshed.refreshToken
                sessionStore.saveAuthSession(refreshed)
              }
              .onFailure { err ->
                val msg = err.message.orEmpty()
                if (
                  msg.contains("AUTH_REFRESH_400") ||
                    msg.contains("AUTH_REFRESH_401") ||
                    msg.contains("invalid_grant", ignoreCase = true) ||
                    msg.contains("Invalid Refresh Token", ignoreCase = true)
                ) {
                  sessionStore.saveAuthSession(null)
                  _uiState.update {
                    it.copy(
                      authSession = null,
                      orders = emptyList(),
                      profiles = emptyList(),
                      authFeedback = "Session expired. Please sign in again.",
                    )
                  }
                  return@collect
                }
              }
          }
          loadAuthenticatedUserData(activeSession.userId, activeSession.accessToken, activeSession.role)
        }
      }
    }
    viewModelScope.launch {
      sessionStore.cartItemsFlow.collect { cart -> _uiState.update { it.copy(cartItems = cart) } }
    }
    viewModelScope.launch {
      sessionStore.addressesFlow.collect { list ->
        _uiState.update { state ->
          state.copy(
            addresses = list,
            selectedAddressId =
              state.selectedAddressId ?: list.firstOrNull { it.isDefault }?.id ?: list.firstOrNull()?.id,
          )
        }
      }
    }
    viewModelScope.launch {
      sessionStore.rationItemsFlow.collect { list ->
        _uiState.update { it.copy(rationItems = list) }
      }
    }
  }

  fun toggleLanguage() {
    val next =
      if (_uiState.value.language == AppLanguage.ENGLISH) AppLanguage.HINDI
      else AppLanguage.ENGLISH
    _uiState.update { it.copy(language = next) }
    viewModelScope.launch { sessionStore.saveLanguage(next) }
  }

  fun clearSnackbar() {
    _uiState.update { it.copy(snackbarMessage = null) }
  }

  fun showMessage(msg: String) {
    _uiState.update { it.copy(snackbarMessage = msg) }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun selectCategory(categoryName: String) {
    _uiState.update { it.copy(selectedCategory = categoryName) }
  }

  fun selectShop(shopId: String) {
    _uiState.update { it.copy(selectedShopId = shopId) }
  }

  fun toggleInStockOnly() {
    _uiState.update { it.copy(inStockOnly = !it.inStockOnly) }
  }

  fun inspectSchemaOnly() {
    viewModelScope.launch {
      _uiState.update { it.copy(isInspectingSchema = true) }
      val result = repository.inspectSchema(_uiState.value.authSession?.accessToken)
      _uiState.update {
        it.copy(
          isInspectingSchema = false,
          schemaInspection = result,
          snackbarMessage =
            if (result.isConnected) "Inspected ${result.tables.size} Supabase tables"
            else result.errorMessage,
        )
      }
    }
  }

  fun refreshCatalogAndSchema() {
    viewModelScope.launch {
      if (!SupabaseConfig.isConfigured) {
        _uiState.update {
          it.copy(
            isSupabaseConfigured = false,
            catalogError =
              SupabaseConfig.configurationError
                ?: "SUPABASE_URL and SUPABASE_ANON_KEY are not configured in AI Studio Secrets.",
          )
        }
        return@launch
      }
      val isRobolectric = Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
      if (!isRobolectric && !NetworkUtils.isNetworkAvailable(getApplication())) {
        _uiState.update {
          it.copy(
            isSupabaseConfigured = true,
            isLoadingCatalog = false,
            isInspectingSchema = false,
            catalogError =
              "No active internet connection detected on this device/emulator. Enable Wi-Fi or mobile data and tap Retry.",
          )
        }
        return@launch
      }
      _uiState.update {
        it.copy(
          isSupabaseConfigured = true,
          isLoadingCatalog = true,
          isInspectingSchema = true,
          catalogError = null,
        )
      }
      val token = _uiState.value.authSession?.accessToken

      val (schemaResult, catalogResult, shopsResult) =
        coroutineScope {
          val schemaDeferred = async { repository.inspectSchema(token) }
          val catalogDeferred = async { repository.fetchAllProducts(token) }
          val shopsDeferred = async { repository.fetchShops(token) }
          Triple(schemaDeferred.await(), catalogDeferred.await(), shopsDeferred.await())
        }

      _uiState.update { it.copy(schemaInspection = schemaResult, isInspectingSchema = false) }
      val categoriesResult = repository.fetchCategories(token)
      val shopsList = shopsResult.getOrDefault(emptyList())
      val shopsById = shopsList.associateBy { it.id }

      catalogResult
        .onSuccess { page ->
          val dbCategories = categoriesResult.getOrDefault(emptyList())
          val categoriesById = dbCategories.associateBy { it.id }
          val resolvedProducts =
            page.products.map { product ->
              val linkedCategory = product.categoryId?.let { categoriesById[it] }
              val linkedShopName = product.shopId?.let { shopsById[it]?.shopName }
              product.copy(
                category =
                  if (linkedCategory != null && product.category == "Grocery") linkedCategory.name
                  else product.category,
                categoryHi =
                  product.categoryHi
                    ?: linkedCategory?.nameHi
                    ?: CategoryHindiDictionary.translate(
                      if (linkedCategory != null && product.category == "Grocery") linkedCategory.name
                      else product.category
                    ),
                shopName = product.shopName ?: linkedShopName,
              )
            }

          val mergedCategories =
            if (dbCategories.isNotEmpty()) {
              dbCategories.map { cat ->
                cat.copy(
                  nameHi = cat.nameHi ?: CategoryHindiDictionary.translate(cat.name),
                  productCount =
                    resolvedProducts.count {
                      it.category.equals(cat.name, ignoreCase = true) ||
                        it.categoryId == cat.id
                    },
                )
              }
            } else {
              resolvedProducts
                .groupBy { it.category }
                .entries
                .sortedBy { it.key }
                .mapIndexed { idx, (name, items) ->
                  Category(
                    id = "cat_$idx",
                    name = name,
                    nameHi =
                      items.firstNotNullOfOrNull { it.categoryHi }
                        ?: CategoryHindiDictionary.translate(name),
                    productCount = items.size,
                  )
                }
            }

          _uiState.update {
            it.copy(
              isLoadingCatalog = false,
              products = resolvedProducts,
              totalCatalogCount = page.totalCount,
              resolvedProductsTable = page.resolvedTableName,
              categories = mergedCategories,
              publicShops = shopsList.filter { s -> s.isActive },
              shops = if (it.shops.isEmpty() || shopsList.isNotEmpty()) shopsList else it.shops,
              catalogError = null,
            )
          }
        }
        .onFailure { err ->
          val diag =
            err.message?.takeIf { it.isNotBlank() }
              ?: schemaResult.errorMessage
              ?: "Failed to load products from Supabase"
          _uiState.update {
            it.copy(
              isLoadingCatalog = false,
              publicShops = shopsList.filter { s -> s.isActive },
              shops = if (it.shops.isEmpty() && shopsList.isNotEmpty()) shopsList else it.shops,
              catalogError = diag,
            )
          }
        }
    }
  }

  fun requestPhoneOtp(rawPhone: String) {
    when (val check = ValidationUtils.validateIndianPhone(rawPhone)) {
      is ValidationResult.Invalid -> {
        _uiState.update { it.copy(authFeedback = localized(check)) }
        return
      }
      ValidationResult.Valid -> Unit
    }
    val e164 = ValidationUtils.normalizeIndianPhone(rawPhone)
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthLoading = true, authFeedback = null) }
      authService
        .requestPhoneOtp(e164)
        .onSuccess { msg ->
          _uiState.update {
            it.copy(isAuthLoading = false, otpSentToPhone = e164, authFeedback = msg)
          }
        }
        .onFailure { err ->
          _uiState.update { it.copy(isAuthLoading = false, authFeedback = err.message) }
        }
    }
  }

  fun verifyPhoneOtp(rawPhone: String, otp: String) {
    when (val check = ValidationUtils.validateOtp(otp)) {
      is ValidationResult.Invalid -> {
        _uiState.update { it.copy(authFeedback = localized(check)) }
        return
      }
      ValidationResult.Valid -> Unit
    }
    val e164 = ValidationUtils.normalizeIndianPhone(rawPhone)
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthLoading = true, authFeedback = null) }
      authService
        .verifyPhoneOtp(e164, otp)
        .onSuccess { session ->
          sessionStore.saveAuthSession(session)
          _uiState.update {
            it.copy(
              isAuthLoading = false,
              otpSentToPhone = null,
              authFeedback = "Signed in as ${session.role.labelEn}",
            )
          }
        }
        .onFailure { err ->
          _uiState.update { it.copy(isAuthLoading = false, authFeedback = err.message) }
        }
    }
  }

  fun signInWithEmail(email: String, password: String) {
    val emailCheck = ValidationUtils.validateEmail(email)
    if (emailCheck is ValidationResult.Invalid) {
      _uiState.update { it.copy(authFeedback = localized(emailCheck)) }
      return
    }
    val passCheck = ValidationUtils.validatePassword(password)
    if (passCheck is ValidationResult.Invalid) {
      _uiState.update { it.copy(authFeedback = localized(passCheck)) }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthLoading = true, authFeedback = null) }
      authService
        .signInWithEmail(email, password)
        .onSuccess { session ->
          sessionStore.saveAuthSession(session)
          _uiState.update {
            it.copy(
              isAuthLoading = false,
              authFeedback = "Signed in (${session.role.labelEn})",
            )
          }
        }
        .onFailure { err ->
          _uiState.update { it.copy(isAuthLoading = false, authFeedback = err.message) }
        }
    }
  }

  fun signUpWithEmail(email: String, password: String, fullName: String, phone: String) {
    val emailCheck = ValidationUtils.validateEmail(email)
    if (emailCheck is ValidationResult.Invalid) {
      _uiState.update { it.copy(authFeedback = localized(emailCheck)) }
      return
    }
    val passCheck = ValidationUtils.validatePassword(password)
    if (passCheck is ValidationResult.Invalid) {
      _uiState.update { it.copy(authFeedback = localized(passCheck)) }
      return
    }
    if (fullName.trim().length < 2) {
      _uiState.update { it.copy(authFeedback = "Enter your full name") }
      return
    }
    val phoneCheck = ValidationUtils.validateIndianPhone(phone)
    if (phoneCheck is ValidationResult.Invalid) {
      _uiState.update { it.copy(authFeedback = localized(phoneCheck)) }
      return
    }
    val normalizedPhone = ValidationUtils.normalizeIndianPhone(phone)
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthLoading = true, authFeedback = null) }
      authService
        .signUpWithEmail(email, password, fullName, normalizedPhone)
        .onSuccess { msg ->
          _uiState.update { it.copy(isAuthLoading = false, authFeedback = msg) }
        }
        .onFailure { err ->
          _uiState.update { it.copy(isAuthLoading = false, authFeedback = err.message) }
        }
    }
  }

  fun updateCustomerProfile(fullName: String, phone: String) {
    val session = _uiState.value.authSession ?: return
    if (fullName.trim().length < 2) {
      showMessage("Enter your full name")
      return
    }
    if (phone.isNotBlank()) {
      val phoneCheck = ValidationUtils.validateIndianPhone(phone)
      if (phoneCheck is ValidationResult.Invalid) {
        showMessage(localized(phoneCheck))
        return
      }
    }
    val normalizedPhone =
      if (phone.isNotBlank()) ValidationUtils.normalizeIndianPhone(phone) else session.phone
    viewModelScope.launch {
      repository
        .updateSelfProfile(session.userId, fullName, normalizedPhone, session.accessToken)
        .onSuccess {
          val updated = session.copy(fullName = fullName.trim(), phone = normalizedPhone)
          sessionStore.saveAuthSession(updated)
          _uiState.update { it.copy(authSession = updated, snackbarMessage = "Profile updated") }
        }
        .onFailure { err -> showMessage(err.message ?: "Profile update failed") }
    }
  }

  fun signOut() {
    val token = _uiState.value.authSession?.accessToken.orEmpty()
    lastAttemptedRefreshToken = null
    viewModelScope.launch {
      authService.signOut(token)
      sessionStore.saveAuthSession(null)
      sessionStore.saveAddresses(emptyList())
      sessionStore.saveRationItems(emptyList())
      _uiState.update { state ->
        state.copy(
          authSession = null,
          otpSentToPhone = null,
          addresses = emptyList(),
          selectedAddressId = null,
          rationItems = emptyList(),
          orders = emptyList(),
          profiles = emptyList(),
          shops = state.publicShops,
          authFeedback = "Signed out",
        )
      }
    }
  }

  private fun loadAuthenticatedUserData(userId: String, token: String, role: UserRole) {
    viewModelScope.launch {
      repository.fetchAddresses(userId, token).onSuccess { remoteAddresses ->
        if (remoteAddresses.isNotEmpty()) {
          sessionStore.saveAddresses(remoteAddresses)
        }
      }
      repository.fetchRationItems(userId, token).onSuccess { remoteRation ->
        if (remoteRation.isNotEmpty()) {
          sessionStore.saveRationItems(remoteRation)
        }
      }
      refreshOrdersForRole(userId, token, role)
      if (role == UserRole.ADMIN || role == UserRole.DISTRIBUTOR) {
        refreshPanelData(token, role)
      }
    }
  }

  fun refreshOrders() {
    val session = _uiState.value.authSession ?: return
    viewModelScope.launch {
      refreshOrdersForRole(session.userId, session.accessToken, session.role)
    }
  }

  private suspend fun refreshOrdersForRole(userId: String, token: String, role: UserRole) {
    _uiState.update { it.copy(isLoadingOrders = true) }
    val result =
      when (role) {
        UserRole.CUSTOMER -> repository.fetchOrders(token, "customer_id", userId)
        UserRole.DELIVERY_PARTNER -> repository.fetchOrders(token, "delivery_partner_id", userId)
        UserRole.DISTRIBUTOR, UserRole.ADMIN -> repository.fetchOrders(token)
      }
    result
      .onSuccess { list -> _uiState.update { it.copy(orders = list, isLoadingOrders = false) } }
      .onFailure { err ->
        _uiState.update {
          it.copy(isLoadingOrders = false, snackbarMessage = err.message)
        }
      }
  }

  fun refreshPanelData(token: String? = null, role: UserRole? = null) {
    val session = _uiState.value.authSession ?: return
    val activeToken = token ?: session.accessToken
    val activeRole = role ?: session.role
    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingPanelData = true) }
      repository.fetchShops(activeToken).onSuccess { list ->
        _uiState.update { it.copy(shops = list) }
      }
      if (activeRole == UserRole.ADMIN) {
        repository.fetchProfiles(activeToken).onSuccess { list ->
          _uiState.update { it.copy(profiles = list) }
        }
      }
      refreshOrdersForRole(session.userId, activeToken, activeRole)
      _uiState.update { it.copy(isLoadingPanelData = false) }
    }
  }

  fun addToCart(product: Product, variant: QuantityVariant, qty: Int = 1) {
    if (!product.isAvailable || product.stockQty <= 0) {
      showMessage("This item is currently out of stock")
      return
    }
    val current = _uiState.value.cartItems.toMutableList()
    val index =
      current.indexOfFirst { it.product.id == product.id && it.variant == variant }
    val otherVariantsQty =
      current.filterIndexed { i, item -> i != index && item.product.id == product.id }.sumOf { it.quantity }
    val maxForThisLine = (product.stockQty - otherVariantsQty).coerceAtLeast(0)
    val requestedLineQty = (if (index >= 0) current[index].quantity else 0) + qty.coerceAtLeast(1)

    if (maxForThisLine <= 0 || requestedLineQty > maxForThisLine) {
      val capped = maxForThisLine
      if (capped <= 0 || (index >= 0 && current[index].quantity >= capped)) {
        showMessage("Only ${product.stockQty} units available in stock")
        return
      }
      if (index >= 0) {
        current[index] = current[index].copy(quantity = capped)
      } else {
        current.add(CartItem(product = product, variant = variant, quantity = capped))
      }
      _uiState.update { it.copy(cartItems = current) }
      viewModelScope.launch { sessionStore.saveCartItems(current) }
      showMessage("Added max available stock (${product.stockQty})")
      return
    }

    if (index >= 0) {
      val existing = current[index]
      current[index] = existing.copy(quantity = requestedLineQty)
    } else {
      current.add(CartItem(product = product, variant = variant, quantity = requestedLineQty))
    }
    _uiState.update { it.copy(cartItems = current) }
    viewModelScope.launch { sessionStore.saveCartItems(current) }
    val unitStr = if (product.isWeightBased) variant.label else product.baseUnit
    showMessage("${product.displayName(_uiState.value.language)} ($unitStr) added")
  }

  fun updateCartQuantity(productId: String, variant: QuantityVariant, newQty: Int) {
    val current = _uiState.value.cartItems.toMutableList()
    val index = current.indexOfFirst { it.product.id == productId && it.variant == variant }
    if (index < 0) return
    if (newQty <= 0) {
      current.removeAt(index)
    } else {
      val liveProduct = _uiState.value.products.firstOrNull { it.id == productId } ?: current[index].product
      val otherVariantsQty =
        current.filterIndexed { i, item -> i != index && item.product.id == productId }.sumOf { it.quantity }
      val maxForLine = (liveProduct.stockQty - otherVariantsQty).coerceAtLeast(0)
      if (newQty > maxForLine) {
        if (maxForLine <= 0) {
          current.removeAt(index)
          showMessage("${liveProduct.displayName(_uiState.value.language)} is out of stock")
        } else {
          current[index] = current[index].copy(quantity = maxForLine)
          showMessage("Only ${liveProduct.stockQty} units available in stock")
        }
      } else {
        current[index] = current[index].copy(quantity = newQty)
      }
    }
    _uiState.update { it.copy(cartItems = current) }
    viewModelScope.launch { sessionStore.saveCartItems(current) }
  }

  fun saveAddress(address: CustomerAddress) {
    val check = ValidationUtils.validateAddress(address)
    if (check is ValidationResult.Invalid) {
      showMessage(localized(check))
      return
    }
    val session = _uiState.value.authSession
    val normalizedPhone = ValidationUtils.normalizeIndianPhone(address.phone)
    val toSave =
      address.copy(
        id = address.id.ifBlank { UUID.randomUUID().toString() },
        userId = session?.userId,
        phone = normalizedPhone,
        isDefault = _uiState.value.addresses.isEmpty() || address.isDefault,
      )
    val updated =
      (_uiState.value.addresses.filterNot { it.id == toSave.id } + toSave).let { list ->
        if (toSave.isDefault) list.map { it.copy(isDefault = it.id == toSave.id) } else list
      }
    _uiState.update { it.copy(addresses = updated, selectedAddressId = toSave.id) }
    viewModelScope.launch {
      sessionStore.saveAddresses(updated)
      if (session != null && SupabaseConfig.isConfigured) {
        repository.saveAddress(toSave, session.accessToken).onFailure { err ->
          showMessage("Saved locally; Supabase sync error: ${err.message}")
        }
      }
    }
    showMessage("Address saved")
  }

  fun deleteAddress(addressId: String) {
    val session = _uiState.value.authSession
    val updated = _uiState.value.addresses.filterNot { it.id == addressId }
    _uiState.update { state ->
      state.copy(
        addresses = updated,
        selectedAddressId =
          if (state.selectedAddressId == addressId) updated.firstOrNull()?.id
          else state.selectedAddressId,
      )
    }
    viewModelScope.launch {
      sessionStore.saveAddresses(updated)
      if (session != null && SupabaseConfig.isConfigured) {
        repository.deleteAddress(addressId, session.accessToken)
      }
    }
    showMessage("Address deleted")
  }

  fun setDefaultAddress(addressId: String) {
    val session = _uiState.value.authSession
    val updated = _uiState.value.addresses.map { it.copy(isDefault = it.id == addressId) }
    _uiState.update { it.copy(addresses = updated, selectedAddressId = addressId) }
    viewModelScope.launch {
      sessionStore.saveAddresses(updated)
      val target = updated.firstOrNull { it.id == addressId }
      if (session != null && target != null && SupabaseConfig.isConfigured) {
        repository.saveAddress(target, session.accessToken)
      }
    }
    showMessage("Default delivery location updated")
  }

  fun selectAddress(addressId: String) {
    _uiState.update { it.copy(selectedAddressId = addressId) }
  }

  fun addToRation(product: Product, variant: QuantityVariant) {
    val session = _uiState.value.authSession
    val current = _uiState.value.rationItems.toMutableList()
    val idx = current.indexOfFirst { it.productId == product.id && it.variant == variant }
    val itemToSync: RationItem
    if (idx >= 0) {
      val updatedItem = current[idx].copy(quantity = current[idx].quantity + 1)
      current[idx] = updatedItem
      itemToSync = updatedItem
    } else {
      val newItem =
        RationItem(
          id = UUID.randomUUID().toString(),
          userId = session?.userId,
          productId = product.id,
          productName = product.name,
          productNameHi = product.nameHi,
          category = product.category,
          variant = variant,
          quantity = 1,
          estimatedUnitPrice = product.priceFor(variant),
          imageUrl = product.imageUrl,
        )
      current.add(newItem)
      itemToSync = newItem
    }
    _uiState.update { it.copy(rationItems = current) }
    viewModelScope.launch {
      sessionStore.saveRationItems(current)
      if (session != null && SupabaseConfig.isConfigured) {
        repository.upsertRationItem(itemToSync.copy(userId = session.userId), session.accessToken)
      }
    }
    showMessage("Added to Monthly Ration List")
  }

  fun addCustomRationItem(name: String, variant: QuantityVariant, quantity: Int) {
    if (name.trim().length < 2) {
      showMessage("Enter item name")
      return
    }
    val session = _uiState.value.authSession
    val newItem =
      RationItem(
        id = UUID.randomUUID().toString(),
        userId = session?.userId,
        productName = name.trim(),
        variant = variant,
        quantity = quantity.coerceAtLeast(1),
      )
    val current = _uiState.value.rationItems + newItem
    _uiState.update { it.copy(rationItems = current) }
    viewModelScope.launch {
      sessionStore.saveRationItems(current)
      if (session != null && SupabaseConfig.isConfigured) {
        repository.upsertRationItem(newItem, session.accessToken)
      }
    }
  }

  fun editRationItem(rationId: String, name: String, variant: QuantityVariant, quantity: Int) {
    if (name.trim().length < 2) {
      showMessage("Enter item name")
      return
    }
    val session = _uiState.value.authSession
    val current = _uiState.value.rationItems.toMutableList()
    val idx = current.indexOfFirst { it.id == rationId }
    if (idx < 0) return
    val updated =
      current[idx].copy(
        productName = name.trim(),
        variant = variant,
        quantity = quantity.coerceAtLeast(1),
      )
    current[idx] = updated
    _uiState.update { it.copy(rationItems = current) }
    viewModelScope.launch {
      sessionStore.saveRationItems(current)
      if (session != null && SupabaseConfig.isConfigured) {
        repository.upsertRationItem(updated.copy(userId = session.userId), session.accessToken)
      }
    }
    showMessage("Ration item updated")
  }

  fun updateRationQuantity(rationId: String, newQty: Int) {
    val session = _uiState.value.authSession
    val current = _uiState.value.rationItems.toMutableList()
    val idx = current.indexOfFirst { it.id == rationId }
    if (idx < 0) return
    val removed = newQty <= 0
    val updatedItem: RationItem? =
      if (removed) {
        current.removeAt(idx)
        null
      } else {
        current[idx].copy(quantity = newQty).also { current[idx] = it }
      }
    _uiState.update { it.copy(rationItems = current) }
    viewModelScope.launch {
      sessionStore.saveRationItems(current)
      if (session != null && SupabaseConfig.isConfigured) {
        if (removed) repository.deleteRationItem(rationId, session.accessToken)
        else if (updatedItem != null) {
          repository.upsertRationItem(updatedItem.copy(userId = session.userId), session.accessToken)
        }
      }
    }
  }

  fun addAllRationToCart() {
    val productsById = _uiState.value.products.associateBy { it.id }
    val productsByName = _uiState.value.products.associateBy { it.name.lowercase() }
    var added = 0
    _uiState.value.rationItems.forEach { r ->
      val matched =
        r.productId?.let { productsById[it] } ?: productsByName[r.productName.lowercase()]
      if (matched != null && matched.isAvailable && matched.stockQty > 0) {
        addToCart(matched, r.variant, r.quantity)
        added++
      }
    }
    showMessage(
      if (added > 0) "$added ration items added to cart"
      else "Connect Supabase catalog to match ration items with live stock"
    )
  }

  fun reorderToCart(order: Order): Int {
    val productsById = _uiState.value.products.associateBy { it.id }
    val productsByName = _uiState.value.products.associateBy { it.name.lowercase() }
    var added = 0
    order.items.forEach { item ->
      val matched =
        productsById[item.productId] ?: productsByName[item.productName.lowercase()]
      if (matched != null && matched.isAvailable && matched.stockQty > 0) {
        addToCart(matched, item.variant, item.quantity)
        added++
      }
    }
    showMessage(
      if (added > 0) "$added items added to your basket"
      else "Items from this order are currently unavailable"
    )
    return added
  }

  fun placeOrder(
    paymentMethod: PaymentMethod,
    upiReference: String = "",
    customerMarkedPaid: Boolean = false,
    onSuccess: (Order) -> Unit,
  ) {
    val state = _uiState.value
    val address = state.selectedAddress
    if (state.cartItems.isEmpty()) {
      showMessage("Your cart is empty")
      return
    }
    if (address == null) {
      showMessage("Please select or add a delivery address")
      return
    }
    if (paymentMethod == PaymentMethod.UPI) {
      val refCheck = ValidationUtils.validateUpiReference(upiReference)
      if (refCheck is ValidationResult.Invalid) {
        showMessage(localized(refCheck))
        return
      }
    }
    val session = state.authSession
    if (!SupabaseConfig.isConfigured || session == null) {
      showMessage(
        "Sign in with a connected Supabase account to submit real orders securely under RLS."
      )
      return
    }

    // Validate live catalog availability and stock limits before order submission
    val liveProductsById = state.products.associateBy { it.id }
    val qtyByProductId = state.cartItems.groupBy { it.product.id }.mapValues { (_, list) -> list.sumOf { it.quantity } }
    for ((pid, totalQty) in qtyByProductId) {
      val prod = liveProductsById[pid] ?: state.cartItems.first { it.product.id == pid }.product
      if (!prod.isAvailable || prod.stockQty <= 0) {
        showMessage("${prod.displayName(state.language)} is out of stock")
        return
      }
      if (totalQty > prod.stockQty) {
        showMessage("Only ${prod.stockQty} units of ${prod.displayName(state.language)} left in stock")
        return
      }
    }

    // Group cart items by shopId so multi-shop baskets create isolated shop-scoped orders
    val groupedByShop = state.cartItems.groupBy { it.product.shopId }
    val shopsById = state.publicShops.associateBy { it.id }
    val cleanRef = upiReference.trim().takeIf { it.isNotBlank() }

    viewModelScope.launch {
      _uiState.update { it.copy(isPlacingOrder = true) }
      val createdOrders = mutableListOf<Order>()
      var failureError: String? = null
      val entries = groupedByShop.entries.toList()

      entries.forEachIndexed { idx, (shopId, shopItems) ->
        val shopSubtotal = shopItems.sumOf { it.lineTotal }
        val feeForOrder = if (idx == 0) state.deliveryFee else 0.0
        val order =
          Order(
            id = "",
            orderNumber = "KGS-${System.currentTimeMillis().toString().takeLast(6)}${if (entries.size > 1) "-${idx + 1}" else ""}",
            customerId = session.userId,
            customerName = address.fullName,
            customerPhone = address.phone,
            deliveryAddress = address.formatted(),
            items =
              shopItems.map {
                OrderItem(
                  productId = it.product.id,
                  productName = it.product.name,
                  variant = it.variant,
                  quantity = it.quantity,
                  unitPrice = it.unitPrice,
                  shopId = it.product.shopId,
                )
              },
            deliveryFee = feeForOrder,
            totalAmount = shopSubtotal + feeForOrder,
            paymentMethod = paymentMethod,
            // CRITICAL: Kotak UPI MUST stay pending_verification until Admin checks bank account
            paymentStatus =
              if (paymentMethod == PaymentMethod.COD) PaymentStatus.COD_PENDING.dbValue
              else PaymentStatus.PENDING_VERIFICATION.dbValue,
            upiReference = if (paymentMethod == PaymentMethod.UPI) cleanRef else null,
            customerMarkedPaid = paymentMethod == PaymentMethod.UPI && customerMarkedPaid,
            refundStatus = "none",
            status = OrderStatus.PLACED,
            shopId = shopId,
            distributorId =
              shopId?.let { shopsById[it]?.ownerId }
                ?: shopItems.firstOrNull()?.product?.distributorId,
          )

        repository
          .createOrder(order, session.accessToken)
          .onSuccess { savedOrder -> createdOrders.add(savedOrder) }
          .onFailure { err -> failureError = err.message ?: "Order failed" }
      }

      if (createdOrders.isNotEmpty() && failureError == null) {
        sessionStore.saveCartItems(emptyList())
        _uiState.update {
          it.copy(
            isPlacingOrder = false,
            orders = createdOrders + it.orders,
            snackbarMessage =
              if (paymentMethod == PaymentMethod.UPI) {
                "Order ${createdOrders.first().orderNumber} placed (Payment: Pending Verification)"
              } else {
                "Order ${createdOrders.first().orderNumber} placed (COD)"
              },
          )
        }
        // Refresh catalog to reflect server stock decrements
        refreshCatalogAndSchema()
        onSuccess(createdOrders.first())
      } else {
        _uiState.update {
          it.copy(
            isPlacingOrder = false,
            snackbarMessage = failureError ?: "Order submission failed",
          )
        }
      }
    }
  }

  fun submitOrderUpiReference(orderId: String, upiReference: String, customerMarkedPaid: Boolean) {
    val refCheck = ValidationUtils.validateUpiReference(upiReference)
    if (refCheck is ValidationResult.Invalid) {
      showMessage(localized(refCheck))
      return
    }
    val session = _uiState.value.authSession ?: return
    val cleanRef = upiReference.trim().takeIf { it.isNotBlank() }
    viewModelScope.launch {
      repository
        .submitOrderUpiReference(orderId, cleanRef, customerMarkedPaid, session.accessToken)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      upiReference = cleanRef ?: it.upiReference,
                      customerMarkedPaid = customerMarkedPaid,
                      paymentStatus = PaymentStatus.PENDING_VERIFICATION.dbValue,
                    )
                  } else it
                },
              snackbarMessage = "UPI reference saved. Pending Admin bank verification.",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Failed to save UPI reference") }
    }
  }

  fun cancelOrder(orderId: String, reason: String) {
    val session = _uiState.value.authSession ?: return
    val existing = _uiState.value.orders.firstOrNull { it.id == orderId }
    val nextRefundStatus =
      if (existing?.parsedPaymentStatus == PaymentStatus.UPI_VERIFIED) "requested" else "none"
    viewModelScope.launch {
      repository
        .updateOrderStatus(
          orderId = orderId,
          newStatus = OrderStatus.CANCELLED,
          cancellationReason = reason.ifBlank { "Cancelled by user" },
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      status = OrderStatus.CANCELLED,
                      cancellationReason = reason.ifBlank { "Cancelled by user" },
                      refundStatus = nextRefundStatus,
                    )
                  } else it
                },
              snackbarMessage = "Order cancelled",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Unable to cancel order") }
    }
  }

  fun saveProductPriceAndStock(product: Product, priceText: String, stockText: String) {
    if (product.name.trim().length < 2) {
      showMessage("Enter a valid product name")
      return
    }
    val check = ValidationUtils.validatePriceAndStock(priceText, stockText)
    if (check is ValidationResult.Invalid) {
      showMessage(localized(check))
      return
    }
    val stateSnapshot = _uiState.value
    val session = stateSnapshot.authSession
    if (session == null || (session.role != UserRole.DISTRIBUTOR && session.role != UserRole.ADMIN)) {
      showMessage("Distributor or Admin sign-in required to manage products")
      return
    }
    val ownedShopIds = stateSnapshot.distributorOwnedShopIds
    if (session.role == UserRole.DISTRIBUTOR) {
      if (product.id.isNotBlank()) {
        val ownsExisting =
          (product.shopId != null && product.shopId in ownedShopIds) ||
            product.distributorId == session.userId
        if (!ownsExisting) {
          showMessage("Distributors can only edit products belonging to their own shop")
          return
        }
      }
      if (product.shopId != null && product.shopId !in ownedShopIds) {
        showMessage("Selected shop does not belong to your distributor account")
        return
      }
    }
    val targetShopId =
      if (session.role == UserRole.DISTRIBUTOR) {
        product.shopId ?: ownedShopIds.firstOrNull()
      } else {
        product.shopId
      }
    if (session.role == UserRole.DISTRIBUTOR && targetShopId.isNullOrBlank()) {
      showMessage("Register and get a shop approved first before adding products")
      return
    }
    val parsedStock = stockText.toInt()
    val updated =
      product.copy(
        basePrice = priceText.toDouble(),
        stockQty = parsedStock,
        isAvailable = parsedStock > 0 && product.isAvailable,
        shopId = targetShopId,
        distributorId =
          product.distributorId ?: if (session.role == UserRole.DISTRIBUTOR) session.userId else null,
      )
    viewModelScope.launch {
      repository
        .upsertProduct(updated, isNew = product.id.isBlank(), accessToken = session.accessToken)
        .onSuccess { saved ->
          _uiState.update { state ->
            val exists = state.products.any { it.id == saved.id }
            val nextList =
              if (exists) state.products.map { if (it.id == saved.id) saved else it }
              else listOf(saved) + state.products
            state.copy(products = nextList, snackbarMessage = "Product saved to Supabase")
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Save product failed") }
    }
  }

  fun deleteProduct(productId: String) {
    val stateSnapshot = _uiState.value
    val session = stateSnapshot.authSession
    if (session == null || (session.role != UserRole.DISTRIBUTOR && session.role != UserRole.ADMIN)) {
      showMessage("Distributor or Admin sign-in required")
      return
    }
    if (session.role == UserRole.DISTRIBUTOR) {
      val target = stateSnapshot.products.firstOrNull { it.id == productId }
      val ownsTarget =
        target != null &&
          ((target.shopId != null && target.shopId in stateSnapshot.distributorOwnedShopIds) ||
            target.distributorId == session.userId)
      if (!ownsTarget) {
        showMessage("Distributors can only delete products belonging to their own shop")
        return
      }
    }
    viewModelScope.launch {
      repository
        .deleteProduct(productId, session.accessToken)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              products = state.products.filterNot { it.id == productId },
              snackbarMessage = "Product deleted",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Delete product failed") }
    }
  }

  fun registerDistributorShop(shop: Shop) {
    val session = _uiState.value.authSession
    if (session == null) {
      showMessage("Sign in first to register a distributor shop")
      return
    }
    if (shop.shopName.trim().length < 3 || shop.address.trim().length < 5) {
      showMessage("Enter valid shop name and address")
      return
    }
    val phoneCheck = ValidationUtils.validateIndianPhone(shop.phone)
    if (phoneCheck is ValidationResult.Invalid) {
      showMessage(localized(phoneCheck))
      return
    }
    viewModelScope.launch {
      repository
        .registerShop(shop.copy(ownerId = session.userId), session.accessToken)
        .onSuccess { saved ->
          _uiState.update {
            it.copy(
              shops = listOf(saved) + it.shops,
              snackbarMessage = "Shop submitted to Supabase for admin approval",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Shop registration failed") }
    }
  }

  fun updateOrderStatus(orderId: String, newStatus: OrderStatus, deliveryPartnerId: String? = null) {
    val stateSnapshot = _uiState.value
    val session = stateSnapshot.authSession
    if (session == null || session.role == UserRole.CUSTOMER) {
      showMessage("Staff sign-in required")
      return
    }
    val existing = stateSnapshot.orders.firstOrNull { it.id == orderId }
    if (session.role == UserRole.DISTRIBUTOR && existing != null) {
      val ownsOrder =
        (existing.shopId != null && existing.shopId in stateSnapshot.distributorOwnedShopIds) ||
          existing.distributorId == session.userId
      if (!ownsOrder) {
        showMessage("Distributors can only update orders belonging to their own shop")
        return
      }
    }
    if (session.role == UserRole.DELIVERY_PARTNER && existing != null && existing.deliveryPartnerId != session.userId) {
      showMessage("Delivery partners can only update orders assigned to them")
      return
    }
    viewModelScope.launch {
      repository
        .updateOrderStatus(
          orderId = orderId,
          newStatus = newStatus,
          deliveryPartnerId = deliveryPartnerId,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      status = newStatus,
                      deliveryPartnerId = deliveryPartnerId ?: it.deliveryPartnerId,
                    )
                  } else it
                },
              snackbarMessage = "Order updated to ${newStatus.labelEn}",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Status update failed") }
    }
  }

  fun markDeliveryCompleted(orderId: String, collectCod: Boolean) {
    val stateSnapshot = _uiState.value
    val session = stateSnapshot.authSession
    if (session == null || (session.role != UserRole.DELIVERY_PARTNER && session.role != UserRole.ADMIN)) {
      showMessage("Delivery Partner or Admin sign-in required")
      return
    }
    val existing = stateSnapshot.orders.firstOrNull { it.id == orderId }
    if (session.role == UserRole.DELIVERY_PARTNER && existing != null && existing.deliveryPartnerId != session.userId) {
      showMessage("Only the assigned delivery partner can complete this delivery")
      return
    }
    val nextPaymentStatus = if (collectCod) PaymentStatus.COD_COLLECTED.dbValue else null
    viewModelScope.launch {
      repository
        .updateOrderStatus(
          orderId = orderId,
          newStatus = OrderStatus.DELIVERED,
          paymentStatus = nextPaymentStatus,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      status = OrderStatus.DELIVERED,
                      paymentStatus = nextPaymentStatus ?: it.paymentStatus,
                    )
                  } else it
                },
              snackbarMessage =
                if (collectCod) "Delivered & COD Cash Collected" else "Marked Delivered",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Delivery update failed") }
    }
  }

  fun adminVerifyUpiPayment(orderId: String, approved: Boolean) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required to verify UPI payments")
      return
    }
    val nextStatus =
      if (approved) PaymentStatus.UPI_VERIFIED else PaymentStatus.UPI_REJECTED
    viewModelScope.launch {
      repository
        .updateOrderPaymentAndRefund(
          orderId = orderId,
          paymentStatus = nextStatus,
          refundStatus = "none",
          verifiedByUserId = session.userId,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      paymentStatus = nextStatus.dbValue,
                      paymentVerifiedBy = session.userId,
                    )
                  } else it
                },
              snackbarMessage =
                if (approved) "Kotak UPI payment verified" else "UPI payment marked not received",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Payment verification failed") }
    }
  }

  fun adminMarkCodCollected(orderId: String) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required")
      return
    }
    viewModelScope.launch {
      repository
        .updateOrderPaymentAndRefund(
          orderId = orderId,
          paymentStatus = PaymentStatus.COD_COLLECTED,
          refundStatus = "none",
          verifiedByUserId = session.userId,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) it.copy(paymentStatus = PaymentStatus.COD_COLLECTED.dbValue)
                  else it
                },
              snackbarMessage = "COD marked collected",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "COD update failed") }
    }
  }

  fun adminUpdateRefund(orderId: String, refundStatus: String) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required")
      return
    }
    val existing = _uiState.value.orders.firstOrNull { it.id == orderId }
    val nextPaymentStatus =
      if (refundStatus == "refunded") PaymentStatus.REFUNDED
      else existing?.parsedPaymentStatus ?: PaymentStatus.PENDING_VERIFICATION
    viewModelScope.launch {
      repository
        .updateOrderPaymentAndRefund(
          orderId = orderId,
          paymentStatus = nextPaymentStatus,
          refundStatus = refundStatus,
          verifiedByUserId = session.userId,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      refundStatus = refundStatus,
                      paymentStatus = nextPaymentStatus.dbValue,
                    )
                  } else it
                },
              snackbarMessage = "Refund status updated to $refundStatus",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Refund update failed") }
    }
  }

  fun adminAssignDeliveryPartner(orderId: String, partnerId: String) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN && session?.role != UserRole.DISTRIBUTOR) {
      showMessage("Admin or Distributor role required")
      return
    }
    val existing = _uiState.value.orders.firstOrNull { it.id == orderId } ?: return
    val partnerProfile = _uiState.value.profiles.firstOrNull { it.id == partnerId }
    val partnerName =
      partnerProfile?.fullName?.ifBlank { partnerProfile.phone }
    viewModelScope.launch {
      repository
        .updateOrderStatus(
          orderId = orderId,
          newStatus = existing.status,
          deliveryPartnerId = partnerId,
          deliveryPartnerName = partnerName,
          accessToken = session.accessToken,
        )
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              orders =
                state.orders.map {
                  if (it.id == orderId) {
                    it.copy(
                      deliveryPartnerId = partnerId,
                      deliveryPartnerName = partnerName ?: it.deliveryPartnerName,
                    )
                  } else it
                },
              snackbarMessage = "Assigned delivery partner",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Partner assignment failed") }
    }
  }

  fun adminUpdateRole(userId: String, role: UserRole) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required")
      return
    }
    viewModelScope.launch {
      repository
        .updateProfileRole(userId, role, session.accessToken)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              profiles = state.profiles.map { if (it.id == userId) it.copy(role = role) else it },
              snackbarMessage = "Updated role to ${role.labelEn}",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Role update failed") }
    }
  }

  fun adminToggleUserActive(userId: String, active: Boolean) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required")
      return
    }
    viewModelScope.launch {
      repository
        .updateProfileActive(userId, active, session.accessToken)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              profiles = state.profiles.map { if (it.id == userId) it.copy(isActive = active) else it },
              snackbarMessage = if (active) "User activated" else "User disabled",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Account status update failed") }
    }
  }

  fun adminApproveShop(shopId: String, approved: Boolean) {
    val session = _uiState.value.authSession
    if (session?.role != UserRole.ADMIN) {
      showMessage("Admin role required")
      return
    }
    viewModelScope.launch {
      repository
        .updateShopApproval(shopId, approved, session.accessToken)
        .onSuccess {
          _uiState.update { state ->
            state.copy(
              shops = state.shops.map { if (it.id == shopId) it.copy(isApproved = approved) else it },
              snackbarMessage = if (approved) "Shop approved" else "Shop suspended",
            )
          }
        }
        .onFailure { err -> showMessage(err.message ?: "Shop approval failed") }
    }
  }

  private fun localized(invalid: ValidationResult.Invalid): String =
    if (_uiState.value.language == AppLanguage.HINDI) invalid.messageHi else invalid.messageEn
}
