package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.AuthSession
import com.example.model.CartItem
import com.example.model.CustomerAddress
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.model.RationItem
import com.example.model.UserRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.kgsDataStore by preferencesDataStore(name = "kgs_store_prefs")

class SessionStore(private val context: Context) {
  private object Keys {
    val LANGUAGE = stringPreferencesKey("app_language")
    val AUTH_SESSION = stringPreferencesKey("auth_session")
    val CART_ITEMS = stringPreferencesKey("cart_items")
    val SAVED_ADDRESSES = stringPreferencesKey("saved_addresses")
    val RATION_ITEMS = stringPreferencesKey("ration_items")
  }

  val languageFlow: Flow<AppLanguage> =
    context.kgsDataStore.data.map { prefs ->
      if (prefs[Keys.LANGUAGE] == AppLanguage.HINDI.code) AppLanguage.HINDI
      else AppLanguage.ENGLISH
    }

  val authSessionFlow: Flow<AuthSession?> =
    context.kgsDataStore.data.map { prefs ->
      prefs[Keys.AUTH_SESSION]?.let(::decodeAuthSession)
    }

  val cartItemsFlow: Flow<List<CartItem>> =
    context.kgsDataStore.data.map { prefs ->
      prefs[Keys.CART_ITEMS]?.let(::decodeCartItems) ?: emptyList()
    }

  val addressesFlow: Flow<List<CustomerAddress>> =
    context.kgsDataStore.data.map { prefs ->
      prefs[Keys.SAVED_ADDRESSES]?.let(::decodeAddresses) ?: emptyList()
    }

  val rationItemsFlow: Flow<List<RationItem>> =
    context.kgsDataStore.data.map { prefs ->
      prefs[Keys.RATION_ITEMS]?.let(::decodeRationItems) ?: emptyList()
    }

  suspend fun saveLanguage(language: AppLanguage) {
    context.kgsDataStore.edit { it[Keys.LANGUAGE] = language.code }
  }

  suspend fun saveAuthSession(session: AuthSession?) {
    context.kgsDataStore.edit { prefs ->
      if (session == null) prefs.remove(Keys.AUTH_SESSION)
      else prefs[Keys.AUTH_SESSION] = encodeAuthSession(session)
    }
  }

  suspend fun saveCartItems(items: List<CartItem>) {
    context.kgsDataStore.edit { it[Keys.CART_ITEMS] = encodeCartItems(items) }
  }

  suspend fun saveAddresses(addresses: List<CustomerAddress>) {
    context.kgsDataStore.edit { it[Keys.SAVED_ADDRESSES] = encodeAddresses(addresses) }
  }

  suspend fun saveRationItems(items: List<RationItem>) {
    context.kgsDataStore.edit { it[Keys.RATION_ITEMS] = encodeRationItems(items) }
  }

  private fun encodeAuthSession(session: AuthSession): String =
    JSONObject()
      .apply {
        put("accessToken", session.accessToken)
        put("refreshToken", session.refreshToken)
        put("userId", session.userId)
        put("email", session.email)
        put("phone", session.phone)
        put("fullName", session.fullName)
        put("role", session.role.dbValue)
      }
      .toString()

  private fun decodeAuthSession(raw: String): AuthSession? =
    runCatching {
        val obj = JSONObject(raw)
        AuthSession(
          accessToken = obj.optString("accessToken"),
          refreshToken = obj.optString("refreshToken"),
          userId = obj.optString("userId"),
          email = obj.optString("email"),
          phone = obj.optString("phone"),
          fullName = obj.optString("fullName"),
          role = UserRole.fromDb(obj.optString("role")),
        )
      }
      .getOrNull()
      ?.takeIf { it.accessToken.isNotBlank() && it.userId.isNotBlank() }

  private fun encodeCartItems(items: List<CartItem>): String =
    JSONArray()
      .apply {
        items.forEach { item ->
          put(
            JSONObject().apply {
              put("id", item.product.id)
              put("name", item.product.name)
              put("nameHi", item.product.nameHi ?: "")
              put("category", item.product.category)
              put("imageUrl", item.product.imageUrl ?: "")
              put("basePrice", item.product.basePrice)
              put("baseUnit", item.product.baseUnit)
              put("stockQty", item.product.stockQty)
              put("isAvailable", item.product.isAvailable)
              put("distributorId", item.product.distributorId ?: "")
              put("shopId", item.product.shopId ?: "")
              put("shopName", item.product.shopName ?: "")
              put("variant", item.variant.label)
              put("quantity", item.quantity)
            }
          )
        }
      }
      .toString()

  private fun decodeCartItems(raw: String): List<CartItem> =
    runCatching {
        val arr = JSONArray(raw)
        List(arr.length()) { i ->
          val obj = arr.getJSONObject(i)
          val product =
            Product(
              id = obj.optString("id"),
              name = obj.optString("name"),
              nameHi = obj.optString("nameHi").takeIf { it.isNotBlank() },
              category = obj.optString("category", "Grocery"),
              imageUrl = obj.optString("imageUrl").takeIf { it.isNotBlank() },
              basePrice = obj.optDouble("basePrice", 0.0),
              baseUnit = obj.optString("baseUnit", "1kg"),
              stockQty = obj.optInt("stockQty", 0),
              isAvailable = obj.optBoolean("isAvailable", true),
              shopId = obj.optString("shopId").takeIf { it.isNotBlank() },
              distributorId = obj.optString("distributorId").takeIf { it.isNotBlank() },
              shopName = obj.optString("shopName").takeIf { it.isNotBlank() },
            )
          CartItem(
            product = product,
            variant = QuantityVariant.fromLabel(obj.optString("variant")),
            quantity = obj.optInt("quantity", 1).coerceAtLeast(1),
          )
        }
      }
      .getOrDefault(emptyList())

  private fun encodeAddresses(addresses: List<CustomerAddress>): String =
    JSONArray()
      .apply {
        addresses.forEach { addr ->
          put(
            JSONObject().apply {
              put("id", addr.id)
              put("userId", addr.userId ?: "")
              put("label", addr.label)
              put("fullName", addr.fullName)
              put("phone", addr.phone)
              put("streetAddress", addr.streetAddress)
              put("landmark", addr.landmark)
              put("city", addr.city)
              put("pincode", addr.pincode)
              put("isDefault", addr.isDefault)
            }
          )
        }
      }
      .toString()

  private fun decodeAddresses(raw: String): List<CustomerAddress> =
    runCatching {
        val arr = JSONArray(raw)
        List(arr.length()) { i ->
          val obj = arr.getJSONObject(i)
          CustomerAddress(
            id = obj.optString("id"),
            userId = obj.optString("userId").takeIf { it.isNotBlank() },
            label = obj.optString("label", "Home"),
            fullName = obj.optString("fullName"),
            phone = obj.optString("phone"),
            streetAddress = obj.optString("streetAddress"),
            landmark = obj.optString("landmark"),
            city = obj.optString("city"),
            pincode = obj.optString("pincode"),
            isDefault = obj.optBoolean("isDefault", false),
          )
        }
      }
      .getOrDefault(emptyList())

  private fun encodeRationItems(items: List<RationItem>): String =
    JSONArray()
      .apply {
        items.forEach { item ->
          put(
            JSONObject().apply {
              put("id", item.id)
              put("userId", item.userId ?: "")
              put("productId", item.productId ?: "")
              put("productName", item.productName)
              put("productNameHi", item.productNameHi ?: "")
              put("category", item.category)
              put("variant", item.variant.label)
              put("quantity", item.quantity)
              put("estimatedUnitPrice", item.estimatedUnitPrice)
              put("imageUrl", item.imageUrl ?: "")
            }
          )
        }
      }
      .toString()

  private fun decodeRationItems(raw: String): List<RationItem> =
    runCatching {
        val arr = JSONArray(raw)
        List(arr.length()) { i ->
          val obj = arr.getJSONObject(i)
          RationItem(
            id = obj.optString("id"),
            userId = obj.optString("userId").takeIf { it.isNotBlank() },
            productId = obj.optString("productId").takeIf { it.isNotBlank() },
            productName = obj.optString("productName"),
            productNameHi = obj.optString("productNameHi").takeIf { it.isNotBlank() },
            category = obj.optString("category", "Grocery"),
            variant = QuantityVariant.fromLabel(obj.optString("variant")),
            quantity = obj.optInt("quantity", 1).coerceAtLeast(1),
            estimatedUnitPrice = obj.optDouble("estimatedUnitPrice", 0.0),
            imageUrl = obj.optString("imageUrl").takeIf { it.isNotBlank() },
          )
        }
      }
      .getOrDefault(emptyList())
}
