package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.UserRole
import com.example.ui.components.OrderTimelineStepper
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.KgsUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryPanelScreen(
  state: KgsUiState,
  strings: AppStrings,
  onBack: () -> Unit,
  onRefresh: () -> Unit,
  onUpdateStatus: (String, OrderStatus) -> Unit,
  onMarkDelivered: (String, Boolean) -> Unit,
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  var selectedTab by rememberSaveable { mutableIntStateOf(0) }

  val role = state.authSession?.role
  val isAuthorized = role == UserRole.DELIVERY_PARTNER || role == UserRole.ADMIN
  val scopedOrders = state.deliveryScopedOrders

  val activeDeliveries =
    scopedOrders.filter {
      it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED
    }
  val historyDeliveries =
    scopedOrders.filter {
      it.status == OrderStatus.DELIVERED || it.status == OrderStatus.CANCELLED
    }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.deliveryPanel) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("delivery_back_button")) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(id = R.string.cd_navigate_back),
            )
          }
        },
        actions = {
          IconButton(onClick = onRefresh) {
            Icon(Icons.Filled.Refresh, contentDescription = strings.retryConnection)
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = KgsForest,
            titleContentColor = PureWhite,
            navigationIconContentColor = PureWhite,
            actionIconContentColor = PureWhite,
          ),
      )
    }
  ) { innerPadding ->
    Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      TabRow(selectedTabIndex = selectedTab) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("${strings.assignedDeliveries} (${activeDeliveries.size})") },
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("${strings.deliveryHistory} (${historyDeliveries.size})") },
        )
      }

      val listToShow = if (selectedTab == 0) activeDeliveries else historyDeliveries
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
          modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          if (!isAuthorized) {
            item {
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = StatusWarning.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth().testTag("delivery_role_notice"),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(Icons.Filled.Lock, contentDescription = null, tint = StatusWarning)
                  Text(
                    text =
                      "Sign in as a Delivery Partner or Admin to receive and update assigned delivery orders.",
                    style = MaterialTheme.typography.bodySmall,
                  )
                }
              }
            }
          }

          if (listToShow.isEmpty()) {
            item {
              Text(
                text = "No assigned orders in this view.",
                style = MaterialTheme.typography.bodyMedium,
              )
            }
          } else {
            items(listToShow, key = { it.id.ifBlank { it.orderNumber } }) { order ->
              val isCod = order.paymentMethod == PaymentMethod.COD
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, OutlineSubtle),
              ) {
                Column(
                  modifier = Modifier.padding(14.dp),
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = "${order.orderNumber} • ${order.customerName}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                      )
                      if (order.customerPhone.isNotBlank()) {
                        Text(
                          text = order.customerPhone,
                          style = MaterialTheme.typography.bodySmall,
                          color = KgsEmerald,
                        )
                      }
                    }
                    Text(
                      text = formatInr(order.totalAmount),
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = KgsForest,
                    )
                  }
                  Text(text = order.deliveryAddress, style = MaterialTheme.typography.bodyMedium)
                  if (order.items.isNotEmpty()) {
                    Text(
                      text =
                        order.items.joinToString {
                          "${it.productName} (${it.variant.label} × ${it.quantity})"
                        },
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Text(
                      text =
                        if (isCod) "COD • Collect ${formatInr(order.totalAmount)}"
                        else order.paymentMethod.labelEn,
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.SemiBold,
                      color = if (isCod) StatusWarning else KgsForest,
                    )
                    PaymentStatusBadge(order.parsedPaymentStatus, state.language)
                  }

                  OrderTimelineStepper(status = order.status, language = state.language)

                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                      onClick = {
                        val dialIntent =
                          Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.customerPhone}"))
                        runCatching { context.startActivity(dialIntent) }
                      },
                      enabled = isAuthorized && order.customerPhone.isNotBlank(),
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Filled.Call, contentDescription = "Call Customer")
                      Spacer(modifier = Modifier.width(4.dp))
                      Text("Call")
                    }
                    OutlinedButton(
                      onClick = {
                        val mapIntent =
                          Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("geo:0,0?q=${Uri.encode(order.deliveryAddress)}"),
                          )
                        runCatching { context.startActivity(mapIntent) }
                      },
                      enabled = isAuthorized && order.deliveryAddress.isNotBlank(),
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Filled.Directions, contentDescription = "Open Maps")
                      Spacer(modifier = Modifier.width(4.dp))
                      Text("Maps")
                    }
                  }

                  if (selectedTab == 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      OutlinedButton(
                        onClick = { onUpdateStatus(order.id, OrderStatus.OUT_FOR_DELIVERY) },
                        enabled = isAuthorized && order.status != OrderStatus.OUT_FOR_DELIVERY,
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                      ) {
                        Text("Out for Delivery", maxLines = 1)
                      }
                      Button(
                        onClick = { onMarkDelivered(order.id, isCod) },
                        enabled = isAuthorized,
                        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                      ) {
                        Text(
                          if (isCod) "Collect Cash & Deliver" else "Mark Delivered",
                          maxLines = 1,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
