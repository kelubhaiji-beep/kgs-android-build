package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.i18n.stringsFor
import com.example.model.AppDestination
import com.example.model.UserRole
import com.example.ui.components.KgsBrandTopHeader
import com.example.ui.screens.AccountAndAuthScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.CartCheckoutScreen
import com.example.ui.screens.DeliveryPanelScreen
import com.example.ui.screens.DistributorPanelScreen
import com.example.ui.screens.HomeCatalogScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.RationListScreen
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.PureWhite
import com.example.ui.viewmodel.KgsViewModel

private data class NavTabItem(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val badgeCount: Int = 0,
  val testTag: String,
)

@Composable
fun KgsApp(viewModel: KgsViewModel = viewModel()) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val strings = remember(state.language) { stringsFor(state.language) }
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route
  val snackbarHostState = remember { SnackbarHostState() }
  var showLocationPicker by rememberSaveable { mutableStateOf(false) }

  LaunchedEffect(state.snackbarMessage) {
    val msg = state.snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  val topLevelTabs =
    listOf(
      NavTabItem(
        route = AppDestination.HOME.route,
        label = strings.navHome,
        selectedIcon = Icons.Filled.Storefront,
        unselectedIcon = Icons.Outlined.Storefront,
        testTag = "nav_home",
      ),
      NavTabItem(
        route = AppDestination.CART.route,
        label = strings.navCart,
        selectedIcon = Icons.Filled.ShoppingCart,
        unselectedIcon = Icons.Outlined.ShoppingCart,
        badgeCount = state.cartCount,
        testTag = "nav_cart",
      ),
      NavTabItem(
        route = AppDestination.RATION.route,
        label = strings.navRation,
        selectedIcon = Icons.Filled.Checklist,
        unselectedIcon = Icons.Outlined.Checklist,
        badgeCount = state.rationItems.size,
        testTag = "nav_ration",
      ),
      NavTabItem(
        route = AppDestination.ORDERS.route,
        label = strings.navOrders,
        selectedIcon = Icons.AutoMirrored.Filled.ReceiptLong,
        unselectedIcon = Icons.AutoMirrored.Outlined.ReceiptLong,
        testTag = "nav_orders",
      ),
      NavTabItem(
        route = AppDestination.ACCOUNT.route,
        label = strings.navAccount,
        selectedIcon = Icons.Filled.AccountCircle,
        unselectedIcon = Icons.Outlined.AccountCircle,
        testTag = "nav_account",
      ),
    )

  val isTopLevelRoute = topLevelTabs.any { it.route == currentRoute }

  fun navigateTopTab(route: String) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  if (showLocationPicker) {
    AlertDialog(
      onDismissRequest = { showLocationPicker = false },
      title = { Text(strings.deliveryAddress) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          if (state.addresses.isEmpty()) {
            Text(
              text = strings.selectOrAddAddress,
              style = MaterialTheme.typography.bodyMedium,
            )
          } else {
            state.addresses.forEach { addr ->
              OutlinedButton(
                onClick = {
                  viewModel.selectAddress(addr.id)
                  showLocationPicker = false
                },
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
              ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                  Text(
                    text = "${addr.label} • ${addr.fullName}",
                    fontWeight = FontWeight.Bold,
                  )
                  Text(text = addr.formatted(), style = MaterialTheme.typography.bodySmall)
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            showLocationPicker = false
            navigateTopTab(AppDestination.ACCOUNT.route)
          }
        ) {
          Text(strings.addNewAddress)
        }
      },
      dismissButton = {
        TextButton(onClick = { showLocationPicker = false }) { Text(strings.cancel) }
      },
    )
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useNavRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useNavRail && isTopLevelRoute) {
        NavigationRail(
          containerColor = PureWhite,
          modifier = Modifier.fillMaxHeight(),
        ) {
          topLevelTabs.forEach { tab ->
            val selected = currentRoute == tab.route
            NavigationRailItem(
              selected = selected,
              onClick = { navigateTopTab(tab.route) },
              icon = {
                TabIconWithBadge(
                  icon = if (selected) tab.selectedIcon else tab.unselectedIcon,
                  label = tab.label,
                  badgeCount = tab.badgeCount,
                )
              },
              label = { Text(tab.label) },
              colors =
                NavigationRailItemDefaults.colors(
                  selectedIconColor = KgsForest,
                  selectedTextColor = KgsForest,
                  indicatorColor = KgsMintContainer,
                ),
              modifier = Modifier.testTag(tab.testTag),
            )
          }
        }
      }

      Scaffold(
        modifier = Modifier.weight(1f).fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
          if (isTopLevelRoute) {
            KgsBrandTopHeader(
              strings = strings,
              language = state.language,
              selectedAddress = state.selectedAddress,
              isSupabaseConnected =
                state.catalogError == null &&
                  (state.schemaInspection?.isConnected == true || state.products.isNotEmpty()),
              onToggleLanguage = { viewModel.toggleLanguage() },
              onAddressClick = { showLocationPicker = true },
            )
          }
        },
        bottomBar = {
          if (!useNavRail && isTopLevelRoute) {
            NavigationBar(
              containerColor = PureWhite,
              windowInsets = WindowInsets.navigationBars,
            ) {
              topLevelTabs.forEach { tab ->
                val selected = currentRoute == tab.route
                NavigationBarItem(
                  selected = selected,
                  onClick = { navigateTopTab(tab.route) },
                  icon = {
                    TabIconWithBadge(
                      icon = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      label = tab.label,
                      badgeCount = tab.badgeCount,
                    )
                  },
                  label = { Text(tab.label, maxLines = 1) },
                  colors =
                    NavigationBarItemDefaults.colors(
                      selectedIconColor = KgsForest,
                      selectedTextColor = KgsForest,
                      indicatorColor = KgsMintContainer,
                    ),
                  modifier = Modifier.testTag(tab.testTag),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
          NavHost(
            navController = navController,
            startDestination = AppDestination.HOME.route,
          ) {
            composable(AppDestination.HOME.route) {
              HomeCatalogScreen(
                state = state,
                strings = strings,
                onSearchChange = viewModel::updateSearchQuery,
                onCategorySelect = viewModel::selectCategory,
                onShopSelect = viewModel::selectShop,
                onToggleInStock = viewModel::toggleInStockOnly,
                onRefreshCatalog = viewModel::refreshCatalogAndSchema,
                onProductClick = { product ->
                  navController.navigate(AppDestination.productDetailRoute(product.id))
                },
                onAddToCart = { product, variant -> viewModel.addToCart(product, variant, 1) },
                onUpdateCartQty = { product, variant, qty ->
                  viewModel.updateCartQuantity(product.id, variant, qty)
                },
                onOpenSchemaInspector = { navController.navigate(AppDestination.ADMIN.route) },
              )
            }

            composable(AppDestination.CART.route) {
              CartCheckoutScreen(
                state = state,
                strings = strings,
                onBrowseProducts = { navigateTopTab(AppDestination.HOME.route) },
                onUpdateQty = viewModel::updateCartQuantity,
                onSelectAddress = viewModel::selectAddress,
                onSaveAddress = viewModel::saveAddress,
                onShowMessage = viewModel::showMessage,
                onPlaceOrder = viewModel::placeOrder,
                onOrderSuccessNavigate = { navigateTopTab(AppDestination.ORDERS.route) },
              )
            }

            composable(AppDestination.RATION.route) {
              RationListScreen(
                state = state,
                strings = strings,
                onAddCustomRation = viewModel::addCustomRationItem,
                onEditRationItem = viewModel::editRationItem,
                onUpdateRationQty = viewModel::updateRationQuantity,
                onAddAllToCart = {
                  viewModel.addAllRationToCart()
                  navigateTopTab(AppDestination.CART.route)
                },
              )
            }

            composable(AppDestination.ORDERS.route) {
              OrdersScreen(
                state = state,
                strings = strings,
                onRefreshOrders = viewModel::refreshOrders,
                onSubmitUpiRef = viewModel::submitOrderUpiReference,
                onCancelOrder = viewModel::cancelOrder,
                onReorder = { order ->
                  val count = viewModel.reorderToCart(order)
                  if (count > 0) navigateTopTab(AppDestination.CART.route)
                },
              )
            }

            composable(AppDestination.ACCOUNT.route) {
              AccountAndAuthScreen(
                state = state,
                strings = strings,
                onToggleLanguage = viewModel::toggleLanguage,
                onRequestOtp = viewModel::requestPhoneOtp,
                onVerifyOtp = viewModel::verifyPhoneOtp,
                onSignInEmail = viewModel::signInWithEmail,
                onSignUpEmail = viewModel::signUpWithEmail,
                onUpdateProfile = viewModel::updateCustomerProfile,
                onSignOut = viewModel::signOut,
                onSaveAddress = viewModel::saveAddress,
                onSetDefaultAddress = viewModel::setDefaultAddress,
                onDeleteAddress = viewModel::deleteAddress,
                onOpenDistributorPanel = {
                  viewModel.refreshPanelData()
                  navController.navigate(AppDestination.DISTRIBUTOR.route)
                },
                onOpenDeliveryPanel = {
                  viewModel.refreshOrders()
                  navController.navigate(AppDestination.DELIVERY.route)
                },
                onOpenAdminPanel = {
                  viewModel.refreshPanelData()
                  navController.navigate(AppDestination.ADMIN.route)
                },
              )
            }

            composable(
              route = AppDestination.PRODUCT_DETAIL.route,
              arguments = listOf(navArgument("productId") { type = NavType.StringType }),
            ) { backStack ->
              val productId = backStack.arguments?.getString("productId").orEmpty()
              val product = state.products.firstOrNull { it.id == productId }
              if (product != null) {
                ProductDetailScreen(
                  product = product,
                  language = state.language,
                  strings = strings,
                  canEditPrice = state.canEditProduct(product),
                  onBack = { navController.popBackStack() },
                  onAddToCart = { p, v -> viewModel.addToCart(p, v, 1) },
                  onAddToRation = viewModel::addToRation,
                  onSavePriceAndStock = viewModel::saveProductPriceAndStock,
                )
              }
            }

            composable(AppDestination.DISTRIBUTOR.route) {
              DistributorPanelScreen(
                state = state,
                strings = strings,
                onBack = { navController.popBackStack() },
                onRefresh = {
                  viewModel.refreshCatalogAndSchema()
                  viewModel.refreshPanelData()
                },
                onRegisterShop = viewModel::registerDistributorShop,
                onSaveProduct = viewModel::saveProductPriceAndStock,
                onDeleteProduct = viewModel::deleteProduct,
                onUpdateOrderStatus = { orderId, status ->
                  viewModel.updateOrderStatus(orderId, status)
                },
              )
            }

            composable(AppDestination.DELIVERY.route) {
              DeliveryPanelScreen(
                state = state,
                strings = strings,
                onBack = { navController.popBackStack() },
                onRefresh = viewModel::refreshOrders,
                onUpdateStatus = { orderId, status ->
                  viewModel.updateOrderStatus(orderId, status)
                },
                onMarkDelivered = viewModel::markDeliveryCompleted,
              )
            }

            composable(AppDestination.ADMIN.route) {
              AdminPanelScreen(
                state = state,
                strings = strings,
                onBack = { navController.popBackStack() },
                onInspectSchema = viewModel::inspectSchemaOnly,
                onRefreshAdminData = {
                  viewModel.refreshCatalogAndSchema()
                  viewModel.refreshPanelData()
                },
                onApproveShop = viewModel::adminApproveShop,
                onUpdateUserRole = viewModel::adminUpdateRole,
                onToggleUserActive = viewModel::adminToggleUserActive,
                onUpdateOrderStatus = { orderId, status ->
                  viewModel.updateOrderStatus(orderId, status)
                },
                onVerifyUpiPayment = viewModel::adminVerifyUpiPayment,
                onMarkCodCollected = viewModel::adminMarkCodCollected,
                onUpdateRefund = viewModel::adminUpdateRefund,
                onAssignDeliveryPartner = viewModel::adminAssignDeliveryPartner,
                onSaveProduct = viewModel::saveProductPriceAndStock,
                onDeleteProduct = viewModel::deleteProduct,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TabIconWithBadge(icon: ImageVector, label: String, badgeCount: Int) {
  BadgedBox(
    badge = {
      if (badgeCount > 0) {
        Badge(containerColor = KgsEmerald, contentColor = PureWhite) {
          Text(
            text = if (badgeCount > 99) "99+" else badgeCount.toString(),
            style = MaterialTheme.typography.labelSmall,
          )
        }
      }
    }
  ) {
    Icon(imageVector = icon, contentDescription = label)
  }
}
