package com.example.model

import kotlin.math.roundToInt

enum class AppLanguage(val code: String, val displayName: String) {
  ENGLISH("en", "EN"),
  HINDI("hi", "हिन्दी"),
}

enum class UserRole(val dbValue: String, val labelEn: String, val labelHi: String) {
  CUSTOMER("customer", "Customer", "ग्राहक"),
  DISTRIBUTOR("distributor", "Distributor", "वितरक"),
  DELIVERY_PARTNER("delivery_partner", "Delivery Partner", "डिलीवरी पार्टनर"),
  ADMIN("admin", "Admin", "एडमिन");

  companion object {
    fun fromDb(value: String?): UserRole =
      entries.firstOrNull {
        it.dbValue.equals(value?.trim(), ignoreCase = true) ||
          it.name.equals(value?.trim(), ignoreCase = true)
      } ?: CUSTOMER
  }
}

enum class QuantityVariant(
  val label: String,
  val grams: Int,
  val multiplierFromKg: Double,
) {
  G100("100g", 100, 0.1),
  G200("200g", 200, 0.2),
  G250("250g", 250, 0.25),
  G500("500g", 500, 0.5),
  KG1("1kg", 1000, 1.0),
  KG2("2kg", 2000, 2.0),
  KG5("5kg", 5000, 5.0),
  KG10("10kg", 10000, 10.0);

  companion object {
    val standardGroceryOptions: List<QuantityVariant> =
      listOf(G100, G200, G250, G500, KG1, KG2, KG5)

    fun fromLabel(label: String?): QuantityVariant =
      entries.firstOrNull { it.label.equals(label?.trim(), ignoreCase = true) } ?: KG1
  }
}

data class ProductVariantOption(
  val variant: QuantityVariant,
  val price: Double,
  val stockQty: Int = 0,
)

object CategoryHindiDictionary {
  private val map =
    mapOf(
      "grains" to "अनाज और आटा",
      "grains & atta" to "अनाज और आटा",
      "atta" to "आटा और अनाज",
      "atta & flour" to "आटा और मैदा",
      "flour" to "आटा और बेसन",
      "rice" to "चावल",
      "dal" to "दालें",
      "dal & pulses" to "दालें और दलहन",
      "pulses" to "दालें",
      "oil" to "तेल और घी",
      "oil & ghee" to "तेल और घी",
      "cooking oil" to "खाना पकाने का तेल",
      "ghee" to "देसी घी",
      "spices" to "मसाले",
      "spices & masala" to "मसाले",
      "masala" to "मसाले",
      "sugar & salt" to "चीनी और नमक",
      "salt & sugar" to "नमक और चीनी",
      "tea & coffee" to "चाय और कॉफी",
      "beverages" to "पेय पदार्थ",
      "drinks" to "पेय पदार्थ",
      "snacks" to "स्नैक्स और नमकीन",
      "biscuits" to "बिस्कुट और कुकीज़",
      "biscuits & snacks" to "बिस्कुट और स्नैक्स",
      "dairy" to "डेयरी और दूध",
      "dairy & bakery" to "डेयरी और बेकरी",
      "personal care" to "पर्सनल केयर",
      "cleaning" to "सफाई सामग्री",
      "household" to "घरेलू सामान",
      "cleaning & household" to "सफाई और घरेलू सामान",
      "dry fruits" to "सूखे मेवे",
      "dry fruits & nuts" to "ड्राई फ्रूट्स और मेवे",
      "instant food" to "नूडल्स और इंस्टेंट फूड",
      "noodles & pasta" to "नूडल्स और पास्ता",
      "pooja" to "पूजा सामग्री",
      "pooja items" to "पूजा सामग्री",
      "stationery" to "स्टेशनरी",
      "baby care" to "बेबी केयर",
      "grocery" to "किराना",
      "general" to "जनरल सामान",
    )

  fun translate(category: String): String? {
    val normalized = category.trim().lowercase()
    map[normalized]?.let { return it }
    return map.entries.firstOrNull { (k, _) -> normalized.contains(k) }?.value
  }
}

data class Product(
  val id: String,
  val name: String,
  val nameHi: String? = null,
  val category: String,
  val categoryId: String? = null,
  val categoryHi: String? = null,
  val description: String = "",
  val imageUrl: String? = null,
  val basePrice: Double,
  val baseUnit: String = "1kg",
  val stockQty: Int = 0,
  val isAvailable: Boolean = true,
  val shopId: String? = null,
  val distributorId: String? = null,
  val shopName: String? = null,
  val variantPrices: Map<QuantityVariant, Double> = emptyMap(),
) {
  val isWeightBased: Boolean
    get() {
      val unit = baseUnit.trim().lowercase()
      return unit.isBlank() ||
        unit.endsWith("kg") ||
        unit.endsWith("g") ||
        unit.endsWith("gm") ||
        unit.endsWith("gms") ||
        unit == "weight"
    }

  fun displayName(language: AppLanguage): String =
    if (language == AppLanguage.HINDI && !nameHi.isNullOrBlank()) nameHi else name

  fun displayCategory(language: AppLanguage): String =
    if (language == AppLanguage.HINDI) {
      categoryHi?.takeIf { it.isNotBlank() }
        ?: CategoryHindiDictionary.translate(category)
        ?: category
    } else {
      category
    }

  fun applicableVariants(): List<QuantityVariant> =
    if (isWeightBased) QuantityVariant.standardGroceryOptions else listOf(QuantityVariant.KG1)

  fun priceFor(variant: QuantityVariant): Double {
    variantPrices[variant]?.let { return it }
    if (!isWeightBased) return basePrice
    val baseGrams =
      when (baseUnit.lowercase().trim()) {
        "100g", "100gm" -> 100.0
        "200g", "200gm" -> 200.0
        "250g", "250gm" -> 250.0
        "500g", "500gm" -> 500.0
        "2kg" -> 2000.0
        "5kg" -> 5000.0
        "10kg" -> 10000.0
        else -> 1000.0
      }
    val scaled = basePrice * (variant.grams / baseGrams)
    return (scaled * 100.0).roundToInt() / 100.0
  }
}

data class Category(
  val id: String,
  val name: String,
  val nameHi: String? = null,
  val imageUrl: String? = null,
  val productCount: Int = 0,
) {
  fun displayName(language: AppLanguage): String =
    if (language == AppLanguage.HINDI) {
      nameHi?.takeIf { it.isNotBlank() }
        ?: CategoryHindiDictionary.translate(name)
        ?: name
    } else {
      name
    }
}

data class CustomerAddress(
  val id: String,
  val userId: String? = null,
  val label: String = "Home",
  val fullName: String,
  val phone: String,
  val streetAddress: String,
  val landmark: String = "",
  val city: String,
  val pincode: String,
  val isDefault: Boolean = false,
) {
  fun formatted(): String =
    buildString {
      append(streetAddress.trim())
      if (landmark.isNotBlank()) append(", Near ${landmark.trim()}")
      append(", ${city.trim()} - ${pincode.trim()}")
    }
}

data class CartItem(
  val product: Product,
  val variant: QuantityVariant,
  val quantity: Int,
) {
  val unitPrice: Double
    get() = product.priceFor(variant)

  val lineTotal: Double
    get() = unitPrice * quantity

  fun variantDisplayLabel(): String =
    if (product.isWeightBased) variant.label else product.baseUnit.ifBlank { "1 pack" }
}

data class RationItem(
  val id: String,
  val userId: String? = null,
  val productId: String? = null,
  val productName: String,
  val productNameHi: String? = null,
  val category: String = "Grocery",
  val variant: QuantityVariant = QuantityVariant.KG1,
  val quantity: Int = 1,
  val estimatedUnitPrice: Double = 0.0,
  val imageUrl: String? = null,
)

enum class PaymentMethod(val dbValue: String, val labelEn: String, val labelHi: String) {
  COD("cod", "Cash on Delivery (COD)", "कैश ऑन डिलीवरी (COD)"),
  UPI("upi", "Kotak UPI", "कोटक UPI भुगतान"),
}

enum class PaymentStatus(val dbValue: String, val labelEn: String, val labelHi: String) {
  PENDING_VERIFICATION("pending_verification", "Pending Verification", "सत्यापन लंबित"),
  UPI_VERIFIED("upi_verified", "UPI Verified", "UPI सत्यापित"),
  UPI_REJECTED("upi_rejected", "UPI Not Received", "UPI भुगतान अस्वीकृत"),
  COD_PENDING("cod_pending", "COD Pending", "COD भुगतान बाकी"),
  COD_COLLECTED("cod_collected", "COD Collected", "COD नकद प्राप्त"),
  REFUNDED("refunded", "Refunded", "रिफंड पूर्ण");

  companion object {
    fun fromDb(value: String?): PaymentStatus {
      val clean = value?.trim()?.lowercase().orEmpty()
      return when (clean) {
        "pending_verification", "upi_unverified", "pending" -> PENDING_VERIFICATION
        "upi_verified", "paid", "verified" -> UPI_VERIFIED
        "upi_rejected", "rejected", "failed" -> UPI_REJECTED
        "cod_collected", "collected" -> COD_COLLECTED
        "refunded" -> REFUNDED
        "cod_pending" -> COD_PENDING
        else -> PENDING_VERIFICATION
      }
    }
  }
}

enum class OrderStatus(val dbValue: String, val labelEn: String, val labelHi: String) {
  PLACED("pending", "Pending", "लंबित"),
  CONFIRMED("accepted", "Accepted", "स्वीकृत"),
  PACKED("preparing", "Preparing", "तैयार हो रहा है"),
  OUT_FOR_DELIVERY("out_for_delivery", "Out for Delivery", "डिलीवरी के लिए निकला"),
  DELIVERED("delivered", "Delivered", "डिलीवर हुआ"),
  CANCELLED("cancelled", "Cancelled", "रद्द हुआ");

  companion object {
    fun fromDb(value: String?): OrderStatus {
      val clean = value?.trim()?.lowercase().orEmpty()
      return when (clean) {
        "pending", "placed" -> PLACED
        "accepted", "confirmed" -> CONFIRMED
        "preparing", "packed" -> PACKED
        "out_for_delivery" -> OUT_FOR_DELIVERY
        "delivered" -> DELIVERED
        "cancelled", "canceled" -> CANCELLED
        else -> entries.firstOrNull { it.name.equals(clean, ignoreCase = true) } ?: PLACED
      }
    }
  }
}

data class OrderItem(
  val productId: String,
  val productName: String,
  val variant: QuantityVariant,
  val quantity: Int,
  val unitPrice: Double,
  val shopId: String? = null,
)

data class Order(
  val id: String,
  val orderNumber: String,
  val customerId: String? = null,
  val customerName: String,
  val customerPhone: String,
  val deliveryAddress: String,
  val items: List<OrderItem> = emptyList(),
  val deliveryFee: Double = 0.0,
  val totalAmount: Double,
  val paymentMethod: PaymentMethod = PaymentMethod.COD,
  val paymentStatus: String = PaymentStatus.COD_PENDING.dbValue,
  val upiReference: String? = null,
  val customerMarkedPaid: Boolean = false,
  val paymentVerifiedBy: String? = null,
  val paymentVerifiedAt: String? = null,
  val refundStatus: String = "none",
  val cancellationReason: String? = null,
  val status: OrderStatus = OrderStatus.PLACED,
  val shopId: String? = null,
  val distributorId: String? = null,
  val deliveryPartnerId: String? = null,
  val deliveryPartnerName: String? = null,
  val createdAt: String = "",
) {
  val parsedPaymentStatus: PaymentStatus
    get() =
      if (paymentMethod == PaymentMethod.COD && paymentStatus == "pending") {
        PaymentStatus.COD_PENDING
      } else {
        PaymentStatus.fromDb(paymentStatus)
      }
}

data class Shop(
  val id: String,
  val ownerId: String? = null,
  val shopName: String,
  val ownerName: String,
  val phone: String,
  val address: String,
  val city: String,
  val pincode: String,
  val gstNumber: String = "",
  val isApproved: Boolean = false,
  val isActive: Boolean = true,
)

data class UserProfile(
  val id: String,
  val fullName: String,
  val phone: String = "",
  val email: String = "",
  val role: UserRole = UserRole.CUSTOMER,
  val isActive: Boolean = true,
)

data class AuthSession(
  val accessToken: String,
  val refreshToken: String = "",
  val userId: String,
  val email: String = "",
  val phone: String = "",
  val fullName: String = "",
  val role: UserRole = UserRole.CUSTOMER,
)

data class SchemaColumnInfo(
  val name: String,
  val type: String,
  val format: String = "",
  val isRequired: Boolean = false,
)

data class SchemaTableInfo(
  val tableName: String,
  val columns: List<SchemaColumnInfo>,
  val rowCount: Int? = null,
  val accessStatus: String = "Readable",
)

data class SchemaInspectionResult(
  val inspectedAt: String,
  val isConnected: Boolean,
  val tables: List<SchemaTableInfo> = emptyList(),
  val detectedMappings: Map<String, String> = emptyMap(),
  val inspectionMethod: String = "Safe Client Table Probes (RLS-Respecting)",
  val errorMessage: String? = null,
)

enum class AppDestination(val route: String) {
  HOME("home"),
  CART("cart"),
  RATION("ration"),
  ORDERS("orders"),
  ACCOUNT("account"),
  PRODUCT_DETAIL("product_detail/{productId}"),
  DISTRIBUTOR("distributor"),
  DELIVERY("delivery"),
  ADMIN("admin");

  companion object {
    fun productDetailRoute(productId: String) = "product_detail/$productId"
  }
}
