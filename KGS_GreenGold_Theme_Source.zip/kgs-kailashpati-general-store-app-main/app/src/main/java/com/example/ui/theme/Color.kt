package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KGS Emerald + Gold premium palette. High-contrast text is intentional for readability.
val KgsEmerald = Color(0xFF075B32)
val KgsForest = Color(0xFF063B25)
val KgsLeaf = Color(0xFF16834A)
val KgsMintBg = Color(0xFFF4F8F3)
val KgsMintContainer = Color(0xFFDDEFE1)
val KgsOnMintContainer = Color(0xFF123B25)

// Gold is an accent for rewards, highlights and premium actions—not a warning/status color.
val KgsSaffron = Color(0xFFD6A52B)
val KgsSaffronContainer = Color(0xFFFFF0C2)
val KgsOnSaffronContainer = Color(0xFF4A3500)
val KgsGold = Color(0xFFE3B341)
val KgsGoldDeep = Color(0xFF8A6410)

val PureWhite = Color(0xFFFFFFFF)
val SoftWhite = Color(0xFFFFFEFA)
val OutlineSubtle = Color(0xFFB9CCBE)
val TextPrimary = Color(0xFF14251A)
val TextSecondary = Color(0xFF405B49)

val StatusSuccess = Color(0xFF176B3A)
val StatusWarning = Color(0xFF8A5A00)
val StatusError = Color(0xFFB3261E)
val StatusErrorContainer = Color(0xFFFFDAD6)

// Dark mode equivalents with accessible contrast.
val KgsEmeraldDark = Color(0xFF83D9A1)
val KgsOnEmeraldDark = Color(0xFF00391C)
val KgsContainerDark = Color(0xFF174F32)
val KgsSurfaceDark = Color(0xFF101A13)
val KgsSurfaceContainerDark = Color(0xFF1A291F)
val KgsTextDark = Color(0xFFF0F5F0)
val KgsTextSecondaryDark = Color(0xFFC0D1C4)
