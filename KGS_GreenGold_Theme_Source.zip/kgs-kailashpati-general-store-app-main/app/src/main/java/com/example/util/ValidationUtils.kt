package com.example.util

import android.net.Uri
import android.util.Patterns
import com.example.model.CustomerAddress

sealed interface ValidationResult {
  data object Valid : ValidationResult

  data class Invalid(val messageEn: String, val messageHi: String) : ValidationResult
}

object ValidationUtils {
  fun normalizeIndianPhone(raw: String): String {
    val digits = raw.filter { it.isDigit() }
    return when {
      digits.length == 10 -> "+91$digits"
      digits.length == 12 && digits.startsWith("91") -> "+$digits"
      raw.startsWith("+") && digits.length >= 10 -> "+$digits"
      else -> raw.trim()
    }
  }

  fun validateIndianPhone(raw: String): ValidationResult {
    val digits = raw.filter { it.isDigit() }
    val tenDigits =
      when {
        digits.length == 10 -> digits
        digits.length == 12 && digits.startsWith("91") -> digits.drop(2)
        else -> ""
      }
    return if (tenDigits.length == 10 && tenDigits.first() in '6'..'9') {
      ValidationResult.Valid
    } else {
      ValidationResult.Invalid(
        "Enter a valid 10-digit Indian mobile number",
        "कृपया मान्य 10 अंकों का मोबाइल नंबर दर्ज करें",
      )
    }
  }

  fun validateOtp(otp: String): ValidationResult {
    val cleaned = otp.trim()
    return if (cleaned.length == 6 && cleaned.all { it.isDigit() }) {
      ValidationResult.Valid
    } else {
      ValidationResult.Invalid("Enter the 6-digit OTP", "कृपया 6 अंकों का OTP दर्ज करें")
    }
  }

  fun validateEmail(email: String): ValidationResult {
    val trimmed = email.trim()
    return if (trimmed.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()) {
      ValidationResult.Valid
    } else {
      ValidationResult.Invalid("Enter a valid email address", "कृपया मान्य ईमेल पता दर्ज करें")
    }
  }

  fun validatePassword(password: String): ValidationResult {
    return if (password.length >= 6) {
      ValidationResult.Valid
    } else {
      ValidationResult.Invalid(
        "Password must be at least 6 characters",
        "पासवर्ड कम से कम 6 अक्षरों का होना चाहिए",
      )
    }
  }

  fun validateAddress(address: CustomerAddress): ValidationResult {
    if (address.fullName.trim().length < 2) {
      return ValidationResult.Invalid("Enter recipient full name", "प्राप्तकर्ता का पूरा नाम दर्ज करें")
    }
    val phoneResult = validateIndianPhone(address.phone)
    if (phoneResult is ValidationResult.Invalid) return phoneResult
    if (address.streetAddress.trim().length < 5) {
      return ValidationResult.Invalid(
        "Enter house no., street and locality",
        "मकान नंबर, गली और मोहल्ला दर्ज करें",
      )
    }
    if (address.city.trim().length < 2) {
      return ValidationResult.Invalid("Enter city or town name", "शहर या कस्बे का नाम दर्ज करें")
    }
    val pinDigits = address.pincode.trim()
    if (pinDigits.length != 6 || !pinDigits.all { it.isDigit() }) {
      return ValidationResult.Invalid(
        "Enter a valid 6-digit pincode",
        "कृपया मान्य 6 अंकों का पिनकोड दर्ज करें",
      )
    }
    return ValidationResult.Valid
  }

  fun validatePriceAndStock(priceText: String, stockText: String): ValidationResult {
    val price = priceText.toDoubleOrNull()
    val stock = stockText.toIntOrNull()
    if (price == null || price <= 0.0) {
      return ValidationResult.Invalid(
        "Price must be greater than ₹0",
        "कीमत ₹0 से अधिक होनी चाहिए",
      )
    }
    if (stock == null || stock < 0) {
      return ValidationResult.Invalid(
        "Stock quantity cannot be negative",
        "स्टॉक मात्रा शून्य से कम नहीं हो सकती",
      )
    }
    return ValidationResult.Valid
  }

  fun validateUpiReference(rawRef: String): ValidationResult {
    val cleaned = rawRef.trim()
    if (cleaned.isEmpty()) return ValidationResult.Valid
    return if (cleaned.length in 6..35 && cleaned.all { it.isLetterOrDigit() || it == '-' || it == '_' }) {
      ValidationResult.Valid
    } else {
      ValidationResult.Invalid(
        "UPI transaction reference should be 6–35 alphanumeric characters",
        "UPI रेफरेंस नंबर 6 से 35 अक्षरों/अंकों का होना चाहिए",
      )
    }
  }

  fun buildUpiPaymentUri(
    merchantVpa: String,
    merchantName: String,
    orderRef: String,
    amount: Double,
  ): Uri {
    val formattedAmount = String.format(java.util.Locale.US, "%.2f", amount)
    return Uri.parse("upi://pay")
      .buildUpon()
      .appendQueryParameter("pa", merchantVpa)
      .appendQueryParameter("pn", merchantName)
      .appendQueryParameter("tr", orderRef)
      .appendQueryParameter("tn", "KGS Order $orderRef")
      .appendQueryParameter("am", formattedAmount)
      .appendQueryParameter("cu", "INR")
      .build()
  }
}
