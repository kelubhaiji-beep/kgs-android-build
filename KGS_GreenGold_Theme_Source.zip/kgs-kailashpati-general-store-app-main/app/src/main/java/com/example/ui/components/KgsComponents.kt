package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.AppLanguage
import com.example.model.CustomerAddress
import com.example.model.OrderStatus
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintBg
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.KgsSaffron
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.util.QrCodeGenerator
import com.example.util.ValidationUtils
import java.util.Locale

fun formatInr(amount: Double): String {
  return if (amount % 1.0 == 0.0) {
    "₹${amount.toInt()}"
  } else {
    "₹${String.format(Locale.US, "%.2f", amount)}"
  }
}

@Composable
fun KgsBrandTopHeader(
  strings: AppStrings,
  language: AppLanguage,
  selectedAddress: CustomerAddress?,
  isSupabaseConnected: Boolean,
  onToggleLanguage: () -> Unit,
  onAddressClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .background(
          Brush.verticalGradient(
            colors = listOf(KgsForest, KgsEmerald),
          )
        )
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = PureWhite,
            shadowElevation = 2.dp,
            modifier = Modifier.size(44.dp),
          ) {
            Image(
              painter = painterResource(id = R.drawable.kgs_logo),
              contentDescription = stringResource(id = R.string.cd_kgs_logo),
              contentScale = ContentScale.Fit,
              modifier = Modifier.padding(2.dp),
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = strings.storeFullName,
              style = MaterialTheme.typography.titleMedium,
              color = PureWhite,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier =
                  Modifier.size(8.dp)
                    .clip(CircleShape)
                    .background(if (isSupabaseConnected) Color(0xFF81F796) else KgsSaffron)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = strings.tagline,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFE1F5E4),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }

        Surface(
          onClick = onToggleLanguage,
          shape = RoundedCornerShape(50),
          color = PureWhite.copy(alpha = 0.18f),
          border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.35f)),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("language_toggle_button"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Translate,
              contentDescription = strings.languageLabel,
              tint = PureWhite,
              modifier = Modifier.size(16.dp),
            )
            Text(
              text = if (language == AppLanguage.ENGLISH) "EN / हिं" else "हिं / EN",
              style = MaterialTheme.typography.labelMedium,
              color = PureWhite,
            )
          }
        }
      }

      Surface(
        onClick = onAddressClick,
        shape = RoundedCornerShape(10.dp),
        color = PureWhite.copy(alpha = 0.14f),
        modifier = Modifier.fillMaxWidth().testTag("header_address_pill"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Filled.LocationOn,
            contentDescription = strings.deliveryAddress,
            tint = KgsSaffron,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text =
              selectedAddress?.let { "${it.label}: ${it.formatted()}" }
                ?: strings.selectOrAddAddress,
            style = MaterialTheme.typography.bodySmall,
            color = PureWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
fun SupabaseStatusCard(
  title: String,
  body: String,
  buttonLabel: String,
  isConnected: Boolean,
  onAction: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth().testTag("supabase_status_card"),
    shape = RoundedCornerShape(16.dp),
    colors =
      CardDefaults.cardColors(
        containerColor = if (isConnected) KgsMintContainer else MaterialTheme.colorScheme.surface
      ),
    border =
      BorderStroke(
        1.dp,
        if (isConnected) KgsEmerald.copy(alpha = 0.3f) else StatusWarning.copy(alpha = 0.45f),
      ),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Icon(
          imageVector = if (isConnected) Icons.Filled.CheckCircle else Icons.Filled.CloudOff,
          contentDescription = title,
          tint = if (isConnected) StatusSuccess else StatusWarning,
          modifier = Modifier.size(26.dp),
        )
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
        )
      }
      Text(
        text = body,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      OutlinedButton(
        onClick = onAction,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("supabase_action_button"),
        shape = RoundedCornerShape(12.dp),
      ) {
        Text(text = buttonLabel)
      }
    }
  }
}

@Composable
fun GroceryProductCard(
  product: Product,
  language: AppLanguage,
  strings: AppStrings,
  selectedVariant: QuantityVariant,
  cartQty: Int,
  onCardClick: () -> Unit,
  onAddToCart: () -> Unit,
  onUpdateQty: (Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  val packPrice = product.priceFor(selectedVariant)
  val unitLabel = if (product.isWeightBased) selectedVariant.label else product.baseUnit

  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onCardClick)
        .testTag("product_card_${product.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, OutlineSubtle),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(112.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(KgsMintBg),
        contentAlignment = Alignment.Center,
      ) {
        if (!product.imageUrl.isNullOrBlank()) {
          AsyncImage(
            model = product.imageUrl,
            contentDescription = product.displayName(language),
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
          )
        } else {
          Icon(
            imageVector = Icons.Outlined.Inventory2,
            contentDescription = product.displayName(language),
            tint = KgsEmerald.copy(alpha = 0.5f),
            modifier = Modifier.size(40.dp),
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = PureWhite.copy(alpha = 0.92f),
          modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
        ) {
          Text(
            text = unitLabel,
            style = MaterialTheme.typography.labelSmall,
            color = KgsForest,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
          )
        }

        if (!product.isAvailable || product.stockQty <= 0) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = StatusError.copy(alpha = 0.9f),
            modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp),
          ) {
            Text(
              text = strings.outOfStock,
              style = MaterialTheme.typography.labelSmall,
              color = PureWhite,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
        }
      }

      Text(
        text = product.displayCategory(language),
        style = MaterialTheme.typography.labelSmall,
        color = KgsEmerald,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      Text(
        text = product.displayName(language),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        minLines = 2,
      )

      if (!product.shopName.isNullOrBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Store,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(12.dp),
          )
          Text(
            text = product.shopName,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column {
          Text(
            text = formatInr(packPrice),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = KgsForest,
          )
          Text(
            text = "/ $unitLabel",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        if (cartQty <= 0) {
          Button(
            onClick = onAddToCart,
            enabled = product.isAvailable && product.stockQty > 0,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
            modifier =
              Modifier.height(40.dp).minimumInteractiveComponentSize().testTag("add_cart_${product.id}"),
          ) {
            Icon(
              imageVector = Icons.Filled.ShoppingBag,
              contentDescription = strings.addToCart,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "+", style = MaterialTheme.typography.labelLarge)
          }
        } else {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = KgsEmerald,
            modifier = Modifier.height(40.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { onUpdateQty(cartQty - 1) },
                modifier = Modifier.size(36.dp).testTag("dec_cart_${product.id}"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Remove,
                  contentDescription = "Decrease quantity",
                  tint = PureWhite,
                  modifier = Modifier.size(16.dp),
                )
              }
              Text(
                text = cartQty.toString(),
                style = MaterialTheme.typography.labelLarge,
                color = PureWhite,
                modifier = Modifier.padding(horizontal = 4.dp),
              )
              IconButton(
                onClick = { onUpdateQty(cartQty + 1) },
                modifier = Modifier.size(36.dp).testTag("inc_cart_${product.id}"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Add,
                  contentDescription = "Increase quantity",
                  tint = PureWhite,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuantityVariantSelector(
  selectedVariant: QuantityVariant,
  priceProvider: ((QuantityVariant) -> Double)?,
  onSelect: (QuantityVariant) -> Unit,
  variants: List<QuantityVariant> = QuantityVariant.standardGroceryOptions,
  modifier: Modifier = Modifier,
) {
  FlowRow(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    variants.forEach { variant ->
      val isSelected = variant == selectedVariant
      val label =
        if (priceProvider != null) "${variant.label} • ${formatInr(priceProvider(variant))}"
        else variant.label
      FilterChip(
        selected = isSelected,
        onClick = { onSelect(variant) },
        label = { Text(text = label, style = MaterialTheme.typography.labelMedium) },
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = KgsEmerald,
            selectedLabelColor = PureWhite,
          ),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("variant_chip_${variant.label}"),
      )
    }
  }
}

@Composable
fun KotakUpiQrCard(
  upiVpa: String,
  payeeName: String,
  amount: Double,
  orderRef: String,
  strings: AppStrings,
  onCopyUpiId: () -> Unit,
  onOpenUpiApp: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val upiUri =
    remember(upiVpa, payeeName, amount, orderRef) {
      ValidationUtils.buildUpiPaymentUri(
        merchantVpa = upiVpa,
        merchantName = payeeName,
        orderRef = orderRef,
        amount = amount,
      ).toString()
    }
  val qrBitmap = remember(upiUri) { QrCodeGenerator.generateQrBitmap(upiUri, 512) }

  Card(
    modifier = modifier.fillMaxWidth().testTag("kotak_upi_qr_card"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, KgsEmerald.copy(alpha = 0.35f)),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(Icons.Filled.QrCode2, contentDescription = null, tint = KgsForest)
        Text(
          text = strings.kotakUpiTitle,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = KgsForest,
        )
      }

      if (qrBitmap != null) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = PureWhite,
          border = BorderStroke(1.dp, OutlineSubtle),
          modifier = Modifier.padding(4.dp),
        ) {
          Image(
            bitmap = qrBitmap,
            contentDescription = "Kotak UPI QR Code for $upiVpa",
            modifier = Modifier.size(184.dp).padding(8.dp),
          )
        }
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = "Payee: $payeeName",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = "UPI ID: $upiVpa",
          style = MaterialTheme.typography.bodyMedium,
          color = KgsForest,
          fontWeight = FontWeight.SemiBold,
        )
        Text(
          text = "Amount: ${formatInr(amount)}",
          style = MaterialTheme.typography.titleMedium,
          color = KgsEmerald,
          fontWeight = FontWeight.Bold,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = onCopyUpiId,
          modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("copy_upi_id_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(Icons.Filled.ContentCopy, contentDescription = strings.copyUpiId, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(strings.copyUpiId, maxLines = 1)
        }
        Button(
          onClick = onOpenUpiApp,
          colors = ButtonDefaults.buttonColors(containerColor = KgsForest),
          modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("open_upi_app_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = strings.openUpiApp, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(strings.openUpiApp, maxLines = 1)
        }
      }
    }
  }
}

@Composable
fun PaymentStatusBadge(
  paymentStatus: PaymentStatus,
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  val (bg, fg) =
    when (paymentStatus) {
      PaymentStatus.UPI_VERIFIED,
      PaymentStatus.COD_COLLECTED -> KgsMintContainer to KgsForest
      PaymentStatus.UPI_REJECTED -> StatusError.copy(alpha = 0.14f) to StatusError
      PaymentStatus.REFUNDED -> Color(0xFFE0ECFF) to Color(0xFF174EA6)
      PaymentStatus.PENDING_VERIFICATION,
      PaymentStatus.COD_PENDING -> StatusWarning.copy(alpha = 0.14f) to StatusWarning
    }
  Surface(shape = RoundedCornerShape(8.dp), color = bg, modifier = modifier) {
    Text(
      text = if (language == AppLanguage.HINDI) paymentStatus.labelHi else paymentStatus.labelEn,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = fg,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

@Composable
fun OrderTimelineStepper(
  status: OrderStatus,
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  if (status == OrderStatus.CANCELLED) return
  val activeSteps =
    listOf(
      OrderStatus.PLACED,
      OrderStatus.CONFIRMED,
      OrderStatus.PACKED,
      OrderStatus.OUT_FOR_DELIVERY,
      OrderStatus.DELIVERED,
    )
  val currentStepIndex = activeSteps.indexOf(status)

  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    activeSteps.forEachIndexed { idx, step ->
      val reached = currentStepIndex >= idx
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier =
            Modifier.size(14.dp)
              .clip(CircleShape)
              .background(if (reached) KgsEmerald else OutlineSubtle)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = if (language == AppLanguage.HINDI) step.labelHi else step.labelEn,
          style = MaterialTheme.typography.labelSmall,
          color = if (reached) KgsForest else MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}
