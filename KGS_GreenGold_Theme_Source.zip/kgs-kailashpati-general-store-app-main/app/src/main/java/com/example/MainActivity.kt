package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.KgsApp
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsTheme
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val isRobolectric = Build.FINGERPRINT.equals("robolectric", ignoreCase = true)
    setContent {
      KgsTheme {
        var showSplash by remember { mutableStateOf(!isRobolectric) }
        LaunchedEffect(Unit) {
          if (showSplash) {
            delay(850L)
            showSplash = false
          }
        }
        Box(modifier = Modifier.fillMaxSize()) {
          KgsApp()
          AnimatedVisibility(visible = showSplash, exit = fadeOut()) { KgsSplashScreen() }
        }
      }
    }
  }
}

@Composable
fun KgsSplashScreen(modifier: Modifier = Modifier) {
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(colors = listOf(KgsForest, KgsEmerald)))
        .testTag("kgs_splash_screen"),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(24.dp),
    ) {
      Surface(
        shape = RoundedCornerShape(28.dp),
        color = PureWhite,
        shadowElevation = 8.dp,
        modifier = Modifier.size(112.dp),
      ) {
        Image(
          painter = painterResource(id = R.drawable.kgs_logo),
          contentDescription = stringResource(id = R.string.cd_kgs_logo),
          modifier = Modifier.fillMaxSize().padding(10.dp).clip(RoundedCornerShape(20.dp)),
        )
      }
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = "KGS – Kailashpati General Store",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = PureWhite,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "दैनिक किराना आपके द्वार पर • Daily Grocery",
        style = MaterialTheme.typography.bodyMedium,
        color = PureWhite.copy(alpha = 0.9f),
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(24.dp))
      CircularProgressIndicator(
        color = PureWhite,
        strokeWidth = 3.dp,
        modifier = Modifier.size(28.dp),
      )
    }
  }
}
