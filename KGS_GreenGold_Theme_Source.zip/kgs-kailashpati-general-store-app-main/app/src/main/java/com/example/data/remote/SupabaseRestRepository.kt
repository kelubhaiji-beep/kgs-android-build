package com.example.data.remote

import com.example.config.SupabaseConfig
import com.example.model.Category
import com.example.model.CustomerAddress
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.model.RationItem
import com.example.model.SchemaColumnInfo
import com.example.model.SchemaInspectionResult
import com.example.model.SchemaTableInfo
import com.example.model.Shop
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.util.NetworkUtils
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class ProductCatalogPageResult(
  val products: List<Product>,
  val totalCount: Int,
  val resolvedTableName: String,
)

class SupabaseRestRepository(
  private val client: OkHttpClient,
  private val baseUrlProvider: () -> String = { SupabaseConfig.url },
  private val anonKeyProvider: () -> String = { SupabaseConfig.anonKey },
  private val isConfiguredProvider: () -> Boolean = { SupabaseConfig.isConfigured },
) {
  private val jsonMedia = "application/json; charset=utf-8".toMediaType()
  private val baseUrl: String
    get() = baseUrlProvider().trim().trimEnd('/')
  private val anonKey: String
    get() = anonKeyProvider().trim()

  // Discovered table names and column sets from safe client table probes (no OpenAPI root or secret key needed)
  @Volatile private var discoveredTables: Set<String> = emptySet()
  @Volatile private var discoveredColumns: Map<String, Set<String>> = emptyMap()

  private fun Request.Builder.applySupabaseHeaders(accessToken: String?): Request.Builder {
    addHeader("apikey", anonKey)
    addHeader("Accept", "application/json")
    when {
      !accessToken.isNullOrBlank() -> addHeader("Authorization", "Bearer $accessToken")
      anonKey.startsWith("eyJ") -> addHeader("Authorization", "Bearer $anonKey")
    }
    return this
  }

  suspend fun inspectSchema(accessToken: String? = null): SchemaInspectionResult =
    withContext(Dispatchers.IO) {
      val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
      if (!isConfiguredProvider()) {
        return@withContext SchemaInspectionResult(
          inspectedAt = timestamp,
          isConnected = false,
          errorMessage =
            SupabaseConfig.configurationError
              ?: "SUPABASE_URL and SUPABASE_ANON_KEY are not configured in AI Studio Secrets.",
        )
      }

      val candidateGroups =
        listOf(
          "products" to listOf("products", "grocery_products", "items", "catalog"),
          "shops" to listOf("shops", "distributors", "stores"),
          "orders" to listOf("orders", "customer_orders"),
          "profiles" to listOf("profiles", "users", "customers"),
          "addresses" to listOf("addresses", "customer_addresses", "user_addresses"),
          "ration_items" to listOf("ration_items", "ration_lists", "monthly_ration_items"),
          "categories" to listOf("categories", "product_categories"),
        )

      data class ProbeOutcome(
        val logicalName: String,
        val tableInfo: SchemaTableInfo? = null,
        val columns: Set<String> = emptySet(),
        val gatewayKeyFailure: String? = null,
        val networkFailure: String? = null,
      )

      val probeResults = coroutineScope {
        candidateGroups.map { (logicalName, candidates) ->
          async(Dispatchers.IO) {
            for (tableName in candidates) {
              val probeUrl = "$baseUrl/rest/v1/$tableName?select=*&limit=1"
              val req =
                Request.Builder()
                  .url(probeUrl)
                  .get()
                  .applySupabaseHeaders(accessToken)
                  .addHeader("Prefer", "count=exact")
                  .build()

              val callOutcome =
                try {
                  client.newCall(req).execute().use { resp ->
                    Triple(resp.code, resp.body?.string().orEmpty(), resp.header("Content-Range"))
                  }
                } catch (err: IOException) {
                  return@async ProbeOutcome(
                    logicalName = logicalName,
                    networkFailure = NetworkUtils.formatConnectionError(err, SupabaseConfig.host),
                  )
                } catch (err: Exception) {
                  return@async ProbeOutcome(
                    logicalName = logicalName,
                    networkFailure = NetworkUtils.formatConnectionError(err, SupabaseConfig.host),
                  )
                }

              val (code, body, contentRange) = callOutcome
              when {
                code in 200..299 -> {
                  val rowCount = parseContentRangeTotal(contentRange)
                  val cols = inferColumnsFromSample(body)
                  val statusLabel =
                    when {
                      rowCount != null -> "Readable via RLS ($rowCount rows)"
                      cols.isNotEmpty() -> "Readable via RLS"
                      else -> "Readable via RLS (0 rows visible)"
                    }
                  return@async ProbeOutcome(
                    logicalName = logicalName,
                    tableInfo =
                      SchemaTableInfo(
                        tableName = tableName,
                        columns = cols,
                        rowCount = rowCount,
                        accessStatus = statusLabel,
                      ),
                    columns = cols.map { it.name }.toSet(),
                  )
                }
                code == 401 && !accessToken.isNullOrBlank() -> {
                  // Retry probe without stale user token for public catalog/shops
                  val anonReq =
                    Request.Builder()
                      .url(probeUrl)
                      .get()
                      .applySupabaseHeaders(null)
                      .addHeader("Prefer", "count=exact")
                      .build()
                  val anonOutcome =
                    runCatching {
                        client.newCall(anonReq).execute().use { resp ->
                          Triple(resp.code, resp.body?.string().orEmpty(), resp.header("Content-Range"))
                        }
                      }
                      .getOrNull()
                  if (anonOutcome != null && anonOutcome.first in 200..299) {
                    val rowCount = parseContentRangeTotal(anonOutcome.third)
                    val cols = inferColumnsFromSample(anonOutcome.second)
                    return@async ProbeOutcome(
                      logicalName = logicalName,
                      tableInfo =
                        SchemaTableInfo(
                          tableName = tableName,
                          columns = cols,
                          rowCount = rowCount,
                          accessStatus = "Readable via public RLS",
                        ),
                      columns = cols.map { it.name }.toSet(),
                    )
                  }
                }
                code == 401 || code == 403 -> {
                  val msg = parseSupabaseMessage(body)
                  val isRlsPolicyDenial =
                    body.contains("42501") || msg.contains("permission denied", ignoreCase = true)
                  if (
                    !isRlsPolicyDenial &&
                      (code == 401 ||
                        msg.contains("Invalid API key", ignoreCase = true) ||
                        msg.contains("Secret API key", ignoreCase = true) ||
                        msg.contains("No API key found", ignoreCase = true) ||
                        msg.contains("Invalid JWT", ignoreCase = true))
                  ) {
                    return@async ProbeOutcome(
                      logicalName = logicalName,
                      gatewayKeyFailure =
                        "Supabase rejected the API key ($code: $msg). Verify SUPABASE_URL and your publishable/anon key in AI Studio Secrets.",
                    )
                  }
                  return@async ProbeOutcome(
                    logicalName = logicalName,
                    tableInfo =
                      SchemaTableInfo(
                        tableName = tableName,
                        columns = emptyList(),
                        rowCount = null,
                        accessStatus = "Protected by RLS ($code: $msg)",
                      ),
                  )
                }
                code == 404 || body.contains("PGRST205", ignoreCase = true) -> continue
                else -> continue
              }
            }
            ProbeOutcome(logicalName = logicalName)
          }
        }.awaitAll()
      }

      val gatewayKeyFailure = probeResults.firstNotNullOfOrNull { it.gatewayKeyFailure }
      if (gatewayKeyFailure != null) {
        return@withContext SchemaInspectionResult(
          inspectedAt = timestamp,
          isConnected = false,
          errorMessage = gatewayKeyFailure,
        )
      }

      val foundTables = probeResults.mapNotNull { it.tableInfo }
      val networkFailure = probeResults.firstNotNullOfOrNull { it.networkFailure }
      if (networkFailure != null && foundTables.isEmpty()) {
        return@withContext SchemaInspectionResult(
          inspectedAt = timestamp,
          isConnected = false,
          errorMessage = networkFailure,
        )
      }

      val detectedMappings = linkedMapOf<String, String>()
      val colMap = mutableMapOf<String, Set<String>>()
      probeResults.forEach { outcome ->
        val info = outcome.tableInfo ?: return@forEach
        detectedMappings[outcome.logicalName] = info.tableName
        if (outcome.columns.isNotEmpty()) {
          colMap[info.tableName] = outcome.columns
        }
      }

      discoveredTables = foundTables.map { it.tableName }.toSet()
      if (colMap.isNotEmpty()) {
        discoveredColumns = discoveredColumns + colMap
      }

      return@withContext if (foundTables.isEmpty()) {
        SchemaInspectionResult(
          inspectedAt = timestamp,
          isConnected = false,
          errorMessage =
            "Connected to Supabase URL, but none of the expected tables (products, shops, orders, etc.) were found under the public schema.",
        )
      } else {
        SchemaInspectionResult(
          inspectedAt = timestamp,
          isConnected = true,
          tables = foundTables.sortedBy { it.tableName },
          detectedMappings = detectedMappings,
        )
      }
    }

  private fun resolveTable(candidates: List<String>): String? =
    candidates.firstOrNull { candidate ->
      discoveredTables.any { it.equals(candidate, ignoreCase = true) }
    }

  private fun hasTable(vararg candidates: String): Boolean =
    candidates.any { candidate ->
      discoveredTables.any { it.equals(candidate, ignoreCase = true) }
    }

  private fun recordColumnsFromJsonArray(table: String, arr: JSONArray) {
    if (arr.length() == 0) return
    val first = arr.optJSONObject(0) ?: return
    val keys = mutableSetOf<String>()
    val iter = first.keys()
    while (iter.hasNext()) keys.add(iter.next())
    if (keys.isNotEmpty()) {
      discoveredColumns = discoveredColumns + (table to keys)
    }
  }

  private suspend fun resolveProductsTable(accessToken: String?): String {
    resolveTable(listOf("products", "grocery_products", "items", "catalog"))?.let { return it }
    return "products"
  }

  /**
   * Fetches ALL available products from Supabase in deterministic 500-row paginated batches so
   * 500+ products load completely without duplicates or skipped items.
   */
  suspend fun fetchAllProducts(accessToken: String? = null): Result<ProductCatalogPageResult> =
    withContext(Dispatchers.IO) {
      if (!isConfiguredProvider()) {
        return@withContext Result.failure(
          IllegalStateException(
            SupabaseConfig.configurationError ?: "Supabase is not configured."
          )
        )
      }
      val candidates =
        listOfNotNull(
            resolveTable(listOf("products", "grocery_products", "items", "catalog")),
            "products",
            "grocery_products",
            "items",
            "catalog",
          )
          .distinct()

      var lastError: Throwable? = null
      for (table in candidates) {
        val attempt = fetchAllProductsFromTable(table = table, accessToken = accessToken)
        if (attempt.isSuccess) {
          discoveredTables = discoveredTables + table
          return@withContext attempt
        }
        val err = attempt.exceptionOrNull()
        val msg = err?.message.orEmpty()
        // Only try fallback table names when PostgREST reports table not found (404 / PGRST205)
        if (msg.contains("PGRST205", ignoreCase = true) || msg.contains("was not found", ignoreCase = true)) {
          lastError = err
          continue
        }
        return@withContext attempt
      }
      return@withContext Result.failure(
        lastError ?: IllegalStateException("Table 'public.products' was not found on Supabase.")
      )
    }

  private fun fetchAllProductsFromTable(
    table: String,
    accessToken: String?,
  ): Result<ProductCatalogPageResult> {
    return try {
      val allProducts = LinkedHashMap<String, Product>()
      var offset = 0
      val batchSize = 500
      var totalCount = 0
      var useOrderById = true
      var activeToken = accessToken

      while (true) {
        val orderParam = if (useOrderById) "&order=id.asc" else ""
        val req =
          Request.Builder()
            .url(
              "$baseUrl/rest/v1/$table?select=*&limit=$batchSize&offset=$offset$orderParam"
            )
            .get()
            .applySupabaseHeaders(activeToken)
            .addHeader("Prefer", "count=exact")
            .build()

        var shouldRetry = false
        val batch =
          client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
              if (resp.code == 400 && useOrderById) {
                useOrderById = false
                shouldRetry = true
                return@use emptyList()
              }
              if (resp.code == 401 && !activeToken.isNullOrBlank()) {
                // Expired/invalid user JWT: fall back to public anon apikey read for public catalog
                activeToken = null
                shouldRetry = true
                return@use emptyList()
              }
              val msg = parseSupabaseMessage(body)
              if (resp.code == 401 || resp.code == 403) {
                error(
                  "Access denied reading 'public.$table' (${resp.code}: $msg). Verify SUPABASE_ANON_KEY and ensure a SELECT RLS policy exists for anon/authenticated on public.$table."
                )
              }
              if (resp.code == 404 || body.contains("PGRST205", ignoreCase = true)) {
                error("Table 'public.$table' was not found on Supabase (HTTP ${resp.code}: $msg).")
              }
              error("Failed reading 'public.$table' (HTTP ${resp.code}): $msg")
            }
            parseContentRangeTotal(resp.header("Content-Range"))?.let { totalCount = it }
            val arr = JSONArray(body)
            if (offset == 0) recordColumnsFromJsonArray(table, arr)
            List(arr.length()) { idx -> parseProduct(arr.getJSONObject(idx), offset + idx) }
          }

        if (shouldRetry) continue
        if (batch.isEmpty()) break

        batch.forEach { product ->
          val key = product.id.ifBlank { "${product.name}_${product.category}_${product.basePrice}" }
          if (!allProducts.containsKey(key)) {
            allProducts[key] = product
          }
        }

        offset += batch.size
        if (totalCount > 0 && allProducts.size >= totalCount) break
        if (totalCount <= 0 && batch.size < batchSize) break
        if (offset >= 5000) break
      }

      val list = allProducts.values.toList()
      Result.success(
        ProductCatalogPageResult(
          products = list,
          totalCount = if (totalCount > 0) totalCount else list.size,
          resolvedTableName = table,
        )
      )
    } catch (io: IOException) {
      Result.failure(IllegalStateException(NetworkUtils.formatConnectionError(io, SupabaseConfig.host), io))
    } catch (t: Throwable) {
      Result.failure(t)
    }
  }

  suspend fun fetchCategories(accessToken: String? = null): Result<List<Category>> =
    withContext(Dispatchers.IO) {
      if (!isConfiguredProvider()) {
        return@withContext Result.success(emptyList())
      }
      // Do NOT assume public.categories exists
      if (!hasTable("categories", "product_categories")) {
        return@withContext Result.success(emptyList())
      }
      runCatching {
        val table = resolveTable(listOf("categories", "product_categories")) ?: return@runCatching emptyList()
        var reqToken = accessToken
        for (attempt in 0..1) {
          val req =
            Request.Builder()
              .url("$baseUrl/rest/v1/$table?select=*")
              .get()
              .applySupabaseHeaders(reqToken)
              .build()
          client.newCall(req).execute().use { resp ->
            if (resp.code == 404) return@runCatching emptyList()
            if (resp.code == 401 && !reqToken.isNullOrBlank() && attempt == 0) {
              reqToken = null
              return@use
            }
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Failed reading '$table' (${resp.code}): ${parseSupabaseMessage(body)}")
            val arr = JSONArray(body)
            return@runCatching List(arr.length()) { idx ->
              val obj = arr.getJSONObject(idx)
              Category(
                id = obj.optString("id").ifBlank { "cat_$idx" },
                name =
                  obj.optString("name")
                    .ifBlank { obj.optString("category_name") }
                    .ifBlank { obj.optString("title") },
                nameHi = obj.optString("name_hi").ifBlank { obj.optString("hindi_name") }.takeIf { it.isNotBlank() },
                imageUrl = obj.optString("image_url").ifBlank { obj.optString("image") }.takeIf { it.isNotBlank() },
              )
            }
          }
        }
        emptyList()
      }
    }

  suspend fun upsertProduct(
    product: Product,
    isNew: Boolean,
    accessToken: String,
  ): Result<Product> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveProductsTable(accessToken)
        val knownCols = discoveredColumns[table].orEmpty()

        val priceCol =
          listOf("price", "selling_price", "base_price", "sale_price", "unit_price")
            .firstOrNull { knownCols.contains(it) } ?: "price"
        val stockCol =
          listOf("stock", "stock_qty", "stock_quantity", "quantity", "qty")
            .firstOrNull { knownCols.contains(it) } ?: "stock"
        val unitCol =
          listOf("unit", "base_unit", "weight", "pack_size")
            .firstOrNull { knownCols.contains(it) } ?: "unit"
        val nameCol =
          listOf("name", "product_name", "title")
            .firstOrNull { knownCols.contains(it) } ?: "name"

        val bodyJson =
          JSONObject().apply {
            if (!isNew && product.id.isNotBlank()) put("id", product.id)
            put(nameCol, product.name)
            if (knownCols.isEmpty() || knownCols.contains("name_hi")) {
              product.nameHi?.takeIf { it.isNotBlank() }?.let { put("name_hi", it) }
            }
            if (knownCols.isEmpty() || knownCols.contains("category")) {
              put("category", product.category)
            } else if (knownCols.contains("category_name")) {
              put("category_name", product.category)
            }
            if (knownCols.isEmpty() || knownCols.contains("category_hi")) {
              product.categoryHi?.takeIf { it.isNotBlank() }?.let { put("category_hi", it) }
            }
            if (knownCols.isEmpty() || knownCols.contains("description")) {
              put("description", product.description)
            }
            if (knownCols.isEmpty() || knownCols.contains("image_url")) {
              product.imageUrl?.takeIf { it.isNotBlank() }?.let { put("image_url", it) }
            }
            put(priceCol, product.basePrice)
            put(unitCol, product.baseUnit)
            put(stockCol, product.stockQty)
            if (knownCols.isEmpty() || knownCols.contains("is_available")) {
              put("is_available", product.isAvailable)
            } else if (knownCols.contains("is_active")) {
              put("is_active", product.isAvailable)
            }
            product.shopId?.takeIf { it.isNotBlank() }?.let { sid ->
              if (knownCols.isEmpty() || knownCols.contains("shop_id")) {
                put("shop_id", sid)
              }
            }
            product.distributorId?.takeIf { it.isNotBlank() }?.let { did ->
              if (knownCols.contains("distributor_id")) {
                put("distributor_id", did)
              }
            }
          }

        val builder =
          Request.Builder()
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=representation")

        val req =
          if (isNew) {
            builder
              .url("${SupabaseConfig.url}/rest/v1/$table")
              .post(bodyJson.toString().toRequestBody(jsonMedia))
              .build()
          } else {
            builder
              .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.${product.id}")
              .patch(bodyJson.toString().toRequestBody(jsonMedia))
              .build()
          }

        client.newCall(req).execute().use { resp ->
          val respBody = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Save product failed (${resp.code}): ${parseSupabaseMessage(respBody)}")
          val arr = JSONArray(respBody)
          if (arr.length() > 0) parseProduct(arr.getJSONObject(0), 0) else product
        }
      }
    }

  suspend fun deleteProduct(productId: String, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveProductsTable(accessToken)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$productId")
            .delete()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Delete product failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun fetchAddresses(userId: String, accessToken: String): Result<List<CustomerAddress>> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table =
          resolveTable(listOf("addresses", "customer_addresses", "user_addresses")) ?: "addresses"
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?user_id=eq.$userId&select=*")
            .get()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Load addresses failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            CustomerAddress(
              id = o.optString("id"),
              userId = o.optString("user_id"),
              label = o.optString("label", "Home"),
              fullName = o.optString("full_name").ifBlank { o.optString("name") },
              phone = o.optString("phone"),
              streetAddress = o.optString("street_address").ifBlank { o.optString("address") },
              landmark = o.optString("landmark"),
              city = o.optString("city"),
              pincode = o.optString("pincode"),
              isDefault = o.optBoolean("is_default", false),
            )
          }
        }
      }
    }

  suspend fun saveAddress(address: CustomerAddress, accessToken: String): Result<CustomerAddress> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table =
          resolveTable(listOf("addresses", "customer_addresses", "user_addresses")) ?: "addresses"
        val payload =
          JSONObject().apply {
            if (address.id.isNotBlank()) put("id", address.id)
            address.userId?.let { put("user_id", it) }
            put("label", address.label)
            put("full_name", address.fullName)
            put("phone", address.phone)
            put("street_address", address.streetAddress)
            put("landmark", address.landmark)
            put("city", address.city)
            put("pincode", address.pincode)
            put("is_default", address.isDefault)
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?on_conflict=id")
            .post(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates,return=representation")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Save address failed (${resp.code}): ${parseSupabaseMessage(body)}")
          address
        }
      }
    }

  suspend fun deleteAddress(addressId: String, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) return@withContext Result.success(Unit)
      runCatching {
        val table =
          resolveTable(listOf("addresses", "customer_addresses", "user_addresses")) ?: "addresses"
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$addressId")
            .delete()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful && resp.code != 404) {
            error("Delete address failed (${resp.code}): ${parseSupabaseMessage(resp.body?.string().orEmpty())}")
          }
        }
      }
    }

  suspend fun fetchRationItems(userId: String, accessToken: String): Result<List<RationItem>> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) return@withContext Result.success(emptyList())
      runCatching {
        val table = resolveTable(listOf("ration_items", "ration_lists", "monthly_ration_items")) ?: "ration_items"
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?user_id=eq.$userId&select=*")
            .get()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          if (resp.code == 404) return@use emptyList()
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Load ration list failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            RationItem(
              id = o.optString("id"),
              userId = o.optString("user_id").takeIf { it.isNotBlank() },
              productId = o.optString("product_id").takeIf { it.isNotBlank() && it != "null" },
              productName = o.optString("product_name"),
              productNameHi = o.optString("product_name_hi").takeIf { it.isNotBlank() && it != "null" },
              category = o.optString("category", "Grocery"),
              variant = QuantityVariant.fromLabel(o.optString("variant")),
              quantity = o.optInt("quantity", 1).coerceAtLeast(1),
              estimatedUnitPrice = o.optDouble("estimated_unit_price", 0.0),
              imageUrl = o.optString("image_url").takeIf { it.isNotBlank() && it != "null" },
            )
          }
        }
      }
    }

  suspend fun upsertRationItem(item: RationItem, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured || item.userId.isNullOrBlank()) return@withContext Result.success(Unit)
      runCatching {
        val table = resolveTable(listOf("ration_items", "ration_lists", "monthly_ration_items")) ?: "ration_items"
        val payload =
          JSONObject().apply {
            put("id", item.id)
            put("user_id", item.userId)
            item.productId?.let { put("product_id", it) }
            put("product_name", item.productName)
            item.productNameHi?.let { put("product_name_hi", it) }
            put("category", item.category)
            put("variant", item.variant.label)
            put("quantity", item.quantity)
            put("estimated_unit_price", item.estimatedUnitPrice)
            item.imageUrl?.let { put("image_url", it) }
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?on_conflict=id")
            .post(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates")
            .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful && resp.code != 404) {
            error("Sync ration item failed (${resp.code}): ${parseSupabaseMessage(resp.body?.string().orEmpty())}")
          }
        }
      }
    }

  suspend fun deleteRationItem(itemId: String, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) return@withContext Result.success(Unit)
      runCatching {
        val table = resolveTable(listOf("ration_items", "ration_lists", "monthly_ration_items")) ?: "ration_items"
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$itemId")
            .delete()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful && resp.code != 404) {
            error("Delete ration item failed (${resp.code}): ${parseSupabaseMessage(resp.body?.string().orEmpty())}")
          }
        }
      }
    }

  suspend fun createOrder(order: Order, accessToken: String): Result<Order> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val ordersTable = resolveTable(listOf("orders", "customer_orders")) ?: "orders"
        val itemsJson =
          JSONArray().apply {
            order.items.forEach { item ->
              put(
                JSONObject().apply {
                  put("product_id", item.productId)
                  put("product_name", item.productName)
                  put("variant", item.variant.label)
                  put("quantity", item.quantity)
                  put("unit_price", item.unitPrice)
                  item.shopId?.let { put("shop_id", it) }
                }
              )
            }
          }
        val payload =
          JSONObject().apply {
            put("order_number", order.orderNumber)
            order.customerId?.let { put("customer_id", it) }
            put("customer_name", order.customerName)
            put("customer_phone", order.customerPhone)
            put("delivery_address", order.deliveryAddress)
            put("delivery_fee", order.deliveryFee)
            put("total_amount", order.totalAmount)
            put("payment_method", order.paymentMethod.dbValue)
            put("payment_status", order.paymentStatus)
            order.upiReference?.takeIf { it.isNotBlank() }?.let { put("upi_reference", it) }
            put("customer_marked_paid", order.customerMarkedPaid)
            put("refund_status", order.refundStatus)
            put("status", order.status.dbValue)
            order.shopId?.takeIf { it.isNotBlank() }?.let { put("shop_id", it) }
            order.distributorId?.takeIf { it.isNotBlank() }?.let { put("distributor_id", it) }
            put("items", itemsJson)
          }

        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$ordersTable")
            .post(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=representation")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Order submission failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          if (arr.length() > 0) parseOrder(arr.getJSONObject(0)) else order
        }
      }
    }

  suspend fun fetchOrders(
    accessToken: String,
    filterColumn: String? = null,
    filterValue: String? = null,
  ): Result<List<Order>> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val ordersTable = resolveTable(listOf("orders", "customer_orders")) ?: "orders"
        val filterQuery =
          if (!filterColumn.isNullOrBlank() && !filterValue.isNullOrBlank()) {
            "&$filterColumn=eq.$filterValue"
          } else {
            ""
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$ordersTable?select=*&order=created_at.desc$filterQuery")
            .get()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Load orders failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          List(arr.length()) { i -> parseOrder(arr.getJSONObject(i)) }
        }
      }
    }

  suspend fun updateOrderStatus(
    orderId: String,
    newStatus: OrderStatus,
    deliveryPartnerId: String? = null,
    deliveryPartnerName: String? = null,
    paymentStatus: String? = null,
    cancellationReason: String? = null,
    accessToken: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val ordersTable = resolveTable(listOf("orders", "customer_orders")) ?: "orders"
        val payload =
          JSONObject().apply {
            put("status", newStatus.dbValue)
            if (!deliveryPartnerId.isNullOrBlank()) put("delivery_partner_id", deliveryPartnerId)
            if (!deliveryPartnerName.isNullOrBlank()) put("delivery_partner_name", deliveryPartnerName)
            if (!paymentStatus.isNullOrBlank()) put("payment_status", paymentStatus)
            if (!cancellationReason.isNullOrBlank()) put("cancellation_reason", cancellationReason)
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$ordersTable?id=eq.$orderId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Update order failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun submitOrderUpiReference(
    orderId: String,
    upiReference: String?,
    customerMarkedPaid: Boolean,
    accessToken: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val ordersTable = resolveTable(listOf("orders", "customer_orders")) ?: "orders"
        val payload =
          JSONObject().apply {
            put("customer_marked_paid", customerMarkedPaid)
            upiReference?.trim()?.takeIf { it.isNotBlank() }?.let { put("upi_reference", it) }
            put("payment_status", PaymentStatus.PENDING_VERIFICATION.dbValue)
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$ordersTable?id=eq.$orderId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Submit UPI reference failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun updateOrderPaymentAndRefund(
    orderId: String,
    paymentStatus: PaymentStatus,
    refundStatus: String,
    verifiedByUserId: String? = null,
    accessToken: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val ordersTable = resolveTable(listOf("orders", "customer_orders")) ?: "orders"
        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        val payload =
          JSONObject().apply {
            put("payment_status", paymentStatus.dbValue)
            put("refund_status", refundStatus)
            if (paymentStatus == PaymentStatus.UPI_VERIFIED && !verifiedByUserId.isNullOrBlank()) {
              put("payment_verified_by", verifiedByUserId)
              put("payment_verified_at", nowIso)
            }
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$ordersTable?id=eq.$orderId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Payment update failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun registerShop(shop: Shop, accessToken: String): Result<Shop> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val shopsTable = resolveTable(listOf("shops", "distributors", "stores")) ?: "shops"
        val knownCols = discoveredColumns[shopsTable].orEmpty()
        val payload =
          JSONObject().apply {
            val ownerCol =
              listOf("owner_id", "user_id", "distributor_id").firstOrNull { knownCols.contains(it) }
                ?: "owner_id"
            shop.ownerId?.let { put(ownerCol, it) }
            val nameCol =
              listOf("shop_name", "name", "store_name", "title").firstOrNull { knownCols.contains(it) }
                ?: "shop_name"
            put(nameCol, shop.shopName)
            if (knownCols.isEmpty() || knownCols.contains("owner_name")) put("owner_name", shop.ownerName)
            if (knownCols.isEmpty() || knownCols.contains("phone")) put("phone", shop.phone)
            if (knownCols.isEmpty() || knownCols.contains("address")) put("address", shop.address)
            if (knownCols.isEmpty() || knownCols.contains("city")) put("city", shop.city)
            if (knownCols.isEmpty() || knownCols.contains("pincode")) put("pincode", shop.pincode)
            if (knownCols.isEmpty() || knownCols.contains("gst_number")) put("gst_number", shop.gstNumber)
            if (knownCols.isEmpty() || knownCols.contains("is_approved")) put("is_approved", false)
            if (knownCols.isEmpty() || knownCols.contains("is_active")) put("is_active", shop.isActive)
            else if (knownCols.contains("active")) put("active", shop.isActive)
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$shopsTable")
            .post(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=representation")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Shop registration failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          if (arr.length() > 0) parseShop(arr.getJSONObject(0)) else shop
        }
      }
    }

  suspend fun fetchShops(accessToken: String? = null): Result<List<Shop>> =
    withContext(Dispatchers.IO) {
      if (!isConfiguredProvider()) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val shopsTable = resolveTable(listOf("shops", "distributors", "stores")) ?: "shops"
        var reqToken = accessToken
        for (attempt in 0..1) {
          val req =
            Request.Builder()
              .url("$baseUrl/rest/v1/$shopsTable?select=*")
              .get()
              .applySupabaseHeaders(reqToken)
              .build()
          client.newCall(req).execute().use { resp ->
            if (resp.code == 401 && !reqToken.isNullOrBlank() && attempt == 0) {
              reqToken = null
              return@use
            }
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Load shops failed (${resp.code}): ${parseSupabaseMessage(body)}")
            val arr = JSONArray(body)
            recordColumnsFromJsonArray(shopsTable, arr)
            return@runCatching List(arr.length()) { i -> parseShop(arr.getJSONObject(i)) }
          }
        }
        emptyList()
      }
    }

  suspend fun fetchProfiles(accessToken: String): Result<List<UserProfile>> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveTable(listOf("profiles", "users", "customers")) ?: "profiles"
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?select=*&limit=200")
            .get()
            .applySupabaseHeaders(accessToken)
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Load profiles failed (${resp.code}): ${parseSupabaseMessage(body)}")
          val arr = JSONArray(body)
          List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            UserProfile(
              id = o.optString("id"),
              fullName = o.optString("full_name").ifBlank { o.optString("name") },
              phone = o.optString("phone"),
              email = o.optString("email"),
              role = UserRole.fromDb(o.optString("role")),
              isActive = o.optBoolean("is_active", true),
            )
          }
        }
      }
    }

  suspend fun updateSelfProfile(
    userId: String,
    fullName: String,
    phone: String,
    accessToken: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveTable(listOf("profiles", "users")) ?: "profiles"
        val payload =
          JSONObject().apply {
            put("full_name", fullName.trim())
            put("phone", phone.trim())
          }
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$userId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Profile update failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun updateProfileRole(userId: String, role: UserRole, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveTable(listOf("profiles", "users")) ?: "profiles"
        val payload = JSONObject().put("role", role.dbValue)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$userId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Role update failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun updateProfileActive(userId: String, active: Boolean, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveTable(listOf("profiles", "users")) ?: "profiles"
        val payload = JSONObject().put("is_active", active)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$userId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Account status update failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  suspend fun updateShopApproval(shopId: String, approved: Boolean, accessToken: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (!SupabaseConfig.isConfigured) {
        return@withContext Result.failure(
          IllegalStateException(SupabaseConfig.configurationError ?: "Supabase is not configured.")
        )
      }
      runCatching {
        val table = resolveTable(listOf("shops", "distributors", "stores")) ?: "shops"
        val payload = JSONObject().put("is_approved", approved)
        val req =
          Request.Builder()
            .url("${SupabaseConfig.url}/rest/v1/$table?id=eq.$shopId")
            .patch(payload.toString().toRequestBody(jsonMedia))
            .applySupabaseHeaders(accessToken)
            .addHeader("Content-Type", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
          val body = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error("Shop approval failed (${resp.code}): ${parseSupabaseMessage(body)}")
        }
      }
    }

  private fun parseShop(o: JSONObject): Shop {
    val active =
      when {
        o.has("is_active") && !o.isNull("is_active") -> o.optBoolean("is_active", true)
        o.has("active") && !o.isNull("active") -> o.optBoolean("active", true)
        else -> true
      }
    val approved =
      when {
        o.has("is_approved") && !o.isNull("is_approved") -> o.optBoolean("is_approved", true)
        o.has("approved") && !o.isNull("approved") -> o.optBoolean("approved", true)
        o.has("status") && !o.isNull("status") ->
          !o.optString("status").equals("suspended", ignoreCase = true)
        else -> active
      }
    val id =
      listOf("id", "shop_id", "uuid")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        .orEmpty()
    val ownerId =
      listOf("owner_id", "user_id", "distributor_id")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
    val shopName =
      listOf("shop_name", "name", "store_name", "title")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        .orEmpty()

    return Shop(
      id = id,
      ownerId = ownerId,
      shopName = shopName,
      ownerName = o.optString("owner_name").takeIf { it != "null" }.orEmpty(),
      phone = o.optString("phone").takeIf { it != "null" }.orEmpty(),
      address = o.optString("address").takeIf { it != "null" }.orEmpty(),
      city = o.optString("city").takeIf { it != "null" }.orEmpty(),
      pincode = o.optString("pincode").takeIf { it != "null" }.orEmpty(),
      gstNumber = o.optString("gst_number").takeIf { it != "null" }.orEmpty(),
      isApproved = approved,
      isActive = active,
    )
  }

  private fun inferColumnsFromSample(rawArrayBody: String): List<SchemaColumnInfo> =
    runCatching {
        val arr = JSONArray(rawArrayBody)
        if (arr.length() == 0) return emptyList()
        val sample = arr.getJSONObject(0)
        val cols = mutableListOf<SchemaColumnInfo>()
        val keys = sample.keys()
        while (keys.hasNext()) {
          val key = keys.next()
          val value = sample.opt(key)
          val typeLabel =
            when (value) {
              null, JSONObject.NULL -> "nullable"
              is Boolean -> "boolean"
              is Int, is Long -> "integer"
              is Double, is Float -> "number"
              is JSONArray -> "array"
              is JSONObject -> "jsonb"
              else -> "text"
            }
          cols.add(SchemaColumnInfo(name = key, type = typeLabel))
        }
        cols.sortedBy { it.name }
      }
      .getOrDefault(emptyList())

  private fun parseSupabaseMessage(raw: String): String {
    if (raw.isBlank()) return "Empty error response"
    return runCatching {
        val obj = JSONObject(raw)
        obj.optString("message")
          .ifBlank { obj.optString("msg") }
          .ifBlank { obj.optString("error_description") }
          .ifBlank { obj.optString("error") }
          .ifBlank { raw }
      }
      .getOrDefault(raw)
  }

  private fun parseContentRangeTotal(header: String?): Int? {
    if (header.isNullOrBlank()) return null
    val slashIdx = header.indexOf('/')
    if (slashIdx == -1) return null
    return header.substring(slashIdx + 1).trim().toIntOrNull()
  }

  private fun parseProduct(o: JSONObject, fallbackIndex: Int): Product {
    val id =
      listOf("id", "product_id", "uuid")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        ?: "row_$fallbackIndex"
    val name =
      listOf("name", "product_name", "title")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        ?: "Product ${fallbackIndex + 1}"
    val nameHi =
      listOf("name_hi", "hindi_name")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
    val categoryId =
      listOf("category_id", "categoryId")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
    val category =
      listOf("category", "category_name")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        ?: "Grocery"
    val categoryHi =
      o.optString("category_hi").takeIf { it.isNotBlank() && it != "null" }
    val price =
      listOf("price", "selling_price", "sale_price", "base_price", "unit_price", "mrp")
        .firstNotNullOfOrNull { key ->
          if (o.has(key) && !o.isNull(key)) o.optDouble(key).takeIf { !it.isNaN() } else null
        } ?: 0.0
    val explicitStock =
      listOf(
          "stock",
          "stock_qty",
          "stock_quantity",
          "stock_count",
          "available_qty",
          "available_stock",
          "inventory",
          "quantity",
          "qty",
        )
        .firstNotNullOfOrNull { key -> if (o.has(key) && !o.isNull(key)) o.optInt(key) else null }
    val imageUrl =
      listOf("image_url", "image", "photo_url", "thumbnail")
        .firstNotNullOfOrNull { key -> o.optString(key).takeIf { it.isNotBlank() && it != "null" } }
    val baseUnit =
      listOf("unit", "base_unit", "weight", "pack_size")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        ?: "1kg"
    val isAvailable =
      when {
        o.has("is_available") && !o.isNull("is_available") -> o.optBoolean("is_available", true)
        o.has("is_active") && !o.isNull("is_active") -> o.optBoolean("is_active", true)
        o.has("in_stock") && !o.isNull("in_stock") -> o.optBoolean("in_stock", true)
        o.has("active") && !o.isNull("active") -> o.optBoolean("active", true)
        else -> (explicitStock ?: 1) > 0
      }
    val stock = explicitStock ?: if (isAvailable) 100 else 0

    val variantPrices = mutableMapOf<QuantityVariant, Double>()
    val variantsObj = o.optJSONObject("variant_prices") ?: o.optJSONObject("variants")
    if (variantsObj != null) {
      QuantityVariant.entries.forEach { variant ->
        if (variantsObj.has(variant.label)) {
          val vp = variantsObj.optDouble(variant.label, -1.0)
          if (vp > 0) variantPrices[variant] = vp
        }
      }
    }

    val shopId =
      listOf("shop_id", "store_id")
        .firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } }
    val distributorId =
      o.optString("distributor_id").takeIf { it.isNotBlank() && it != "null" }

    return Product(
      id = id,
      name = name,
      nameHi = nameHi,
      category = category,
      categoryId = categoryId,
      categoryHi = categoryHi,
      description = o.optString("description").takeIf { it != "null" }.orEmpty(),
      imageUrl = imageUrl,
      basePrice = price,
      baseUnit = baseUnit,
      stockQty = stock,
      isAvailable = isAvailable,
      shopId = shopId,
      distributorId = distributorId,
      shopName = o.optString("shop_name").takeIf { it.isNotBlank() && it != "null" },
      variantPrices = variantPrices,
    )
  }

  private fun parseOrder(o: JSONObject): Order {
    val parsedItems = mutableListOf<OrderItem>()
    val itemsArr = o.optJSONArray("items")
    if (itemsArr != null) {
      for (i in 0 until itemsArr.length()) {
        val io = itemsArr.getJSONObject(i)
        parsedItems.add(
          OrderItem(
            productId = io.optString("product_id"),
            productName = io.optString("product_name"),
            variant = QuantityVariant.fromLabel(io.optString("variant")),
            quantity = io.optInt("quantity", 1),
            unitPrice = io.optDouble("unit_price", 0.0),
            shopId = io.optString("shop_id").takeIf { it.isNotBlank() && it != "null" },
          )
        )
      }
    }

    val payMethod =
      if (o.optString("payment_method").equals("upi", ignoreCase = true)) PaymentMethod.UPI
      else PaymentMethod.COD

    return Order(
      id = o.optString("id"),
      orderNumber = o.optString("order_number").ifBlank { o.optString("id").take(8).uppercase() },
      customerId = o.optString("customer_id").takeIf { it.isNotBlank() && it != "null" },
      customerName = o.optString("customer_name"),
      customerPhone = o.optString("customer_phone"),
      deliveryAddress = o.optString("delivery_address"),
      items = parsedItems,
      deliveryFee = o.optDouble("delivery_fee", 0.0),
      totalAmount = o.optDouble("total_amount", 0.0),
      paymentMethod = payMethod,
      paymentStatus = o.optString("payment_status", PaymentStatus.COD_PENDING.dbValue),
      upiReference = o.optString("upi_reference").takeIf { it.isNotBlank() && it != "null" },
      customerMarkedPaid = o.optBoolean("customer_marked_paid", false),
      paymentVerifiedBy = o.optString("payment_verified_by").takeIf { it.isNotBlank() && it != "null" },
      paymentVerifiedAt = o.optString("payment_verified_at").takeIf { it.isNotBlank() && it != "null" },
      refundStatus = o.optString("refund_status", "none").ifBlank { "none" },
      cancellationReason = o.optString("cancellation_reason").takeIf { it.isNotBlank() && it != "null" },
      status = OrderStatus.fromDb(o.optString("status")),
      shopId = o.optString("shop_id").takeIf { it.isNotBlank() && it != "null" },
      distributorId = o.optString("distributor_id").takeIf { it.isNotBlank() && it != "null" },
      deliveryPartnerId = o.optString("delivery_partner_id").takeIf { it.isNotBlank() && it != "null" },
      deliveryPartnerName = o.optString("delivery_partner_name").takeIf { it.isNotBlank() && it != "null" },
      createdAt = o.optString("created_at"),
    )
  }
}
