package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.i18n.AppStrings
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.Shop
import com.example.model.UserRole
import com.example.ui.components.OrderTimelineStepper
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.components.formatInr
import com.example.ui.theme.KgsEmerald
import com.example.ui.theme.KgsForest
import com.example.ui.theme.KgsMintContainer
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.KgsUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DistributorPanelScreen(
  state: KgsUiState,
  strings: AppStrings,
  onBack: () -> Unit,
  onRefresh: () -> Unit,
  onRegisterShop: (Shop) -> Unit,
  onSaveProduct: (Product, String, String) -> Unit,
  onDeleteProduct: (String) -> Unit,
  onUpdateOrderStatus: (String, OrderStatus) -> Unit,
) {
  BackHandler(onBack = onBack)

  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  var editingProductId by rememberSaveable { mutableStateOf<String?>(null) }
  var showAddProductDialog by rememberSaveable { mutableStateOf(false) }

  val session = state.authSession
  val isAuthorized =
    session?.role == UserRole.DISTRIBUTOR || session?.role == UserRole.ADMIN
  val ownedShops =
    state.shops.filter {
      session?.role == UserRole.ADMIN || it.ownerId == session?.userId
    }
  val scopedProducts = state.distributorScopedProducts
  val scopedOrders = state.distributorScopedOrders

  if (showAddProductDialog) {
    DistributorProductDialog(
      existing = null,
      ownedShops = ownedShops,
      strings = strings,
      onDismiss = { showAddProductDialog = false },
      onSave = { product, price, stock ->
        onSaveProduct(product, price, stock)
        showAddProductDialog = false
      },
    )
  }

  editingProductId?.let { prodId ->
    scopedProducts.firstOrNull { it.id == prodId }?.let { target ->
      DistributorProductDialog(
        existing = target,
        ownedShops = ownedShops,
        strings = strings,
        onDismiss = { editingProductId = null },
        onSave = { product, price, stock ->
          onSaveProduct(product, price, stock)
          editingProductId = null
        },
      )
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.distributorPanel) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("distributor_back_button")) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(id = R.string.cd_navigate_back),
            )
          }
        },
        actions = {
          IconButton(onClick = onRefresh) {
            Icon(Icons.Filled.Refresh, contentDescription = strings.retryConnection)
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(
            containerColor = KgsForest,
            titleContentColor = PureWhite,
            navigationIconContentColor = PureWhite,
            actionIconContentColor = PureWhite,
          ),
      )
    }
  ) { innerPadding ->
    Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      TabRow(selectedTabIndex = selectedTab) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("${strings.manageProducts} (${scopedProducts.size})") },
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("${strings.manageOrders} (${scopedOrders.size})") },
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text(strings.shopRegistration) },
        )
      }

      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        when (selectedTab) {
          0 -> {
            LazyColumn(
              modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
              contentPadding = PaddingValues(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              if (!isAuthorized) {
                item {
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StatusWarning.copy(alpha = 0.14f),
                    modifier = Modifier.fillMaxWidth().testTag("distributor_role_notice"),
                  ) {
                    Row(
                      modifier = Modifier.padding(12.dp),
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Icon(Icons.Filled.Lock, contentDescription = null, tint = StatusWarning)
                      Text(
                        text =
                          "Sign in as a Distributor or Admin to view and manage your shop's products. Other shops' private data is isolated by RLS.",
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                  }
                }
              }

              item {
                Card(
                  shape = RoundedCornerShape(14.dp),
                  colors = CardDefaults.cardColors(containerColor = KgsMintContainer),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Column {
                      Text(
                        text = ownedShops.firstOrNull()?.shopName ?: "Your Shop",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = KgsForest,
                      )
                      Text(
                        text = "${scopedProducts.size} assigned products • ${scopedOrders.size} shop orders",
                        style = MaterialTheme.typography.bodySmall,
                        color = KgsForest,
                      )
                    }
                    Text(
                      text =
                        if (ownedShops.any { it.isApproved }) "Approved"
                        else if (ownedShops.isNotEmpty()) "Pending"
                        else "No Shop",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = KgsEmerald,
                    )
                  }
                }
              }

              item {
                Button(
                  onClick = { showAddProductDialog = true },
                  enabled = isAuthorized,
                  colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                  modifier =
                    Modifier.fillMaxWidth()
                      .minimumInteractiveComponentSize()
                      .testTag("distributor_add_product_button"),
                ) {
                  Icon(Icons.Filled.Add, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Add New Product to Shop")
                }
              }

              if (scopedProducts.isEmpty() && isAuthorized) {
                item {
                  Text(
                    text =
                      "No products are linked to your shop yet. Register/approve a shop first and add products.",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              }

              items(scopedProducts, key = { it.id }) { prod ->
                Card(
                  shape = RoundedCornerShape(14.dp),
                  colors = CardDefaults.cardColors(containerColor = PureWhite),
                  border = BorderStroke(1.dp, OutlineSubtle),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = prod.displayName(state.language),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                      )
                      Text(
                        text =
                          "${prod.category} • ${formatInr(prod.basePrice)}/${prod.baseUnit} • Stock: ${prod.stockQty}",
                        style = MaterialTheme.typography.bodySmall,
                        color = KgsForest,
                      )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      IconButton(
                        onClick = { editingProductId = prod.id },
                        enabled = isAuthorized,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit product", tint = KgsForest)
                      }
                      IconButton(
                        onClick = { onDeleteProduct(prod.id) },
                        enabled = isAuthorized,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Icon(
                          Icons.Filled.DeleteOutline,
                          contentDescription = "Delete product",
                          tint = StatusError,
                        )
                      }
                    }
                  }
                }
              }
            }
          }

          1 -> {
            LazyColumn(
              modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
              contentPadding = PaddingValues(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              if (!isAuthorized) {
                item {
                  Text(
                    text = "Sign in as a Distributor to view orders placed for your shop.",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              } else if (scopedOrders.isEmpty()) {
                item {
                  Text(
                    text = "No orders received for your shop yet.",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              } else {
                items(scopedOrders, key = { it.id.ifBlank { it.orderNumber } }) { order ->
                  Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, OutlineSubtle),
                  ) {
                    Column(
                      modifier = Modifier.padding(14.dp),
                      verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        Text(
                          text = "${order.orderNumber} • ${order.customerName}",
                          style = MaterialTheme.typography.titleSmall,
                          fontWeight = FontWeight.Bold,
                        )
                        Text(
                          text = formatInr(order.totalAmount),
                          style = MaterialTheme.typography.titleSmall,
                          fontWeight = FontWeight.Bold,
                          color = KgsForest,
                        )
                      }
                      PaymentStatusBadge(order.parsedPaymentStatus, state.language)
                      Text(text = order.deliveryAddress, style = MaterialTheme.typography.bodySmall)
                      if (order.items.isNotEmpty()) {
                        Text(
                          text =
                            order.items.joinToString {
                              "${it.productName} (${it.variant.label} × ${it.quantity})"
                            },
                          style = MaterialTheme.typography.bodySmall,
                          color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                      }
                      OrderTimelineStepper(status = order.status, language = state.language)
                      if (order.status != OrderStatus.CANCELLED &&
                        order.status != OrderStatus.DELIVERED
                      ) {
                        Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                          OutlinedButton(
                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.CONFIRMED) },
                            enabled = order.status == OrderStatus.PLACED,
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                          ) {
                            Text("Accept", maxLines = 1)
                          }
                          Button(
                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.PACKED) },
                            enabled =
                              order.status == OrderStatus.PLACED ||
                                order.status == OrderStatus.CONFIRMED,
                            colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                          ) {
                            Text("Preparing", maxLines = 1)
                          }
                          OutlinedButton(
                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.OUT_FOR_DELIVERY) },
                            enabled = order.status == OrderStatus.PACKED,
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                          ) {
                            Text("Dispatch", maxLines = 1)
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }

          else -> {
            ShopRegistrationForm(
              existingShops = ownedShops,
              isAuthorized = session != null,
              strings = strings,
              onSubmit = onRegisterShop,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ShopRegistrationForm(
  existingShops: List<Shop>,
  isAuthorized: Boolean,
  strings: AppStrings,
  onSubmit: (Shop) -> Unit,
) {
  var shopName by rememberSaveable { mutableStateOf("") }
  var ownerName by rememberSaveable { mutableStateOf("") }
  var phone by rememberSaveable { mutableStateOf("") }
  var address by rememberSaveable { mutableStateOf("") }
  var city by rememberSaveable { mutableStateOf("") }
  var pincode by rememberSaveable { mutableStateOf("") }
  var gstNumber by rememberSaveable { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, OutlineSubtle),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text(
            text = strings.shopRegistration,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          OutlinedTextField(
            value = shopName,
            onValueChange = { shopName = it },
            label = { Text("Shop / Distributor Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("shop_name_input"),
          )
          OutlinedTextField(
            value = ownerName,
            onValueChange = { ownerName = it },
            label = { Text("Owner Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text(strings.mobileNumber) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text(strings.streetAddress) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = city,
              onValueChange = { city = it },
              label = { Text(strings.city) },
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = pincode,
              onValueChange = { pincode = it },
              label = { Text(strings.pincode) },
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
          OutlinedTextField(
            value = gstNumber,
            onValueChange = { gstNumber = it },
            label = { Text("GSTIN (Optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          Button(
            onClick = {
              onSubmit(
                Shop(
                  id = "",
                  shopName = shopName,
                  ownerName = ownerName,
                  phone = phone,
                  address = address,
                  city = city,
                  pincode = pincode,
                  gstNumber = gstNumber,
                )
              )
            },
            enabled = isAuthorized,
            colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
            modifier =
              Modifier.fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("register_shop_submit"),
          ) {
            Text("Register Shop")
          }
        }
      }
    }

    items(existingShops, key = { it.id.ifBlank { it.shopName } }) { shop ->
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = KgsMintContainer,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(
            text = "${shop.shopName} (${if (shop.isApproved) "Approved" else "Pending Approval"})",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
          )
          Text(text = "${shop.address}, ${shop.city}", style = MaterialTheme.typography.bodySmall)
        }
      }
    }
  }
}

@Composable
private fun DistributorProductDialog(
  existing: Product?,
  ownedShops: List<Shop>,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (Product, String, String) -> Unit,
) {
  var name by rememberSaveable { mutableStateOf(existing?.name.orEmpty()) }
  var nameHi by rememberSaveable { mutableStateOf(existing?.nameHi.orEmpty()) }
  var category by rememberSaveable { mutableStateOf(existing?.category ?: "Grains & Atta") }
  var unit by rememberSaveable { mutableStateOf(existing?.baseUnit ?: "1kg") }
  var price by rememberSaveable { mutableStateOf(existing?.basePrice?.toString().orEmpty()) }
  var stock by rememberSaveable { mutableStateOf(existing?.stockQty?.toString() ?: "50") }
  var imageUrl by rememberSaveable { mutableStateOf(existing?.imageUrl.orEmpty()) }
  var selectedShopId by rememberSaveable {
    mutableStateOf(existing?.shopId ?: ownedShops.firstOrNull()?.id.orEmpty())
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) "New Product" else "Update ${existing.name}") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Product Name (English)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = nameHi,
          onValueChange = { nameHi = it },
          label = { Text("Product Name (Hindi - Optional)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category") },
          singleLine = true,
        )
        OutlinedTextField(
          value = unit,
          onValueChange = { unit = it },
          label = { Text("Base Unit (e.g. 1kg, 500g, 1 pc)") },
          singleLine = true,
        )
        OutlinedTextField(
          value = price,
          onValueChange = { price = it },
          label = { Text("Price (₹)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
        )
        OutlinedTextField(
          value = stock,
          onValueChange = { stock = it.filter { c -> c.isDigit() } },
          label = { Text("Stock Qty") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
        )
        OutlinedTextField(
          value = imageUrl,
          onValueChange = { imageUrl = it },
          label = { Text("Image URL (Optional)") },
          singleLine = true,
        )
        if (ownedShops.size > 1) {
          Text("Assign to Shop", style = MaterialTheme.typography.labelMedium)
          ownedShops.forEach { shop ->
            FilterChip(
              selected = selectedShopId == shop.id,
              onClick = { selectedShopId = shop.id },
              label = { Text(shop.shopName) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            (existing ?: Product(id = "", name = name, category = category, basePrice = 0.0))
              .copy(
                name = name.trim(),
                nameHi = nameHi.trim().takeIf { it.isNotBlank() },
                category = category.trim(),
                baseUnit = unit.trim(),
                imageUrl = imageUrl.trim().takeIf { it.isNotBlank() },
                shopId = selectedShopId.takeIf { it.isNotBlank() } ?: existing?.shopId,
              ),
            price,
            stock,
          )
        },
        colors = ButtonDefaults.buttonColors(containerColor = KgsEmerald),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}
