package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import com.example.i18n.stringsFor
import com.example.model.AppLanguage
import com.example.model.Product
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.theme.KgsTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KgsSecurityAndUiTest {

  @get:Rule val composeRule = createComposeRule()

  @Test
  fun `branded KGS splash screen displays logo title and Hindi tagline`() {
    composeRule.setContent { KgsTheme { KgsSplashScreen() } }
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("kgs_splash_screen").assertIsDisplayed()
    composeRule.onNodeWithText("KGS – Kailashpati General Store").assertIsDisplayed()
  }

  @Test
  fun `product detail hides price edit card when distributor does not own shop`() {
    val foreignProduct =
      Product(
        id = "p_foreign",
        name = "Foreign Shop Mustard Oil",
        category = "Oil & Ghee",
        basePrice = 185.0,
        baseUnit = "1kg",
        stockQty = 20,
        shopId = "other_shop",
      )
    composeRule.setContent {
      KgsTheme {
        ProductDetailScreen(
          product = foreignProduct,
          language = AppLanguage.ENGLISH,
          strings = stringsFor(AppLanguage.ENGLISH),
          canEditPrice = false,
          onBack = {},
          onAddToCart = { _, _ -> },
          onAddToRation = { _, _ -> },
          onSavePriceAndStock = { _, _, _ -> },
        )
      }
    }
    composeRule.waitForIdle()
    composeRule.onAllNodesWithText("Foreign Shop Mustard Oil").onFirst().assertIsDisplayed()
    composeRule.onNodeWithTag("detail_save_price_button").assertDoesNotExist()
  }

  @Test
  fun `product detail shows price edit card when distributor owns shop`() {
    val ownProduct =
      Product(
        id = "p_own",
        name = "Own Shop Mustard Oil",
        category = "Oil & Ghee",
        basePrice = 185.0,
        baseUnit = "1kg",
        stockQty = 20,
        shopId = "own_shop",
      )
    composeRule.setContent {
      KgsTheme {
        ProductDetailScreen(
          product = ownProduct,
          language = AppLanguage.ENGLISH,
          strings = stringsFor(AppLanguage.ENGLISH),
          canEditPrice = true,
          onBack = {},
          onAddToCart = { _, _ -> },
          onAddToRation = { _, _ -> },
          onSavePriceAndStock = { _, _, _ -> },
        )
      }
    }
    composeRule.waitForIdle()
    composeRule.onAllNodesWithText("Own Shop Mustard Oil").onFirst().assertIsDisplayed()
    composeRule.onNodeWithTag("detail_save_price_button").performScrollTo().assertIsDisplayed()
  }
}
