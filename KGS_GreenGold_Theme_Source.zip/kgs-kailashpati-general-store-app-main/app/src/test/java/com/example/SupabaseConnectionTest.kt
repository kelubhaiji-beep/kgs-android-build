package com.example

import com.example.config.SupabaseConfig
import com.example.data.remote.SupabaseRestRepository
import com.example.util.NetworkUtils
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlinx.coroutines.test.runTest
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SupabaseConnectionTest {

  @Test
  fun `supabase config normalizes url and publishable key without hardcoding`() {
    assertEquals(
      "https://hafbkxaefzkwyjdkxaai.supabase.co",
      SupabaseConfig.normalizeUrl("\"https://hafbkxaefzkwyjdkxaai.supabase.co/rest/v1/\""),
    )
    assertTrue(
      SupabaseConfig.isValidConfig(
        "https://hafbkxaefzkwyjdkxaai.supabase.co",
        "sb_publishable_test_key_123",
      )
    )
    assertFalse(
      SupabaseConfig.isValidConfig(
        "http://hafbkxaefzkwyjdkxaai.supabase.co",
        "sb_publishable_test_key_123",
      )
    )
    assertFalse(
      SupabaseConfig.isValidConfig(
        "https://hafbkxaefzkwyjdkxaai.supabase.co",
        "sb_secret_forbidden",
      )
    )
    assertFalse(SupabaseConfig.isSecretKeyDetected)
  }

  @Test
  fun `fetchAllProducts loads 500 products from public products with publishable apikey header`() =
    runTest {
      val capturedRequests = mutableListOf<okhttp3.Request>()
      val jsonArr =
        JSONArray().apply {
          for (i in 1..500) {
            put(
              JSONObject()
                .put("id", "prod_$i")
                .put("name", "Grocery Item $i")
                .put("category", "Grains")
                .put("price", 50.0 + i)
                .put("unit", "1kg")
                .put("stock", 25)
                .put("is_available", true)
            )
          }
        }

      val client =
        OkHttpClient.Builder()
          .addInterceptor { chain ->
            val req = chain.request()
            capturedRequests.add(req)
            Response.Builder()
              .request(req)
              .protocol(Protocol.HTTP_1_1)
              .code(200)
              .message("OK")
              .header("Content-Range", "0-499/500")
              .body(jsonArr.toString().toResponseBody("application/json".toMediaType()))
              .build()
          }
          .build()

      val repo =
        SupabaseRestRepository(
          client = client,
          baseUrlProvider = { "https://hafbkxaefzkwyjdkxaai.supabase.co" },
          anonKeyProvider = { "sb_publishable_test_key_123" },
          isConfiguredProvider = { true },
        )

      val result = repo.fetchAllProducts(accessToken = null)
      assertTrue(result.isSuccess)
      val page = result.getOrThrow()
      assertEquals(500, page.products.size)
      assertEquals(500, page.totalCount)
      assertEquals("products", page.resolvedTableName)

      val firstReq = capturedRequests.first()
      assertEquals(
        "https://hafbkxaefzkwyjdkxaai.supabase.co/rest/v1/products?select=*&limit=500&offset=0&order=id.asc",
        firstReq.url.toString(),
      )
      assertEquals("sb_publishable_test_key_123", firstReq.header("apikey"))
      assertNull(firstReq.header("Authorization"))
    }

  @Test
  fun `fetchAllProducts retries without order on 400 and retries anon on stale JWT 401`() =
    runTest {
      val seenAuthHeaders = mutableListOf<String?>()
      val seenUrls = mutableListOf<String>()

      val client =
        OkHttpClient.Builder()
          .addInterceptor { chain ->
            val req = chain.request()
            seenAuthHeaders.add(req.header("Authorization"))
            seenUrls.add(req.url.toString())

            when {
              req.header("Authorization") != null ->
                Response.Builder()
                  .request(req)
                  .protocol(Protocol.HTTP_1_1)
                  .code(401)
                  .message("Unauthorized")
                  .body("""{"message":"JWT expired"}""".toResponseBody("application/json".toMediaType()))
                  .build()
              req.url.toString().contains("order=id.asc") ->
                Response.Builder()
                  .request(req)
                  .protocol(Protocol.HTTP_1_1)
                  .code(400)
                  .message("Bad Request")
                  .body("""{"message":"column id does not exist"}""".toResponseBody("application/json".toMediaType()))
                  .build()
              else ->
                Response.Builder()
                  .request(req)
                  .protocol(Protocol.HTTP_1_1)
                  .code(200)
                  .message("OK")
                  .header("Content-Range", "0-0/1")
                  .body(
                    """[{"id":"p1","name":"Toor Dal","category":"Dal","price":145,"stock":10}]"""
                      .toResponseBody("application/json".toMediaType())
                  )
                  .build()
            }
          }
          .build()

      val repo =
        SupabaseRestRepository(
          client = client,
          baseUrlProvider = { "https://hafbkxaefzkwyjdkxaai.supabase.co" },
          anonKeyProvider = { "sb_publishable_test_key_123" },
          isConfiguredProvider = { true },
        )

      val result = repo.fetchAllProducts(accessToken = "stale.jwt.token")
      assertTrue(result.isSuccess)
      assertEquals(1, result.getOrThrow().products.size)
      assertEquals("Toor Dal", result.getOrThrow().products.first().name)
      assertTrue(seenAuthHeaders.contains("Bearer stale.jwt.token"))
      assertTrue(seenAuthHeaders.contains(null))
      assertTrue(seenUrls.any { !it.contains("order=id.asc") })
    }

  @Test
  fun `network error formatter produces clear diagnostics for DNS and timeouts`() {
    val dnsMsg =
      NetworkUtils.formatConnectionError(
        UnknownHostException("hafbkxaefzkwyjdkxaai.supabase.co"),
        "hafbkxaefzkwyjdkxaai.supabase.co",
      )
    assertTrue(dnsMsg.contains("DNS lookup failed"))

    val timeoutMsg =
      NetworkUtils.formatConnectionError(
        SocketTimeoutException("timeout"),
        "hafbkxaefzkwyjdkxaai.supabase.co",
      )
    assertTrue(timeoutMsg.contains("timed out"))
  }
}
