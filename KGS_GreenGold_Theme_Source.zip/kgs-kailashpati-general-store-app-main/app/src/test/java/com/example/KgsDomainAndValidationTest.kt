package com.example

import com.example.config.SupabaseConfig
import com.example.model.AuthSession
import com.example.model.CategoryHindiDictionary
import com.example.model.CustomerAddress
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.PaymentStatus
import com.example.model.Product
import com.example.model.QuantityVariant
import com.example.model.Shop
import com.example.model.UserRole
import com.example.ui.viewmodel.KgsUiState
import com.example.util.QrCodeGenerator
import com.example.util.ValidationResult
import com.example.util.ValidationUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KgsDomainAndValidationTest {

  @Test
  fun `product calculates all 8 quantity variants accurately`() {
    val atta =
      Product(
        id = "p1",
        name = "Chakki Atta",
        category = "Grains",
        basePrice = 60.0,
        baseUnit = "1kg",
        stockQty = 100,
      )

    assertEquals(6.0, atta.priceFor(QuantityVariant.G100), 0.01)
    assertEquals(12.0, atta.priceFor(QuantityVariant.G200), 0.01)
    assertEquals(15.0, atta.priceFor(QuantityVariant.G250), 0.01)
    assertEquals(30.0, atta.priceFor(QuantityVariant.G500), 0.01)
    assertEquals(60.0, atta.priceFor(QuantityVariant.KG1), 0.01)
    assertEquals(120.0, atta.priceFor(QuantityVariant.KG2), 0.01)
    assertEquals(300.0, atta.priceFor(QuantityVariant.KG5), 0.01)
    assertEquals(600.0, atta.priceFor(QuantityVariant.KG10), 0.01)
    assertTrue(atta.isWeightBased)
    assertEquals(QuantityVariant.standardGroceryOptions, atta.applicableVariants())
  }

  @Test
  fun `non-weight product uses fixed base unit without gram scaling`() {
    val soap =
      Product(
        id = "p2",
        name = "Bath Soap Pack",
        category = "Personal Care",
        basePrice = 120.0,
        baseUnit = "4 pcs",
        stockQty = 20,
      )
    assertFalse(soap.isWeightBased)
    assertEquals(listOf(QuantityVariant.KG1), soap.applicableVariants())
    assertEquals(120.0, soap.priceFor(QuantityVariant.G100), 0.01)
  }

  @Test
  fun `phone validation accepts 10 digit Indian numbers and rejects invalid`() {
    assertTrue(ValidationUtils.validateIndianPhone("9876543210") is ValidationResult.Valid)
    assertEquals("+919876543210", ValidationUtils.normalizeIndianPhone("9876543210"))
    assertTrue(ValidationUtils.validateIndianPhone("12345") is ValidationResult.Invalid)
  }

  @Test
  fun `address validation checks pincode and required fields`() {
    val validAddress =
      CustomerAddress(
        id = "a1",
        fullName = "Ramesh Kumar",
        phone = "9876543210",
        streetAddress = "House 14, Main Bazar Road",
        city = "Varanasi",
        pincode = "221001",
      )
    assertTrue(ValidationUtils.validateAddress(validAddress) is ValidationResult.Valid)

    val badPincode = validAddress.copy(pincode = "2210")
    assertTrue(ValidationUtils.validateAddress(badPincode) is ValidationResult.Invalid)
  }

  @Test
  fun `price and stock validation prevents negative or zero prices`() {
    assertTrue(ValidationUtils.validatePriceAndStock("45.5", "10") is ValidationResult.Valid)
    assertTrue(ValidationUtils.validatePriceAndStock("0", "10") is ValidationResult.Invalid)
    assertTrue(ValidationUtils.validatePriceAndStock("45", "-1") is ValidationResult.Invalid)
  }

  @Test
  fun `upi reference validation allows empty optional input and rejects malformed refs`() {
    assertTrue(ValidationUtils.validateUpiReference("") is ValidationResult.Valid)
    assertTrue(ValidationUtils.validateUpiReference("431912345678") is ValidationResult.Valid)
    assertTrue(ValidationUtils.validateUpiReference("12") is ValidationResult.Invalid)
    assertTrue(ValidationUtils.validateUpiReference("bad ref!") is ValidationResult.Invalid)
  }

  @Test
  fun `kotak upi defaults and qr bitmap generation work`() {
    assertEquals("kailashyadav0@kotakbank", SupabaseConfig.effectiveUpiVpa)
    assertEquals("KAILASH YADAV", SupabaseConfig.effectivePayeeName)

    val uri =
      ValidationUtils.buildUpiPaymentUri(
        merchantVpa = SupabaseConfig.effectiveUpiVpa,
        merchantName = SupabaseConfig.effectivePayeeName,
        orderRef = "KGS-1001",
        amount = 499.0,
      )
    val uriString = uri.toString()
    assertTrue(uriString.contains("pa=kailashyadav0%40kotakbank") || uriString.contains("pa=kailashyadav0@kotakbank"))
    assertTrue(uriString.contains("am=499.00"))
    assertTrue(uriString.contains("cu=INR"))

    val qrBitmap = QrCodeGenerator.generateQrBitmap(uriString, 256)
    assertNotNull(qrBitmap)
  }

  @Test
  fun `order status and payment status map both legacy and new db values`() {
    assertEquals(OrderStatus.PLACED, OrderStatus.fromDb("pending"))
    assertEquals(OrderStatus.PLACED, OrderStatus.fromDb("placed"))
    assertEquals(OrderStatus.CONFIRMED, OrderStatus.fromDb("accepted"))
    assertEquals(OrderStatus.CONFIRMED, OrderStatus.fromDb("confirmed"))
    assertEquals(OrderStatus.PACKED, OrderStatus.fromDb("preparing"))
    assertEquals(OrderStatus.PACKED, OrderStatus.fromDb("packed"))
    assertEquals(OrderStatus.OUT_FOR_DELIVERY, OrderStatus.fromDb("out_for_delivery"))
    assertEquals(OrderStatus.DELIVERED, OrderStatus.fromDb("delivered"))
    assertEquals(OrderStatus.CANCELLED, OrderStatus.fromDb("cancelled"))

    assertEquals(PaymentStatus.PENDING_VERIFICATION, PaymentStatus.fromDb("pending_verification"))
    assertEquals(PaymentStatus.UPI_VERIFIED, PaymentStatus.fromDb("upi_verified"))
    assertEquals(PaymentStatus.UPI_REJECTED, PaymentStatus.fromDb("upi_rejected"))
    assertEquals(PaymentStatus.COD_PENDING, PaymentStatus.fromDb("cod_pending"))
    assertEquals(PaymentStatus.COD_COLLECTED, PaymentStatus.fromDb("cod_collected"))
    assertEquals(PaymentStatus.REFUNDED, PaymentStatus.fromDb("refunded"))
  }

  @Test
  fun `category dictionary translates common grocery categories to Hindi`() {
    assertEquals("दालें", CategoryHindiDictionary.translate("Dal"))
    assertEquals("तेल और घी", CategoryHindiDictionary.translate("Oil & Ghee"))
    assertEquals("मसाले", CategoryHindiDictionary.translate("Spices"))
  }

  @Test
  fun `distributor shop isolation and admin analytics metrics filter accurately`() {
    val shopA = Shop(id = "shop_a", ownerId = "dist_a", shopName = "Shop A", ownerName = "A", phone = "9876543210", address = "Addr", city = "City", pincode = "221001")
    val shopB = Shop(id = "shop_b", ownerId = "dist_b", shopName = "Shop B", ownerName = "B", phone = "9876543211", address = "Addr2", city = "City", pincode = "221001")
    val prodA = Product(id = "pa", name = "Atta", category = "Grains", basePrice = 50.0, stockQty = 10, shopId = "shop_a")
    val prodB = Product(id = "pb", name = "Oil", category = "Oil", basePrice = 150.0, stockQty = 0, shopId = "shop_b")
    val ordA = Order(id = "oa", orderNumber = "KGS-1", customerName = "C1", customerPhone = "999", deliveryAddress = "D1", totalAmount = 200.0, paymentMethod = PaymentMethod.UPI, paymentStatus = "pending_verification", shopId = "shop_a")
    val ordB = Order(id = "ob", orderNumber = "KGS-2", customerName = "C2", customerPhone = "998", deliveryAddress = "D2", totalAmount = 300.0, paymentMethod = PaymentMethod.UPI, paymentStatus = "upi_verified", shopId = "shop_b")

    val distState =
      KgsUiState(
        authSession = AuthSession(accessToken = "t", userId = "dist_a", role = UserRole.DISTRIBUTOR),
        shops = listOf(shopA, shopB),
        products = listOf(prodA, prodB),
        orders = listOf(ordA, ordB),
      )
    assertEquals(listOf(prodA), distState.distributorScopedProducts)
    assertEquals(listOf(ordA), distState.distributorScopedOrders)
    assertEquals(500.0, distState.totalOrderVolume, 0.01)
    assertEquals(300.0, distState.verifiedAndCollectedRevenue, 0.01)
    assertEquals(1, distState.pendingUpiVerificationOrdersCount)
    assertEquals(1, distState.outOfStockProductsCount)
  }

  @Test
  fun `supabase config validates placeholders vs live secrets honestly`() {
    assertFalse(SupabaseConfig.isValidConfig("YOUR_SUPABASE_URL", "YOUR_SUPABASE_ANON_KEY"))
    assertFalse(SupabaseConfig.isValidConfig("https://example.supabase.co", "sb_secret_123"))
    assertTrue(SupabaseConfig.isValidConfig("https://example.supabase.co", "sb_publishable_123"))

    assertFalse(SupabaseConfig.isValidUpiVpa("UNCONFIGURED"))
    assertTrue(SupabaseConfig.isValidUpiVpa("kailashyadav0@kotakbank"))

    // Never allow a secret/service_role key regardless of whether Secrets are injected
    assertFalse(SupabaseConfig.isSecretKeyDetected)
    if (SupabaseConfig.isConfigured) {
      assertTrue(SupabaseConfig.url.startsWith("https://"))
      assertTrue(SupabaseConfig.anonKey.isNotBlank())
    }
  }

  @Test
  fun `supabase config blocks secret and service_role keys while allowing publishable and anon keys`() {
    assertTrue(SupabaseConfig.isSecretOrServiceRoleKey("sb_secret_abc123"))
    assertFalse(SupabaseConfig.isSecretOrServiceRoleKey("sb_publishable_abc123"))

    val serviceRoleJwt = "eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIn0.sig"
    val anonJwt = "eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiYW5vbiJ9.sig"

    assertTrue(SupabaseConfig.isSecretOrServiceRoleKey(serviceRoleJwt))
    assertFalse(SupabaseConfig.isSecretOrServiceRoleKey(anonJwt))
  }

  @Test
  fun `canEditProduct isolates distributors to own shop and isolates delivery partner orders`() {
    val shopA = Shop(id = "shop_a", ownerId = "dist_a", shopName = "Shop A", ownerName = "A", phone = "9876543210", address = "Addr", city = "City", pincode = "221001")
    val shopB = Shop(id = "shop_b", ownerId = "dist_b", shopName = "Shop B", ownerName = "B", phone = "9876543211", address = "Addr2", city = "City", pincode = "221001")
    val prodA = Product(id = "pa", name = "Atta", category = "Grains", basePrice = 50.0, stockQty = 10, shopId = "shop_a")
    val prodB = Product(id = "pb", name = "Oil", category = "Oil", basePrice = 150.0, stockQty = 5, shopId = "shop_b")
    val ordDp1 = Order(id = "o1", orderNumber = "KGS-1", customerName = "C1", customerPhone = "999", deliveryAddress = "D1", totalAmount = 100.0, deliveryPartnerId = "dp_1")
    val ordDp2 = Order(id = "o2", orderNumber = "KGS-2", customerName = "C2", customerPhone = "998", deliveryAddress = "D2", totalAmount = 200.0, deliveryPartnerId = "dp_2")

    val distState =
      KgsUiState(
        authSession = AuthSession(accessToken = "t", userId = "dist_a", role = UserRole.DISTRIBUTOR),
        shops = listOf(shopA, shopB),
        products = listOf(prodA, prodB),
      )
    assertTrue(distState.canEditProduct(prodA))
    assertFalse(distState.canEditProduct(prodB))

    val adminState =
      distState.copy(
        authSession = AuthSession(accessToken = "t", userId = "admin_1", role = UserRole.ADMIN)
      )
    assertTrue(adminState.canEditProduct(prodA))
    assertTrue(adminState.canEditProduct(prodB))

    val dpState =
      KgsUiState(
        authSession = AuthSession(accessToken = "t", userId = "dp_1", role = UserRole.DELIVERY_PARTNER),
        orders = listOf(ordDp1, ordDp2),
      )
    assertEquals(listOf(ordDp1), dpState.deliveryScopedOrders)
  }

  @Test
  fun `viewModel enforces upper stock limit when adding and updating cart quantities`() {
    val app = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = com.example.ui.viewmodel.KgsViewModel(app)
    val limitedProduct =
      Product(
        id = "stock_test_1",
        name = "Toor Dal",
        category = "Dal",
        basePrice = 140.0,
        stockQty = 3,
        isAvailable = true,
      )

    vm.addToCart(limitedProduct, QuantityVariant.KG1, qty = 2)
    assertEquals(2, vm.uiState.value.cartCount)

    // Trying to add 5 more must cap cleanly at stockQty = 3
    vm.addToCart(limitedProduct, QuantityVariant.KG1, qty = 5)
    assertEquals(3, vm.uiState.value.cartCount)

    // Trying to update directly to 10 must clamp cleanly at 3
    vm.updateCartQuantity(limitedProduct.id, QuantityVariant.KG1, 10)
    assertEquals(3, vm.uiState.value.cartCount)

    // Setting to 0 removes item
    vm.updateCartQuantity(limitedProduct.id, QuantityVariant.KG1, 0)
    assertEquals(0, vm.uiState.value.cartCount)
  }
}
