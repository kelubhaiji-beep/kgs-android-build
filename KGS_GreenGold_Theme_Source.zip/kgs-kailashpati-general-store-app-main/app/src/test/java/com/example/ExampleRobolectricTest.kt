package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `app name matches KGS Kailashpati General Store`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KGS Kailashpati General Store", appName)
  }

  @Test
  fun `customer flow language toggle navigation and all panels work`() {
    composeTestRule.waitForIdle()

    // When secrets are placeholders, the config prompt is shown; when secrets are injected, catalog grid is active
    composeTestRule.onNodeWithTag("catalog_product_grid").assertIsDisplayed()
    if (!com.example.config.SupabaseConfig.isConfigured) {
      composeTestRule.onNodeWithTag("supabase_status_card").assertIsDisplayed()
    }

    // Toggle language from English to Hindi and verify Hindi header text
    composeTestRule.onNodeWithTag("language_toggle_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("दैनिक किराना आपके द्वार पर").assertIsDisplayed()

    // Toggle back to English
    composeTestRule.onNodeWithTag("language_toggle_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Daily Grocery at Your Doorstep").assertIsDisplayed()

    // Navigate to Cart empty state
    composeTestRule.onNodeWithTag("nav_cart").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("empty_cart_browse_button").assertIsDisplayed()

    // Navigate to Ration tab, add a custom monthly ration item, and verify it appears
    composeTestRule.onNodeWithTag("nav_ration").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("add_custom_ration_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("ration_item_name_input").performTextInput("Sharbati Atta")
    composeTestRule.onNodeWithTag("ration_save_item_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Sharbati Atta").assertIsDisplayed()

    // Navigate to Account tab and open Distributor, Delivery, and Admin panels
    composeTestRule.onNodeWithTag("nav_account").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("account_lazy_column").performScrollToNode(hasTestTag("open_distributor_panel"))
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("open_distributor_panel").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("distributor_role_notice").assertIsDisplayed()
    composeTestRule.onNodeWithTag("distributor_add_product_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("distributor_back_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("account_lazy_column").performScrollToNode(hasTestTag("open_delivery_panel"))
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("open_delivery_panel").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("delivery_role_notice").assertIsDisplayed()
    composeTestRule.onNodeWithTag("delivery_back_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("account_lazy_column").performScrollToNode(hasTestTag("open_admin_panel"))
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("open_admin_panel").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("admin_role_notice").assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_inspect_schema_button").assertIsDisplayed()
  }
}
