-- KGS - Kailashpati General Store
-- Safe, non-destructive RLS & GRANT migration for public catalog browsing.
-- Preserves all 500 existing rows in public.products and keeps RLS ENABLED everywhere.
-- Does NOT expose private customer, shop-owner, order, or payment tables to anon.

-- ============================================================================
-- STEP 1: INSPECT EXISTING GRANTS, RLS STATUS, AND POLICIES (Read-Only)
-- ============================================================================
-- Check whether RLS is enabled on public.products & public.categories:
SELECT n.nspname AS schema_name,
       c.relname AS table_name,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS force_rls
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('products', 'categories', 'shops', 'orders', 'profiles', 'addresses');

-- Check existing table grants for anon and authenticated:
SELECT table_schema, table_name, grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema = 'public'
  AND table_name IN ('products', 'categories')
  AND grantee IN ('anon', 'authenticated', 'PUBLIC')
ORDER BY table_name, grantee, privilege_type;

-- Check existing RLS policies on public.products and public.categories:
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('products', 'categories')
ORDER BY tablename, policyname;

-- ============================================================================
-- STEP 2: APPLY SAFE READ-ONLY ACCESS FOR CATALOG (NO DATA MODIFICATION)
-- ============================================================================
BEGIN;

-- Ensure schema usage is granted to Supabase client roles
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Grant read-only SELECT on public.products (never INSERT/UPDATE/DELETE for anon)
GRANT SELECT ON TABLE public.products TO anon, authenticated;

-- Keep Row Level Security ENABLED on public.products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Replace only our named SELECT policy so all existing products can be read by customers
DROP POLICY IF EXISTS "kgs_public_read_products" ON public.products;
CREATE POLICY "kgs_public_read_products"
ON public.products
FOR SELECT
TO anon, authenticated
USING (true);

-- Grant read-only SELECT on public.categories if present, keeping RLS enabled
DO $$
BEGIN
  IF to_regclass('public.categories') IS NOT NULL THEN
    EXECUTE 'GRANT SELECT ON TABLE public.categories TO anon, authenticated';
    EXECUTE 'ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS "kgs_public_read_categories" ON public.categories';
    EXECUTE 'CREATE POLICY "kgs_public_read_categories" ON public.categories FOR SELECT TO anon, authenticated USING (true)';
  END IF;
END
$$;

COMMIT;

-- ============================================================================
-- STEP 3: POST-MIGRATION VERIFICATION
-- ============================================================================
-- Confirm exact product count is unchanged (expected: 500):
SELECT COUNT(*) AS total_products FROM public.products;

-- Confirm private tables are NOT granted to anon:
SELECT table_name, grantee, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema = 'public'
  AND grantee = 'anon'
  AND table_name NOT IN ('products', 'categories')
ORDER BY table_name;
