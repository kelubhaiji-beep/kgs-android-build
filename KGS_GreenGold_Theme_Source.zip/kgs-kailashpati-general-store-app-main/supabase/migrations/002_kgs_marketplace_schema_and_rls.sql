-- KGS – Kailashpati General Store
-- Non-destructive, idempotent schema & Row Level Security (RLS) migration.
-- Compatible with existing public.products (500+ rows, linked via shop_id),
-- public.shops, and public.orders. Does NOT assume a public.categories table exists.

BEGIN;

-- ============================================================================
-- 1. PROFILES TABLE (Customer, Distributor, Delivery Partner, Admin roles)
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT DEFAULT '',
  email TEXT DEFAULT '',
  role TEXT NOT NULL DEFAULT 'customer'
    CHECK (role IN ('customer', 'distributor', 'delivery_partner', 'admin')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Safely add missing columns if profiles already existed
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS full_name TEXT NOT NULL DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'customer';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT true;

-- Auto-create profile as 'customer' on new auth.users signup (never trust client role)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.phone, NEW.raw_user_meta_data->>'phone', ''),
    COALESCE(NEW.email, ''),
    'customer'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Helper function for RLS policies without recursive table lookups
CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = true LIMIT 1),
    'customer'
  );
$$;

-- ============================================================================
-- 2. SHOPS & PRODUCTS NON-DESTRUCTIVE EXTENSIONS (Preserves all existing data)
-- ============================================================================
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS owner_id UUID REFERENCES auth.users(id);
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS owner_name TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS address TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS city TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS pincode TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS gst_number TEXT DEFAULT '';
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS is_approved BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE public.shops ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT true;

ALTER TABLE public.products ADD COLUMN IF NOT EXISTS name_hi TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS category_hi TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_available BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES public.shops(id);

-- ============================================================================
-- 3. CUSTOMER ADDRESSES & MONTHLY RATION LIST TABLES
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  label TEXT NOT NULL DEFAULT 'Home',
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  street_address TEXT NOT NULL,
  landmark TEXT DEFAULT '',
  city TEXT NOT NULL,
  pincode TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.ration_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id TEXT,
  product_name TEXT NOT NULL,
  product_name_hi TEXT,
  category TEXT NOT NULL DEFAULT 'Grocery',
  variant TEXT NOT NULL DEFAULT '1kg',
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  estimated_unit_price NUMERIC(10, 2) NOT NULL DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- 4. ORDERS NON-DESTRUCTIVE EXTENSIONS (Kotak UPI, COD, Refunds, Delivery)
-- ============================================================================
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS order_number TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_id UUID REFERENCES auth.users(id);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_address TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_fee NUMERIC(10, 2) NOT NULL DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_amount NUMERIC(10, 2) NOT NULL DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_method TEXT NOT NULL DEFAULT 'cod';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'cod_pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS upi_reference TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_marked_paid BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_verified_by UUID REFERENCES auth.users(id);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_verified_at TIMESTAMPTZ;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS refund_status TEXT NOT NULL DEFAULT 'none';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES public.shops(id);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS distributor_id UUID REFERENCES auth.users(id);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_partner_id UUID REFERENCES auth.users(id);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_partner_name TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();

-- ============================================================================
-- 5. SAFE ATOMIC STOCK DECREMENT TRIGGER ON ORDER CREATION
-- ============================================================================
CREATE OR REPLACE FUNCTION public.kgs_decrement_stock_on_order()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  item JSONB;
  pid TEXT;
  qty INT;
  stock_col TEXT;
BEGIN
  IF NEW.items IS NULL OR jsonb_typeof(NEW.items) <> 'array' THEN
    RETURN NEW;
  END IF;

  SELECT column_name INTO stock_col
  FROM information_schema.columns
  WHERE table_schema = 'public'
    AND table_name = 'products'
    AND column_name IN ('stock', 'stock_qty', 'stock_quantity', 'quantity', 'qty')
  ORDER BY CASE column_name
    WHEN 'stock' THEN 1
    WHEN 'stock_qty' THEN 2
    WHEN 'stock_quantity' THEN 3
    WHEN 'quantity' THEN 4
    ELSE 5
  END
  LIMIT 1;

  IF stock_col IS NULL THEN
    RETURN NEW;
  END IF;

  FOR item IN SELECT * FROM jsonb_array_elements(NEW.items)
  LOOP
    pid := item->>'product_id';
    qty := GREATEST(COALESCE((item->>'quantity')::INT, 1), 1);

    IF pid IS NOT NULL AND pid <> '' THEN
      EXECUTE format(
        'UPDATE public.products SET %I = GREATEST(COALESCE(%I, 0) - $1, 0) WHERE id::TEXT = $2',
        stock_col,
        stock_col
      ) USING qty, pid;
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_kgs_decrement_stock_on_order ON public.orders;
CREATE TRIGGER trg_kgs_decrement_stock_on_order
AFTER INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.kgs_decrement_stock_on_order();

-- ============================================================================
-- 6. GRANTS & ROW LEVEL SECURITY POLICIES
-- ============================================================================
GRANT USAGE ON SCHEMA public TO anon, authenticated;

-- Public catalog read-only grants
GRANT SELECT ON TABLE public.products TO anon, authenticated;
GRANT SELECT ON TABLE public.shops TO anon, authenticated;

-- Authenticated operational grants (restricted by RLS below)
GRANT INSERT, UPDATE, DELETE ON TABLE public.products TO authenticated;
GRANT INSERT, UPDATE ON TABLE public.shops TO authenticated;
GRANT SELECT, UPDATE ON TABLE public.profiles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.addresses TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.ration_items TO authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.orders TO authenticated;

-- Enable RLS on all tables
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ration_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- --- PRODUCTS RLS ---
DROP POLICY IF EXISTS "kgs_public_read_products" ON public.products;
CREATE POLICY "kgs_public_read_products"
ON public.products FOR SELECT TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "kgs_distributor_manage_own_shop_products" ON public.products;
CREATE POLICY "kgs_distributor_manage_own_shop_products"
ON public.products FOR ALL TO authenticated
USING (
  public.current_user_role() = 'admin'
  OR (
    public.current_user_role() = 'distributor'
    AND shop_id IN (SELECT id FROM public.shops WHERE owner_id = auth.uid())
  )
)
WITH CHECK (
  public.current_user_role() = 'admin'
  OR (
    public.current_user_role() = 'distributor'
    AND shop_id IN (SELECT id FROM public.shops WHERE owner_id = auth.uid())
  )
);

-- --- SHOPS RLS ---
DROP POLICY IF EXISTS "kgs_shops_select_policy" ON public.shops;
CREATE POLICY "kgs_shops_select_policy"
ON public.shops FOR SELECT TO anon, authenticated
USING (
  (is_approved = true AND is_active = true)
  OR owner_id = auth.uid()
  OR public.current_user_role() = 'admin'
);

DROP POLICY IF EXISTS "kgs_shops_insert_owner" ON public.shops;
CREATE POLICY "kgs_shops_insert_owner"
ON public.shops FOR INSERT TO authenticated
WITH CHECK (owner_id = auth.uid() AND is_approved = false);

DROP POLICY IF EXISTS "kgs_shops_update_owner_or_admin" ON public.shops;
CREATE POLICY "kgs_shops_update_owner_or_admin"
ON public.shops FOR UPDATE TO authenticated
USING (owner_id = auth.uid() OR public.current_user_role() = 'admin')
WITH CHECK (
  public.current_user_role() = 'admin'
  OR (owner_id = auth.uid() AND is_approved = (SELECT s.is_approved FROM public.shops s WHERE s.id = id))
);

-- --- PROFILES RLS ---
DROP POLICY IF EXISTS "kgs_profiles_select" ON public.profiles;
CREATE POLICY "kgs_profiles_select"
ON public.profiles FOR SELECT TO authenticated
USING (id = auth.uid() OR public.current_user_role() = 'admin');

DROP POLICY IF EXISTS "kgs_profiles_update_self_or_admin" ON public.profiles;
CREATE POLICY "kgs_profiles_update_self_or_admin"
ON public.profiles FOR UPDATE TO authenticated
USING (id = auth.uid() OR public.current_user_role() = 'admin')
WITH CHECK (
  public.current_user_role() = 'admin'
  OR (
    id = auth.uid()
    AND role = (SELECT p.role FROM public.profiles p WHERE p.id = auth.uid())
    AND is_active = (SELECT p.is_active FROM public.profiles p WHERE p.id = auth.uid())
  )
);

-- --- ADDRESSES RLS ---
DROP POLICY IF EXISTS "kgs_addresses_owner_all" ON public.addresses;
CREATE POLICY "kgs_addresses_owner_all"
ON public.addresses FOR ALL TO authenticated
USING (user_id = auth.uid() OR public.current_user_role() = 'admin')
WITH CHECK (user_id = auth.uid() OR public.current_user_role() = 'admin');

-- --- RATION ITEMS RLS ---
DROP POLICY IF EXISTS "kgs_ration_owner_all" ON public.ration_items;
CREATE POLICY "kgs_ration_owner_all"
ON public.ration_items FOR ALL TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- --- ORDERS RLS ---
DROP POLICY IF EXISTS "kgs_orders_select" ON public.orders;
CREATE POLICY "kgs_orders_select"
ON public.orders FOR SELECT TO authenticated
USING (
  customer_id = auth.uid()
  OR public.current_user_role() = 'admin'
  OR (
    public.current_user_role() = 'distributor'
    AND (
      distributor_id = auth.uid()
      OR shop_id IN (SELECT id FROM public.shops WHERE owner_id = auth.uid())
    )
  )
  OR (
    public.current_user_role() = 'delivery_partner'
    AND delivery_partner_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "kgs_orders_customer_insert" ON public.orders;
CREATE POLICY "kgs_orders_customer_insert"
ON public.orders FOR INSERT TO authenticated
WITH CHECK (
  customer_id = auth.uid()
  AND status IN ('pending', 'placed')
  AND (
    (payment_method = 'cod' AND payment_status = 'cod_pending')
    OR (payment_method = 'upi' AND payment_status = 'pending_verification')
  )
);

DROP POLICY IF EXISTS "kgs_orders_update_role_scoped" ON public.orders;
CREATE POLICY "kgs_orders_update_role_scoped"
ON public.orders FOR UPDATE TO authenticated
USING (
  public.current_user_role() = 'admin'
  OR (
    customer_id = auth.uid()
    AND status IN ('pending', 'placed', 'accepted', 'confirmed')
  )
  OR (
    public.current_user_role() = 'distributor'
    AND (
      distributor_id = auth.uid()
      OR shop_id IN (SELECT id FROM public.shops WHERE owner_id = auth.uid())
    )
  )
  OR (
    public.current_user_role() = 'delivery_partner'
    AND delivery_partner_id = auth.uid()
  )
)
WITH CHECK (
  public.current_user_role() = 'admin'
  OR (
    -- Customers can only update UPI reference/claim or cancel pending orders; NEVER mark UPI verified
    customer_id = auth.uid()
    AND payment_status IN ('cod_pending', 'pending_verification')
  )
  OR (
    -- Distributors can advance fulfillment status; NEVER verify UPI payments
    public.current_user_role() = 'distributor'
    AND (
      distributor_id = auth.uid()
      OR shop_id IN (SELECT id FROM public.shops WHERE owner_id = auth.uid())
    )
    AND payment_status <> 'upi_verified'
  )
  OR (
    -- Delivery partners can update delivery status and mark COD collected
    public.current_user_role() = 'delivery_partner'
    AND delivery_partner_id = auth.uid()
    AND payment_status IN ('cod_pending', 'cod_collected', 'pending_verification', 'upi_verified')
  )
);

COMMIT;
