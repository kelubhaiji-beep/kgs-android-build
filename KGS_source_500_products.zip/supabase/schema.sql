-- KGS marketplace schema (run in Supabase SQL editor)
create extension if not exists pgcrypto;
create type public.app_role as enum ('customer','distributor','admin');
create type public.order_status as enum ('placed','accepted','packing','out_for_delivery','delivered','cancelled');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text, phone text unique, role public.app_role not null default 'customer',
 preferred_language text not null default 'en', created_at timestamptz default now()
);
create table public.stores (
 id uuid primary key default gen_random_uuid(), name text not null, owner_id uuid references public.profiles(id),
 phone text, address text, is_active boolean default true, created_at timestamptz default now()
);
create table public.categories (
 id uuid primary key default gen_random_uuid(), name text not null, name_hi text, image_url text, sort_order int default 0
);
create table public.products (
 id uuid primary key default gen_random_uuid(), store_id uuid references public.stores(id),
 category_id uuid references public.categories(id), name text not null, name_hi text,
 description text, image_url text, unit text default 'kg', price numeric(10,2) not null,
 is_available boolean default true, created_at timestamptz default now()
);
create table public.orders (
 id uuid primary key default gen_random_uuid(), customer_id uuid references public.profiles(id),
 store_id uuid references public.stores(id), status public.order_status default 'placed',
 payment_method text not null default 'cod', payment_status text default 'pending',
 subtotal numeric(10,2) not null, delivery_fee numeric(10,2) default 0,
 total numeric(10,2) not null, delivery_address jsonb not null,
 created_at timestamptz default now()
);
create table public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid references public.orders(id) on delete cascade,
 product_id uuid references public.products(id), product_name text not null,
 quantity numeric(10,3) not null, unit text not null, unit_price numeric(10,2) not null
);
create table public.monthly_lists (
 id uuid primary key default gen_random_uuid(), customer_id uuid references public.profiles(id),
 name text not null default 'Monthly ration', created_at timestamptz default now()
);
create table public.monthly_list_items (
 id uuid primary key default gen_random_uuid(), list_id uuid references public.monthly_lists(id) on delete cascade,
 product_id uuid references public.products(id), quantity numeric(10,3) default 1, unit text default 'kg'
);
alter table public.profiles enable row level security;
alter table public.stores enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.monthly_lists enable row level security;
alter table public.monthly_list_items enable row level security;
create policy "profiles read own" on public.profiles for select using (auth.uid()=id);
create policy "profiles update own" on public.profiles for update using (auth.uid()=id);
create policy "stores visible" on public.stores for select using (is_active=true);
create policy "categories public" on public.categories for select using (true);
create policy "products public" on public.products for select using (is_available=true);
create policy "orders own" on public.orders for all using (auth.uid()=customer_id) with check (auth.uid()=customer_id);
create policy "order items own" on public.order_items for all using (exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())) with check (exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid()));
create policy "monthly own" on public.monthly_lists for all using (auth.uid()=customer_id) with check (auth.uid()=customer_id);
create policy "monthly items own" on public.monthly_list_items for all using (exists(select 1 from public.monthly_lists l where l.id=list_id and l.customer_id=auth.uid())) with check (exists(select 1 from public.monthly_lists l where l.id=list_id and l.customer_id=auth.uid()));
insert into public.categories(name,name_hi,sort_order) values
('Staples','अनाज',1),('Pulses','दालें',2),('Vegetables','सब्ज़ियाँ',3),('Fruits','फल',4),('Dairy','डेयरी',5),('Oils','तेल',6),('Beverages','पेय पदार्थ',7);
