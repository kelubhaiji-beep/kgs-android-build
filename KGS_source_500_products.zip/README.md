# KGS – Kailashpati General Store

Customer-side Flutter MVP for an India-focused multi-vendor kirana marketplace.

## Included in this MVP
- Mobile-number login screen with demo OTP (`123456`) and guest entry
- Home, category chips, product search, demo product photos and local-store labels
- Product cards with quantity size selector (100g, 200g, 500g, 1kg, 5kg)
- Cart quantity controls, subtotal/delivery/total and checkout sheet
- COD and UPI demo payment choices, demo order confirmation
- Orders/tracking placeholder and monthly ration checklist
- Customer profile shell and English/Hindi toggle
- Supabase/PostgreSQL schema with stores, products, orders and monthly lists plus starter RLS policies

## Run
1. Install Flutter stable and Android Studio / Xcode.
2. From this directory run `flutter create .` if platform folders are not present.
3. Run `flutter pub get`.
4. Demo: `flutter run`.
5. Supabase: create a project, run `supabase/schema.sql` in SQL Editor, then:
   `flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY`

## Important integration notes
- The current UI deliberately uses demo products and a demo OTP. Real OTP requires enabling Supabase Phone Auth and configuring an SMS provider.
- UPI is a demo choice only. Production UPI needs a payment provider (e.g. Razorpay/PhonePe) and server-side payment verification; never put secret keys in Flutter.
- Production order placement should be implemented through a Supabase Edge Function or trusted backend, with stock reservation, price validation, vendor assignment, delivery fee calculation and payment verification.
- For a multi-vendor cart, split the cart into one order per store or define a central fulfilment model. This starter shows mixed demo inventory and should be refined before production.
- Distributor authentication/dashboard is intentionally phase 2; roles and stores are represented in the database schema.
- Product image URLs are demo Unsplash assets. Replace with licensed store/product images and Supabase Storage.
- Review and harden RLS policies before launch. Add address ownership, vendor-scoped product/order permissions, audit logs, rate limits and server-side role assignment.
