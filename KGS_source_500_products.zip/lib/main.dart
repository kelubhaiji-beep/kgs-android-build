import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
bool get supabaseReady => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseReady) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const KgsApp());
}

class Product {
  final String id, name, category, image, unit, shop;
  final double price;
  const Product(this.id, this.name, this.category, this.image, this.price,
      this.unit, this.shop);
}



class KgsApp extends StatefulWidget {
  const KgsApp({super.key});
  @override State<KgsApp> createState()=>_KgsAppState();
}
class _KgsAppState extends State<KgsApp> {
  bool hindi=false;
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'KGS Grocery',
    theme:ThemeData(useMaterial3:true, colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff16834a),brightness:Brightness.light),scaffoldBackgroundColor:const Color(0xfff7faf7),fontFamily:'Roboto'),
    home: Builder(
       builder: (navigatorContext) => LoginScreen(
         onDone: () => Navigator.of(navigatorContext).pushReplacement(
           MaterialPageRoute(
             builder: (_) => HomeShell(
               hindi: hindi,
               onLanguage: () => setState(() => hindi = !hindi),
             ),
           ),
         ),
       ),
     ),
  );
}

String tr(bool hi,String en,String hn)=>hi?hn:en;

class LoginScreen extends StatefulWidget {
 final VoidCallback onDone; const LoginScreen({super.key,required this.onDone});
 @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
 final phone=TextEditingController(); final otp=TextEditingController(); bool sent=false;
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
 const SizedBox(height:36), Container(height:92,width:92,alignment:Alignment.center,decoration:BoxDecoration(color:const Color(0xffe4f5e9),borderRadius:BorderRadius.circular(28)),child:const Icon(Icons.shopping_basket_rounded,color:Color(0xff16834a),size:54)),
 const SizedBox(height:20),const Text('KGS',textAlign:TextAlign.center,style:TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:Color(0xff126b3b))),const Text('Kailashpati General Store',textAlign:TextAlign.center,style:TextStyle(fontSize:16,fontWeight:FontWeight.w600)),
 const SizedBox(height:12),const Text('Your neighbourhood, delivered.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54)),
 const SizedBox(height:42),Text(sent?'Enter verification code':'Login with mobile number',style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
 const SizedBox(height:14),TextField(controller:sent?otp:phone,keyboardType:TextInputType.phone,maxLength:sent?6:10,decoration:InputDecoration(prefixIcon:Icon(sent?Icons.lock_outline:Icons.phone_android),hintText:sent?'6-digit OTP':'10-digit mobile number',border:OutlineInputBorder(borderRadius:BorderRadius.circular(16)))),
 FilledButton(onPressed:(){if(!sent){if(phone.text.length<10){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid 10-digit mobile number')));return;}setState(()=>sent=true);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Demo OTP: 123456')));}else{if(otp.text=='123456'){widget.onDone();}else{ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Use demo OTP 123456')));}}},style:FilledButton.styleFrom(padding:const EdgeInsets.all(17),backgroundColor:const Color(0xff16834a)),child:Text(sent?'Verify & continue':'Send OTP')),
 const SizedBox(height:12),const Text('Demo mode: use OTP 123456. Configure Supabase Auth for real SMS OTP.',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Colors.black54)),
 const SizedBox(height:34),TextButton(onPressed:widget.onDone,child:const Text('Continue as guest')),
 ])))));
}

class HomeShell extends StatefulWidget {
 final bool hindi; final VoidCallback onLanguage; const HomeShell({super.key,required this.hindi,required this.onLanguage});
 @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell>{
 int tab=0; final Map<String,int> cart={}; String search=''; String category='All';
 List<Product> products = [];
 bool loadingProducts = true;
 String? productsError;
 @override void initState(){super.initState();_loadProducts();}
 Future<void> _loadProducts() async {
   if (!supabaseReady) {
     setState(() { loadingProducts=false; productsError='Supabase configuration missing. Add build secrets.'; });
     return;
   }
   try {
     final client=Supabase.instance.client;
     final categoryRows=await client.from('categories').select('id,name,name_hi');
     final categoryNames=<String,String>{};
     for(final row in categoryRows){
       final id=row['id']?.toString()??'';
       final label=(row['name_hi']??row['name']??'Other').toString();
       if(id.isNotEmpty) categoryNames[id]=label;
     }
     final rows=await client.from('products').select().order('name').limit(1000);
     final loaded=rows.map<Product>((row){
       final catId=row['category_id']?.toString()??'';
       final rawPrice=row['price'];
       return Product(
         row['id']?.toString()??'',
         (row['name']??'Unnamed product').toString(),
         categoryNames[catId]??'Other',
         (row['image_url']??'').toString(),
         rawPrice is num ? rawPrice.toDouble() : double.tryParse('$rawPrice')??0,
         (row['unit']??'kg').toString(),
         'KGS Main Store',
       );
     }).where((p)=>p.id.isNotEmpty).toList();
     if(!mounted)return;
     setState(()=>{products=loaded,loadingProducts=false,productsError=loaded.isEmpty?'No products found in Supabase.':null});
   } catch(e) {
     if(!mounted)return;
     setState(()=>{loadingProducts=false,productsError='Products load nahi hue: $e'});
   }
 }
 int get count=>cart.values.fold(0,(a,b)=>a+b);
 double get total=>products.where((p)=>cart.containsKey(p.id)).fold(0,(a,p)=>a+p.price*cart[p.id]!);
 void add(Product p){setState(()=>cart[p.id]=(cart[p.id]??0)+1);}
 void change(Product p,int n){setState(()=>n<=0?cart.remove(p.id):cart[p.id]=n);}
 @override Widget build(BuildContext context){
 final pages=[
  home(),cartPage(),ordersPage(),profilePage()
 ];
 return Scaffold(body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:[
 NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:tr(widget.hindi,'Home','होम')),
 NavigationDestination(icon:Badge(label:Text('$count'),isLabelVisible:count>0,child:const Icon(Icons.shopping_cart_outlined)),label:tr(widget.hindi,'Cart','कार्ट')),
 NavigationDestination(icon:const Icon(Icons.receipt_long_outlined),label:tr(widget.hindi,'Orders','ऑर्डर')),
 NavigationDestination(icon:const Icon(Icons.person_outline),label:tr(widget.hindi,'Profile','प्रोफ़ाइल')),
 ]));
 }
 Widget home()=>CustomScrollView(slivers:[
 SliverToBoxAdapter(child:Container(padding:const EdgeInsets.fromLTRB(18,48,18,20),decoration:const BoxDecoration(color:Color(0xff16834a),borderRadius:BorderRadius.vertical(bottom:Radius.circular(26))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Row(children:[const Icon(Icons.location_on,color:Colors.white),const SizedBox(width:6),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Delivering to',style:TextStyle(color:Colors.white70,fontSize:12)),Text('Home • Durgapur',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold))])),TextButton(onPressed:widget.onLanguage,child:Text(widget.hindi?'EN':'हिंदी',style:const TextStyle(color:Colors.white))) ]),
 const SizedBox(height:18),Text(tr(widget.hindi,'Good morning!','सुप्रभात!'),style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),Text(tr(widget.hindi,'Fresh groceries from shops near you','आपकी नज़दीकी दुकानों से ताज़ा सामान'),style:const TextStyle(color:Colors.white70)),
 const SizedBox(height:18),TextField(onChanged:(v)=>setState(()=>search=v),decoration:InputDecoration(filled:true,fillColor:Colors.white,hintText:tr(widget.hindi,'Search atta, rice, milk...','आटा, चावल, दूध खोजें...'),prefixIcon:const Icon(Icons.search),contentPadding:const EdgeInsets.all(14),border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none))),
 ]))),
 SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,18,16,8),child:Container(height:112,padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xffdff5e5),Color(0xfff3fbef)]),borderRadius:BorderRadius.circular(20)),child:Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text('MONTHLY RATION',style:TextStyle(color:Color(0xff16834a),fontWeight:FontWeight.w800)),Text('Your monthly essentials, one tap away',style:TextStyle(fontSize:14,fontWeight:FontWeight.w600))])),FilledButton.tonal(onPressed:()=>setState(()=>tab=2),child:const Text('View list')),const Icon(Icons.shopping_bag_outlined,size:38,color:Color(0xff16834a))])))),
 SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,12,16,8),child:Text(tr(widget.hindi,'Shop by category','श्रेणी के अनुसार खरीदें'),style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
 SliverToBoxAdapter(child:SizedBox(height:92,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),children:[
 for(final c in ['All',...products.map((p)=>p.category).where((c)=>c.isNotEmpty).toSet().toList()]) Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c))),
 ]))),
 SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,8,16,10),child:Row(children:[const Expanded(child:Text('Popular near you',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),Text('${products.length} items',style:const TextStyle(color:Colors.black54))]))),
 if(loadingProducts) const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(28),child:Center(child:CircularProgressIndicator()))),
 if(!loadingProducts && productsError!=null) SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[Text(productsError!,textAlign:TextAlign.center),const SizedBox(height:8),OutlinedButton(onPressed:(){setState(()=>loadingProducts=true);_loadProducts();},child:const Text('Retry'))]))),
 if(!loadingProducts && productsError==null) SliverPadding(padding:const EdgeInsets.fromLTRB(14,0,14,24),sliver:SliverGrid(delegate:SliverChildBuilderDelegate((context,i){final p=filtered[i];return ProductCard(p:p,qty:cart[p.id]??0,onAdd:()=>add(p),onChange:(n)=>change(p,n));},childCount:filtered.length),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:.68))),
 ]);
 List<Product> get filtered=>products.where((p)=>(category=='All'||p.category==category)&&(search.isEmpty||p.name.toLowerCase().contains(search.toLowerCase()))).toList();
 Widget cartPage()=>Scaffold(appBar:AppBar(title:const Text('My Cart')),body:cart.isEmpty?const Center(child:Text('Your cart is empty. Add some groceries!')):Column(children:[Expanded(child:ListView(children:[for(final p in products.where((p)=>cart.containsKey(p.id)))ListTile(leading:ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.network(p.image,width:54,height:54,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.image))),title:Text(p.name),subtitle:Text('₹${p.price.toStringAsFixed(0)} / ${p.unit}'),trailing:qtyControl(cart[p.id]!, (n)=>change(p,n)))])),Container(padding:const EdgeInsets.all(18),decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(20))),child:Column(children:[row('Subtotal','₹${total.toStringAsFixed(2)}'),row('Delivery','₹20.00'),row('Total','₹${(total+20).toStringAsFixed(2)}',bold:true),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:checkout,child:Text('Proceed to checkout • ₹${(total+20).toStringAsFixed(0)}')))]))]));
 Widget row(String a,String b,{bool bold=false})=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(children:[Text(a,style:TextStyle(fontWeight:bold?FontWeight.bold:FontWeight.normal)),const Spacer(),Text(b,style:TextStyle(fontWeight:bold?FontWeight.bold:FontWeight.normal))]));
 Widget qtyControl(int n,ValueChanged<int> on)=>Container(decoration:BoxDecoration(border:Border.all(color:const Color(0xff16834a)),borderRadius:BorderRadius.circular(10)),child:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(visualDensity:VisualDensity.compact,onPressed:()=>on(n-1),icon:const Icon(Icons.remove,size:17)),Text('$n'),IconButton(visualDensity:VisualDensity.compact,onPressed:()=>on(n+1),icon:const Icon(Icons.add,size:17))]));
  void checkout() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(22, 24, 22, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Checkout', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('Delivery address'),
            const TextField(decoration: InputDecoration(hintText: 'House / street / landmark')),
            const SizedBox(height: 14),
            const Text('Payment method'),
            RadioListTile<String>(value: 'COD', groupValue: 'COD', onChanged: (_) {}, title: const Text('Cash on Delivery')),
            RadioListTile<String>(value: 'UPI', groupValue: 'COD', onChanged: (_) {}, title: const Text('UPI (demo)')),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  setState(() => tab = 2);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Demo order placed! Order #KGS1024')),
                  );
                },
                child: const Text('Place order'),
              ),
            ),
          ],
        ),
      ),
    );
  }
 Widget ordersPage()=>Scaffold(appBar:AppBar(title:const Text('Orders & Monthly Ration')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const CircleAvatar(backgroundColor:Color(0xffe2f4e8),child:Icon(Icons.local_shipping,color:Color(0xff16834a))),title:const Text('Order #KGS1024'),subtitle:const Text('Demo order • Preparing your items'),trailing:const Chip(label:Text('Processing')))),const SizedBox(height:18),const Text('Monthly ration list',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const Text('Save essentials and reorder them every month.'),for(final p in products.take(6))CheckboxListTile(value:true,onChanged:(_){},title:Text(p.name),subtitle:Text('₹${p.price.toStringAsFixed(0)} / ${p.unit}'))]));
 Widget profilePage()=>Scaffold(appBar:AppBar(title:const Text('My Profile')),body:ListView(padding:const EdgeInsets.all(16),children:[const CircleAvatar(radius:38,child:Icon(Icons.person,size:40)),const SizedBox(height:10),const Text('KGS Customer',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.bold,fontSize:19)),const Text('+91 ••••••1234',textAlign:TextAlign.center),const SizedBox(height:20),for(final x in ['My addresses','Saved monthly ration','Language / भाषा','Help & support','About KGS'])ListTile(leading:const Icon(Icons.chevron_right),title:Text(x),onTap:()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$x — coming in the next MVP update')))),const Divider(),const ListTile(leading:Icon(Icons.storefront),title:Text('Local stores'),subtitle:Text('KGS Main Store • Fresh Mart • Green Basket'))]));
}

class ProductCard extends StatefulWidget{
 final Product p;final int qty;final VoidCallback onAdd;final ValueChanged<int> onChange;
 const ProductCard({super.key,required this.p,required this.qty,required this.onAdd,required this.onChange});
 @override State<ProductCard> createState()=>_ProductCardState();
}
class _ProductCardState extends State<ProductCard>{
 String unit='1 kg';
 @override Widget build(BuildContext context)=>Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.04),blurRadius:9,offset:const Offset(0,3))]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Expanded(child:Stack(children:[ClipRRect(borderRadius:const BorderRadius.vertical(top:Radius.circular(17)),child:Image.network(widget.p.image,width:double.infinity,height:double.infinity,fit:BoxFit.cover,errorBuilder:(_,__,___)=>Container(color:const Color(0xffedf5ef),child:const Icon(Icons.local_grocery_store,size:48,color:Color(0xff16834a))))),Positioned(left:8,top:8,child:Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:Colors.white.withOpacity(.92),borderRadius:BorderRadius.circular(20)),child:Text(widget.p.shop,style:const TextStyle(fontSize:9,fontWeight:FontWeight.bold))))])),
 Padding(padding:const EdgeInsets.fromLTRB(10,9,10,8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Text(widget.p.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.bold)),Text('₹${widget.p.price.toStringAsFixed(0)} / ${widget.p.unit}',style:const TextStyle(color:Color(0xff16834a),fontWeight:FontWeight.w700)),
 const SizedBox(height:6),DropdownButtonHideUnderline(child:DropdownButton<String>(isExpanded:true,value:unit,items:['100 g','200 g','500 g','1 kg','5 kg'].map((u)=>DropdownMenuItem(value:u,child:Text(u,style:const TextStyle(fontSize:12)))).toList(),onChanged:(v)=>setState(()=>unit=v!))),
 SizedBox(width:double.infinity,height:34,child:widget.qty==0?OutlinedButton(onPressed:widget.onAdd,style:OutlinedButton.styleFrom(foregroundColor:const Color(0xff16834a),side:const BorderSide(color:Color(0xff16834a))),child:const Text('ADD')):Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[IconButton(onPressed:()=>widget.onChange(widget.qty-1),icon:const Icon(Icons.remove,size:17)),Text('${widget.qty}'),IconButton(onPressed:()=>widget.onChange(widget.qty+1),icon:const Icon(Icons.add,size:17))]))
 ]))
 ]));
}
