# KGS Direct UPI + COD update (test build)

## What changed
- Added `url_launcher` dependency.
- Checkout now collects a delivery address and lets the customer choose COD or Kotak Direct UPI.
- Kotak UPI intent uses the supplied VPA `7992359405@kotakbank`, payee `Kailash Yadav`, INR and the current cart total (subtotal + ₹20 delivery).
- UPI is launched externally so a compatible UPI app can handle it.

## Important limitations — not production-ready
- This is an Android UPI-intent handoff, not a payment gateway. The app cannot trust the return from another UPI app as proof of payment. Check the Kotak bank transaction/statement before marking an order paid.
- The current app still has demo OTP and demo order flow. COD currently displays a demo notice; neither COD nor UPI orders are persisted to Supabase by this change.
- Do not dispatch goods based only on a screenshot or customer claim. Confirm credit in the merchant bank account.
- UPI app availability, payee-name display and payment acceptance depend on the installed UPI app and bank/NPCI handling. The app does not control these.
- The existing Supabase schema in `supabase/schema.sql` defines `stores/store_id`; the live database described by the owner uses `shops/shop_id`. Do not run the old schema over the live database. Inspect actual `orders` table columns and RLS before implementing order persistence.

## Build
1. Run `flutter pub get`.
2. Build the APK using the existing GitHub Actions workflow.
3. Install the debug APK and test a small amount first.
4. Verify the payee shown in the UPI app before approving any payment.
